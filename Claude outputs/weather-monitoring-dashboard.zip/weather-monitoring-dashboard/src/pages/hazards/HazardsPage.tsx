import { useMemo, useState } from 'react';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import ToggleButton from '@mui/material/ToggleButton';
import BoltRoundedIcon from '@mui/icons-material/BoltRounded';
import AcUnitRoundedIcon from '@mui/icons-material/AcUnitRounded';
import StormRoundedIcon from '@mui/icons-material/StormRounded';
import WaterRoundedIcon from '@mui/icons-material/WaterRounded';
import CloudRoundedIcon from '@mui/icons-material/CloudRounded';
import TerrainRoundedIcon from '@mui/icons-material/TerrainRounded';
import { MapContainer, TileLayer } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { PageHeader } from '@/components/common/PageHeader';
import { LoadingState } from '@/components/common/LoadingState';
import { ErrorState } from '@/components/common/ErrorState';
import { useListSitesQuery } from '@/features/sites/sitesApi';
import { useGetCurrentObservationsQuery } from '@/features/weather/weatherApi';
import type { CurrentObservation } from '@/features/weather/types';
import type { Site } from '@/features/sites/types';
import { SiteMarkers } from '@/pages/live-map/components/SiteMarkers';
import { RiskLegend } from '@/pages/live-map/components/RiskLegend';
import { useFiveDayObservations } from '@/pages/reports/useFiveDayObservations';
import { CycloneMap } from './components/CycloneMap';
import { FloodMap } from './components/FloodMap';
import { RiskIntensityDashboard } from './components/RiskIntensityDashboard';
import { WeeklyAdvisories } from './components/WeeklyAdvisories';
import {
  getActiveCyclone,
  buildWeatherParameterRiskRows,
  buildHazardRiskRows,
  buildWeeklyAdvisories,
} from './hazardData';

type HazardType = 'lightning' | 'snowfall' | 'cyclone' | 'flood' | 'fog' | 'avalanche';

const HAZARD_TOGGLES: { value: HazardType; label: string; icon: JSX.Element }[] = [
  { value: 'lightning', label: 'Lightning', icon: <BoltRoundedIcon fontSize="small" /> },
  { value: 'snowfall', label: 'Snowfall', icon: <AcUnitRoundedIcon fontSize="small" /> },
  { value: 'cyclone', label: 'Cyclone', icon: <StormRoundedIcon fontSize="small" /> },
  { value: 'flood', label: 'Flood', icon: <WaterRoundedIcon fontSize="small" /> },
  { value: 'fog', label: 'Fog', icon: <CloudRoundedIcon fontSize="small" /> },
  { value: 'avalanche', label: 'Avalanche', icon: <TerrainRoundedIcon fontSize="small" /> },
];

const INDIA_CENTER: [number, number] = [22.9734, 78.6569];

/** Site-marker map for the per-site hazards (lightning/snowfall/fog/
 *  avalanche) - these already exist as Live Map parameter layers, so this
 *  reuses the exact same marker component/coloring rather than building a
 *  second implementation. */
function SiteHazardMap({
  sites,
  observations,
  layer,
}: {
  sites: Site[];
  observations: Record<string, CurrentObservation>;
  layer: 'lightning' | 'snowfall' | 'fog' | 'avalanche';
}) {
  return (
    <Paper variant="outlined" sx={{ position: 'relative', overflow: 'hidden' }}>
      <Box sx={{ height: 480 }}>
        <MapContainer center={INDIA_CENTER} zoom={5} minZoom={4} style={{ height: '100%', width: '100%' }}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="&copy; OpenStreetMap contributors" />
          <SiteMarkers sites={sites} observations={observations} layer={layer} showWind={false} />
        </MapContainer>
      </Box>
      <RiskLegend />
    </Paper>
  );
}

export default function HazardsPage() {
  const [hazard, setHazard] = useState<HazardType>('cyclone');

  const { data: sitesPage, isLoading: sitesLoading, isError, refetch } = useListSitesQuery({ pageSize: 500 });
  const sites = useMemo(() => sitesPage?.items ?? [], [sitesPage]);
  const siteIds = useMemo(() => sites.map((s) => s.id), [sites]);

  const { data: observationsList, isLoading: obsLoading } = useGetCurrentObservationsQuery(siteIds, {
    skip: siteIds.length === 0,
  });
  const obsBySiteId = useMemo(() => {
    const map: Record<string, CurrentObservation> = {};
    (observationsList ?? []).forEach((obs) => {
      map[obs.siteId] = obs;
    });
    return map;
  }, [observationsList]);

  const { days, isLoading: forecastLoading } = useFiveDayObservations(siteIds);

  const cyclone = useMemo(() => getActiveCyclone(), []);
  const parameterRows = useMemo(() => buildWeatherParameterRiskRows(sites, obsBySiteId), [sites, obsBySiteId]);
  const hazardRows = useMemo(() => buildHazardRiskRows(sites, obsBySiteId, cyclone), [sites, obsBySiteId, cyclone]);
  const weeklyRows = useMemo(() => buildWeeklyAdvisories(sites, days), [sites, days]);

  const loading = sitesLoading || obsLoading;

  return (
    <Stack spacing={2}>
      <PageHeader
        title="Hazards & Advisories"
        description="Special bulletins (cyclone, flood), hazard-specific views, today's district risk intensity, and the weekly monsoon-preparation advisory"
      />

      {isError ? (
        <ErrorState onRetry={refetch} />
      ) : loading ? (
        <LoadingState label="Loading hazard data..." />
      ) : (
        <>
          <ToggleButtonGroup
            value={hazard}
            exclusive
            onChange={(_e, value: HazardType | null) => value && setHazard(value)}
            sx={{ flexWrap: 'wrap', gap: 0.5, '& .MuiToggleButtonGroup-grouped': { border: '1px solid', borderColor: 'divider', borderRadius: '8px !important' } }}
          >
            {HAZARD_TOGGLES.map((item) => (
              <ToggleButton key={item.value} value={item.value} sx={{ px: 1.5, gap: 0.75 }}>
                {item.icon}
                {item.label}
              </ToggleButton>
            ))}
          </ToggleButtonGroup>

          <div>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
              {HAZARD_TOGGLES.find((h) => h.value === hazard)?.label} Map
            </Typography>
            {hazard === 'cyclone' && <CycloneMap cyclone={cyclone} />}
            {hazard === 'flood' && <FloodMap sites={sites} observations={obsBySiteId} />}
            {(hazard === 'lightning' || hazard === 'snowfall' || hazard === 'fog' || hazard === 'avalanche') && (
              <SiteHazardMap sites={sites} observations={obsBySiteId} layer={hazard} />
            )}
            {(hazard === 'snowfall' || hazard === 'avalanche') && (
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
                Synthetic, elevation-derived risk - every current demo site sits well below avalanche/snowfall-relevant
                elevations, so this will read "No warning" until a high-Himalaya site is added to the network.
              </Typography>
            )}
          </div>

          <div>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
              Today&apos;s Risk Intensity of Districts
            </Typography>
            <RiskIntensityDashboard parameterRows={parameterRows} hazardRows={hazardRows} />
          </div>

          <div>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
              Weekly Advisories (Monsoon Preparation)
            </Typography>
            {forecastLoading ? (
              <LoadingState label="Loading 5-day outlook..." />
            ) : (
              <WeeklyAdvisories rows={weeklyRows} />
            )}
          </div>
        </>
      )}
    </Stack>
  );
}
