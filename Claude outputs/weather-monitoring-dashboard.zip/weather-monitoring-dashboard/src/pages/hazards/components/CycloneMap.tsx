import dayjs from 'dayjs';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Chip from '@mui/material/Chip';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { MapContainer, TileLayer, CircleMarker, Polyline, Tooltip } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { RISK_COLOR } from '@/utils/severity';
import { CYCLONE_WARNING_LABEL, type CycloneSystem } from '../hazardData';

const CLASSIFICATION_COLOR: Record<string, string> = {
  'Low Pressure Area': '#94a3b8',
  Depression: '#38bdf8',
  'Deep Depression': '#0ea5e9',
  'Cyclonic Storm': '#eab308',
  'Severe Cyclonic Storm': '#f97316',
  'Very Severe Cyclonic Storm': '#dc2626',
  'Super Cyclonic Storm': '#7c3aed',
};

interface CycloneMapProps {
  cyclone: CycloneSystem;
}

export function CycloneMap({ cyclone }: CycloneMapProps) {
  const center: [number, number] = [
    cyclone.track[Math.floor(cyclone.track.length / 2)].lat,
    cyclone.track[Math.floor(cyclone.track.length / 2)].lng,
  ];
  const observedPath = cyclone.track.filter((p) => p.observed).map((p): [number, number] => [p.lat, p.lng]);
  const forecastPath = cyclone.track.filter((p) => !p.observed);
  // Include the last observed point so the forecast line connects continuously.
  const lastObserved = cyclone.track.filter((p) => p.observed).slice(-1);
  const forecastLine = [...lastObserved, ...forecastPath].map((p): [number, number] => [p.lat, p.lng]);

  return (
    <Stack spacing={2}>
      <Paper variant="outlined" sx={{ overflow: 'hidden' }}>
        <Box sx={{ height: 420 }}>
          <MapContainer center={center} zoom={6} style={{ height: '100%', width: '100%' }}>
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution="&copy; OpenStreetMap contributors"
            />
            <Polyline positions={observedPath} pathOptions={{ color: '#111827', weight: 2 }} />
            <Polyline positions={forecastLine} pathOptions={{ color: '#dc2626', weight: 2, dashArray: '6 6' }} />
            {cyclone.track.map((p, i) => (
              <CircleMarker
                key={i}
                center={[p.lat, p.lng]}
                radius={6 + i * 0.5}
                pathOptions={{
                  color: '#fff',
                  weight: 1.5,
                  fillColor: CLASSIFICATION_COLOR[p.classification],
                  fillOpacity: 0.9,
                }}
              >
                <Tooltip>
                  <strong>{p.classification}</strong>
                  <br />
                  {p.windKmph} km/h &bull; {dayjs(p.at).format('DD MMM, HH:mm')}
                  <br />
                  {p.observed ? 'Observed' : 'Forecast'}
                </Tooltip>
              </CircleMarker>
            ))}
          </MapContainer>
        </Box>
      </Paper>

      <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
        {Object.entries(CLASSIFICATION_COLOR).map(([label, color]) => (
          <Stack key={label} direction="row" alignItems="center" spacing={0.5}>
            <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: color }} />
            <Typography variant="caption">{label}</Typography>
          </Stack>
        ))}
        <Stack direction="row" alignItems="center" spacing={0.5}>
          <Box sx={{ width: 18, height: 2, backgroundColor: '#111827' }} />
          <Typography variant="caption">Observed path</Typography>
        </Stack>
        <Stack direction="row" alignItems="center" spacing={0.5}>
          <Box sx={{ width: 18, height: 2, backgroundColor: '#dc2626', backgroundImage: 'repeating-linear-gradient(90deg,#dc2626 0 4px,transparent 4px 7px)' }} />
          <Typography variant="caption">Forecast path</Typography>
        </Stack>
      </Stack>

      <div>
        <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1 }}>
          District Warnings
        </Typography>
        <TableContainer component={Paper} variant="outlined">
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>State</TableCell>
                <TableCell>District</TableCell>
                <TableCell>Warning Level</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {cyclone.districtWarnings.map((w) => (
                <TableRow key={`${w.state}-${w.district}`}>
                  <TableCell>{w.state}</TableCell>
                  <TableCell sx={{ fontWeight: 600 }}>{w.district}</TableCell>
                  <TableCell>
                    <Chip
                      size="small"
                      label={CYCLONE_WARNING_LABEL[w.level]}
                      sx={{ backgroundColor: RISK_COLOR[w.level], color: '#fff', fontWeight: 700 }}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
    </Stack>
  );
}
