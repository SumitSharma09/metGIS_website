import { useMemo } from 'react';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { MapContainer, TileLayer } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useListStatesQuery } from '@/features/sites/sitesApi';
import type { Site } from '@/features/sites/types';
import type { CurrentObservation } from '@/features/weather/types';
import { buildDistrictRiskIndex } from '@/utils/districtRisk';
import { RiskLegend } from '@/pages/live-map/components/RiskLegend';
import { DistrictLayer } from '@/pages/live-map/components/DistrictLayer';
import { useDistrictBoundariesForStates } from '@/pages/live-map/useDistrictBoundaries';
import { getFloodRisk } from '../hazardData';

const INDIA_CENTER: [number, number] = [22.9734, 78.6569];

interface FloodMapProps {
  sites: Site[];
  observations: Record<string, CurrentObservation>;
}

/** Flood risk has no separate hydrological model - it's derived from
 *  rainfall (see hazardData.ts's getFloodRisk) and rendered on the same
 *  real district-boundary choropleth machinery the Live Map uses, just
 *  colored by a different risk function. */
export function FloodMap({ sites, observations }: FloodMapProps) {
  const { data: allStates = [] } = useListStatesQuery();
  const { get: getBoundary } = useDistrictBoundariesForStates(allStates);

  const floodRiskIndex = useMemo(() => buildDistrictRiskIndex(sites, observations, getFloodRisk), [sites, observations]);

  return (
    <Paper variant="outlined" sx={{ position: 'relative', overflow: 'hidden' }}>
      <Box sx={{ height: 480 }}>
        <MapContainer center={INDIA_CENTER} zoom={5} minZoom={4} style={{ height: '100%', width: '100%' }}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="&copy; OpenStreetMap contributors" />
          {allStates.map((s) => {
            const { features } = getBoundary(s);
            if (features.length === 0) return null;
            return (
              <DistrictLayer
                key={s}
                stateName={s}
                features={features}
                districtRisk={floodRiskIndex}
                selectedDistrict={null}
                onSelectDistrict={() => {}}
                enableFitBounds={false}
              />
            );
          })}
        </MapContainer>
      </Box>
      <RiskLegend />
    </Paper>
  );
}
