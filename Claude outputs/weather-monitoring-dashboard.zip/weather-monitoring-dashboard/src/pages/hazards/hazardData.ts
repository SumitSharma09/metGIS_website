import dayjs from 'dayjs';
import type { Site } from '@/features/sites/types';
import type { CurrentObservation } from '@/features/weather/types';
import { getParameterRisk, RISK_RANK, worseRisk, type RiskLevel } from '@/utils/severity';
import { buildDistrictRiskIndex, type DistrictRiskInfo } from '@/utils/districtRisk';
import { layerRisk } from '@/pages/live-map/mapLayers';
import type { ForecastDaySnapshot } from '@/pages/reports/useFiveDayObservations';

/* ------------------------------------------------------------------ */
/* Cyclone (synthetic, illustrative demo system - see HazardsPage note) */
/* ------------------------------------------------------------------ */

export type CycloneClassification =
  | 'Low Pressure Area'
  | 'Depression'
  | 'Deep Depression'
  | 'Cyclonic Storm'
  | 'Severe Cyclonic Storm'
  | 'Very Severe Cyclonic Storm'
  | 'Super Cyclonic Storm';

// Approximate, illustrative wind-speed bands (kmph) - not IMD's official
// scale, which is defined in knots/kt sustained wind.
const CYCLONE_BANDS: { min: number; classification: CycloneClassification }[] = [
  { min: 222, classification: 'Super Cyclonic Storm' },
  { min: 166, classification: 'Very Severe Cyclonic Storm' },
  { min: 118, classification: 'Severe Cyclonic Storm' },
  { min: 89, classification: 'Cyclonic Storm' },
  { min: 62, classification: 'Deep Depression' },
  { min: 51, classification: 'Depression' },
  { min: 0, classification: 'Low Pressure Area' },
];

export function classifyCycloneWind(windKmph: number): CycloneClassification {
  return CYCLONE_BANDS.find((b) => windKmph >= b.min)?.classification ?? 'Low Pressure Area';
}

export interface CycloneTrackPoint {
  lat: number;
  lng: number;
  windKmph: number;
  classification: CycloneClassification;
  at: string; // ISO
  observed: boolean;
}

export interface CycloneDistrictWarning {
  state: string;
  district: string;
  level: RiskLevel; // reuses the shared scale: warning/alert/watch/none
}

export interface CycloneSystem {
  name: string;
  basin: string;
  track: CycloneTrackPoint[];
  districtWarnings: CycloneDistrictWarning[];
}

/** Labels for the shared RiskLevel scale in the specific "what to do about
 *  it" phrasing the scope document's Cyclone Map legend uses. */
export const CYCLONE_WARNING_LABEL: Record<RiskLevel, string> = {
  warning: 'Warning (Take Action)',
  alert: 'Alert (Be Prepared)',
  watch: 'Watch (Be Updated)',
  none: 'No Warning (No Action)',
};

/**
 * A single always-on, deterministically-seeded demo cyclone system in the
 * Bay of Bengal, tracking toward the West Bengal coast - illustrating the
 * Cyclone Map UI the scope document asks for. There's no real cyclone
 * model behind this (and no live cyclone feed to plug in yet), so this is
 * clearly a fixed demo scenario, not a live one - swap this function's
 * body for a real IMD/JTWC feed integration when one is available.
 */
export function getActiveCyclone(): CycloneSystem {
  const now = dayjs().hour(0).minute(0).second(0);
  const track: CycloneTrackPoint[] = [
    { lat: 12.5, lng: 88.0, windKmph: 35, at: now.subtract(3, 'day').toISOString(), observed: true },
    { lat: 14.5, lng: 87.5, windKmph: 55, at: now.subtract(2, 'day').toISOString(), observed: true },
    { lat: 16.8, lng: 87.2, windKmph: 75, at: now.subtract(1, 'day').toISOString(), observed: true },
    { lat: 18.9, lng: 87.6, windKmph: 100, at: now.toISOString(), observed: true },
    { lat: 20.6, lng: 88.0, windKmph: 130, at: now.add(1, 'day').toISOString(), observed: false },
    { lat: 21.8, lng: 88.3, windKmph: 105, at: now.add(2, 'day').toISOString(), observed: false },
    { lat: 22.8, lng: 88.5, windKmph: 70, at: now.add(3, 'day').toISOString(), observed: false },
  ].map((p) => ({ ...p, classification: classifyCycloneWind(p.windKmph) }));

  return {
    name: 'Cyclonic Storm ASANI (demo)',
    basin: 'Bay of Bengal',
    track,
    districtWarnings: [
      { state: 'West Bengal', district: 'North 24 Parganas', level: 'warning' },
      { state: 'Tamil Nadu', district: 'Chennai', level: 'watch' },
      { state: 'Kerala', district: 'Ernakulam', level: 'watch' },
    ],
  };
}

/* ------------------------------------------------------------------ */
/* Flood risk (derived from rainfall - no separate hydrological model)  */
/* ------------------------------------------------------------------ */

export function getFloodRisk(_site: Site, obs: CurrentObservation): RiskLevel {
  return getParameterRisk('rainfall', obs.rainfallLastHour);
}

/* ------------------------------------------------------------------ */
/* Today's Risk Intensity of Districts (weather parameters + hazards)   */
/* ------------------------------------------------------------------ */

export interface RiskIntensityRow {
  key: string;
  label: string;
  bands: Record<RiskLevel, string[]>; // district names, per band
}

function toRows(
  sites: Site[],
  obsBySiteId: Record<string, CurrentObservation>,
  entries: { key: string; label: string; riskFn: (site: Site, obs: CurrentObservation) => RiskLevel }[]
): RiskIntensityRow[] {
  return entries.map(({ key, label, riskFn }) => {
    const perDistrict = buildDistrictRiskIndex(sites, obsBySiteId, riskFn);
    const bands: Record<RiskLevel, string[]> = { warning: [], alert: [], watch: [], none: [] };
    perDistrict.forEach((info: DistrictRiskInfo) => {
      bands[info.risk].push(info.canonicalName);
    });
    (Object.keys(bands) as RiskLevel[]).forEach((k) => bands[k].sort());
    return { key, label, bands };
  });
}

export function buildWeatherParameterRiskRows(
  sites: Site[],
  obsBySiteId: Record<string, CurrentObservation>
): RiskIntensityRow[] {
  return toRows(sites, obsBySiteId, [
    { key: 'rainfall', label: 'Rainfall', riskFn: (_s, o) => getParameterRisk('rainfall', o.rainfallLastHour) },
    { key: 'wind', label: 'Wind', riskFn: (_s, o) => getParameterRisk('windSpeed', o.windSpeed) },
    { key: 'humidity', label: 'Humidity', riskFn: (_s, o) => getParameterRisk('humidity', o.humidity) },
    { key: 'visibility', label: 'Visibility', riskFn: (_s, o) => layerRisk('visibility', o) },
    { key: 'temperature', label: 'Temperature', riskFn: (_s, o) => getParameterRisk('temperature', o.temperature) },
  ]);
}

export function buildHazardRiskRows(
  sites: Site[],
  obsBySiteId: Record<string, CurrentObservation>,
  cyclone: CycloneSystem
): RiskIntensityRow[] {
  const rows = toRows(sites, obsBySiteId, [
    { key: 'lightning', label: 'Lightning', riskFn: (_s, o) => getParameterRisk('lightning', o.lightningStrikesLastHour) },
    { key: 'flood', label: 'Flood', riskFn: getFloodRisk },
    { key: 'fog', label: 'Fog', riskFn: (_s, o) => layerRisk('fog', o) },
    { key: 'snowfall', label: 'Snowfall', riskFn: (s, o) => layerRisk('snowfall', o, s) },
    { key: 'avalanche', label: 'Avalanche', riskFn: (s, o) => layerRisk('avalanche', o, s) },
  ]);

  const cycloneBands: Record<RiskLevel, string[]> = { warning: [], alert: [], watch: [], none: [] };
  cyclone.districtWarnings.forEach((w) => cycloneBands[w.level].push(w.district));
  (Object.keys(cycloneBands) as RiskLevel[]).forEach((k) => cycloneBands[k].sort());
  rows.splice(1, 0, { key: 'cyclone', label: 'Cyclone', bands: cycloneBands });

  return rows;
}

/* ------------------------------------------------------------------ */
/* Weekly advisories (monsoon-preparation style bulletin)               */
/* ------------------------------------------------------------------ */

const STATE_REGION: Record<string, string> = {
  Maharashtra: 'West',
  Delhi: 'North',
  Haryana: 'North',
  Karnataka: 'South',
  'Tamil Nadu': 'South',
  Telangana: 'South',
  'West Bengal': 'East',
  Gujarat: 'West',
  Rajasthan: 'North',
  'Uttar Pradesh': 'North',
  'Madhya Pradesh': 'Central',
  Bihar: 'East',
  Assam: 'Northeast',
  Chandigarh: 'North',
  Kerala: 'South',
};

const RAINFALL_OUTLOOK_LABEL: Record<RiskLevel, string> = {
  warning: 'Extremely Heavy',
  alert: 'Very Heavy',
  watch: 'Heavy',
  none: 'Light to Moderate',
};

export interface WeeklyAdvisoryRow {
  region: string;
  circle: string;
  rainfallOutlook: string;
  windOutlook: string;
  severity: RiskLevel;
  days: { label: string; risk: RiskLevel }[];
  summary: string;
}

export function buildWeeklyAdvisories(sites: Site[], days: ForecastDaySnapshot[]): WeeklyAdvisoryRow[] {
  const circles = Array.from(new Set(sites.map((s) => s.circle))).sort();
  const siteById = new Map(sites.map((s) => [s.id, s]));

  return circles.map((circle) => {
    const circleSites = sites.filter((s) => s.circle === circle);
    const region = STATE_REGION[circleSites[0]?.state ?? ''] ?? 'Pan-India';

    const dayRisks = days.map((day) => {
      let worst: RiskLevel = 'none';
      day.observations.forEach((obs) => {
        const site = siteById.get(obs.siteId);
        if (site && site.circle === circle) {
          worst = worseRisk(worst, getParameterRisk('rainfall', obs.rainfallLastHour));
        }
      });
      return { label: day.label, risk: worst };
    });

    const windRisks = days.map((day) => {
      let worst: RiskLevel = 'none';
      day.observations.forEach((obs) => {
        const site = siteById.get(obs.siteId);
        if (site && site.circle === circle) {
          worst = worseRisk(worst, getParameterRisk('windSpeed', obs.windSpeed));
        }
      });
      return worst;
    });

    const severity = dayRisks.reduce<RiskLevel>((acc, d) => worseRisk(acc, d.risk), 'none');
    const windSeverity = windRisks.reduce<RiskLevel>((acc, r) => worseRisk(acc, r), 'none');

    const worstDays = dayRisks.filter((d) => RISK_RANK[d.risk] === RISK_RANK[severity] && severity !== 'none');
    const summary =
      severity === 'none'
        ? `No significant rainfall or wind risk expected over ${circle} in the next 5 days.`
        : `${RAINFALL_OUTLOOK_LABEL[severity]} rainfall expected over ${circle} on ${worstDays
            .map((d) => d.label)
            .join(', ')}${windSeverity !== 'none' ? ', with thunderstorms, lightning & gusty winds likely' : ''}.`;

    return {
      region,
      circle,
      rainfallOutlook: RAINFALL_OUTLOOK_LABEL[severity],
      windOutlook: windSeverity === 'none' ? 'No significant wind risk' : 'Thunderstorms, lightning & gusty winds',
      severity,
      days: dayRisks,
      summary,
    };
  });
}
