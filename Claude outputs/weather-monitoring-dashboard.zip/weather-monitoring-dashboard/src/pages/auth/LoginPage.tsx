import { useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useLocation, useNavigate } from 'react-router-dom';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import Alert from '@mui/material/Alert';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import CircularProgress from '@mui/material/CircularProgress';
import Divider from '@mui/material/Divider';
import PersonRoundedIcon from '@mui/icons-material/PersonRounded';
import LockRoundedIcon from '@mui/icons-material/LockRounded';
import VisibilityRoundedIcon from '@mui/icons-material/VisibilityRounded';
import VisibilityOffRoundedIcon from '@mui/icons-material/VisibilityOffRounded';
import CloudCircleRoundedIcon from '@mui/icons-material/CloudCircleRounded';
import { useAppDispatch } from '@/app/hooks';
import { setCredentials } from '@/features/auth/authSlice';
import { useLoginMutation } from '@/features/auth/authApi';
import { loginSchema, type LoginFormValues } from '@/utils/validation';
import { APP_NAME } from '@/utils/constants';
import { ROUTES } from '@/routes/routePaths';

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [login, { isLoading }] = useLoginMutation();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const [formError, setFormError] = useState<string | null>(null);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: '', password: '', rememberMe: true },
  });

  const onSubmit = async (values: LoginFormValues) => {
    setFormError(null);
    try {
      const response = await login(values).unwrap();
      dispatch(setCredentials(response));
      const redirectTo = (location.state as { from?: { pathname: string } } | null)?.from?.pathname || ROUTES.liveMap;
      navigate(redirectTo, { replace: true });
    } catch (err) {
      const message = (err as { message?: string })?.message ?? 'Unable to sign in. Please try again.';
      setFormError(message);
    }
  };

  return (
    <Card
      elevation={12}
      sx={{ width: '100%', maxWidth: 420, position: 'relative', zIndex: 1, borderRadius: 4 }}
    >
      <CardContent sx={{ p: 4 }}>
        <Stack alignItems="center" spacing={1} sx={{ mb: 3 }}>
          <CloudCircleRoundedIcon color="primary" sx={{ fontSize: 42 }} />
          <Typography variant="h5" fontWeight={800}>
            {APP_NAME}
          </Typography>
          <Typography variant="body2" color="text.secondary" textAlign="center">
            Sign in to access the site weather monitoring dashboard
          </Typography>
        </Stack>

        {formError && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setFormError(null)}>
            {formError}
          </Alert>
        )}

        <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate>
          <Stack spacing={2.5}>
            <Controller
              name="username"
              control={control}
              render={({ field }) => (
                <TextField
                  {...field}
                  label="Username"
                  placeholder="Enter username"
                  fullWidth
                  autoFocus
                  error={Boolean(errors.username)}
                  helperText={errors.username?.message}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <PersonRoundedIcon fontSize="small" />
                      </InputAdornment>
                    ),
                  }}
                />
              )}
            />
            <Controller
              name="password"
              control={control}
              render={({ field }) => (
                <TextField
                  {...field}
                  label="Password"
                  placeholder="Enter password"
                  type={showPassword ? 'text' : 'password'}
                  fullWidth
                  error={Boolean(errors.password)}
                  helperText={errors.password?.message}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <LockRoundedIcon fontSize="small" />
                      </InputAdornment>
                    ),
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton size="small" onClick={() => setShowPassword((v) => !v)} edge="end">
                          {showPassword ? <VisibilityOffRoundedIcon fontSize="small" /> : <VisibilityRoundedIcon fontSize="small" />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              )}
            />

            <Stack direction="row" alignItems="center" justifyContent="space-between">
              <Controller
                name="rememberMe"
                control={control}
                render={({ field }) => (
                  <FormControlLabel
                    control={<Checkbox size="small" checked={field.value} onChange={field.onChange} />}
                    label={<Typography variant="body2">Remember me</Typography>}
                  />
                )}
              />
              <Typography variant="body2" color="primary" sx={{ cursor: 'pointer' }}>
                Forgot password?
              </Typography>
            </Stack>

            <Button type="submit" variant="contained" size="large" fullWidth disabled={isLoading}>
              {isLoading ? <CircularProgress size={22} color="inherit" /> : 'Sign in'}
            </Button>
          </Stack>
        </Box>

        <Divider sx={{ my: 3 }}>
          <Typography variant="caption" color="text.secondary">
            DEMO CREDENTIALS
          </Typography>
        </Divider>
        <Stack spacing={0.5}>
          <Typography variant="caption" color="text.secondary">
            Admin: <b>admin</b> / admin123 &nbsp;·&nbsp; Operator: <b>operator</b> / operator123 &nbsp;·&nbsp; Viewer:{' '}
            <b>viewer</b> / viewer123
          </Typography>
        </Stack>
      </CardContent>
    </Card>
  );
}
