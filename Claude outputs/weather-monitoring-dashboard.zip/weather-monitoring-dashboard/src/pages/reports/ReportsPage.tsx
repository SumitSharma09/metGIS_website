import { useState } from 'react';
import Stack from '@mui/material/Stack';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import { PageHeader } from '@/components/common/PageHeader';
import { TowerRiskReportsTab } from './TowerRiskReportsTab';
import { SavedReportsTab } from './SavedReportsTab';

type ReportsTab = 'risk' | 'saved';

export default function ReportsPage() {
  const [tab, setTab] = useState<ReportsTab>('risk');

  return (
    <Stack spacing={2}>
      <PageHeader
        title="Tower Risk Reports"
        description="Current and forecast weather risk across the tower network, with Excel/PDF export"
      />

      <Tabs value={tab} onChange={(_e, v: ReportsTab) => setTab(v)}>
        <Tab value="risk" label="Tower Risk Reports" />
        <Tab value="saved" label="Saved Reports" />
      </Tabs>

      {tab === 'risk' ? <TowerRiskReportsTab /> : <SavedReportsTab />}
    </Stack>
  );
}
