import { useMemo, useState } from 'react';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import Chip from '@mui/material/Chip';
import LockRoundedIcon from '@mui/icons-material/LockRounded';
import TableChartRoundedIcon from '@mui/icons-material/TableChartRounded';
import PictureAsPdfRoundedIcon from '@mui/icons-material/PictureAsPdfRounded';
import { FilterBar } from '@/components/common/FilterBar';
import { LoadingState } from '@/components/common/LoadingState';
import { ErrorState } from '@/components/common/ErrorState';
import { useListStatesQuery, useListDistrictsQuery, useListSitesQuery } from '@/features/sites/sitesApi';
import { useScopedStates } from '@/features/users/useScopedStates';
import { useGetCurrentObservationsQuery } from '@/features/weather/weatherApi';
import { useFiveDayObservations } from './useFiveDayObservations';
import { computeOverallRisk } from './riskAggregation';
import { SiteRiskTable, type SiteRiskRow } from './components/SiteRiskTable';
import { RiskDistributionCharts } from './components/RiskDistributionCharts';
import { RegionalHeatmap } from './components/RegionalHeatmap';
import { exportSiteRiskToExcel, exportSiteRiskToPdf } from './exportUtils';

export function TowerRiskReportsTab() {
  const [state, setState] = useState<string | null>(null);
  const [district, setDistrict] = useState<string | null>(null);

  const { data: states = [] } = useListStatesQuery();
  const { data: districts = [] } = useListDistrictsQuery(state ?? undefined);
  const { isPanIndia, assignedStates } = useScopedStates();
  const { data: sitesPage, isLoading: sitesLoading, isError, refetch } = useListSitesQuery({
    state: state ?? undefined,
    district: district ?? undefined,
    pageSize: 200,
  });
  const sites = useMemo(() => sitesPage?.items ?? [], [sitesPage]);
  const siteIds = useMemo(() => sites.map((s) => s.id), [sites]);

  const { data: observations, isLoading: obsLoading } = useGetCurrentObservationsQuery(siteIds, { skip: siteIds.length === 0 });
  const { days, isLoading: forecastLoading } = useFiveDayObservations(siteIds);

  const rows: SiteRiskRow[] = useMemo(() => {
    const bySite = new Map(sites.map((s) => [s.id, s]));
    return (observations ?? [])
      .map((obs) => {
        const site = bySite.get(obs.siteId);
        if (!site) return null;
        return { site, obs, overallRisk: computeOverallRisk(obs) } satisfies SiteRiskRow;
      })
      .filter((r): r is SiteRiskRow => r !== null)
      .sort((a, b) => a.site.name.localeCompare(b.site.name));
  }, [observations, sites]);

  const loading = sitesLoading || obsLoading;

  return (
    <Stack spacing={2}>
      <FilterBar>
        <Autocomplete
          size="small"
          options={states}
          value={state}
          onChange={(_e, value) => {
            setState(value);
            setDistrict(null);
          }}
          sx={{ minWidth: 200 }}
          renderInput={(params) => <TextField {...params} label="State" />}
        />
        <Autocomplete
          size="small"
          options={districts}
          value={district}
          disabled={districts.length === 0}
          onChange={(_e, value) => setDistrict(value)}
          sx={{ minWidth: 200 }}
          renderInput={(params) => <TextField {...params} label="District" />}
        />
        {!isPanIndia && (
          <Chip
            size="small"
            variant="outlined"
            color="primary"
            icon={<LockRoundedIcon fontSize="small" />}
            label={`Scoped to: ${assignedStates.join(', ') || 'none assigned'}`}
          />
        )}
        <Divider orientation="vertical" flexItem />
        <Button
          size="small"
          variant="outlined"
          startIcon={<TableChartRoundedIcon />}
          disabled={rows.length === 0}
          onClick={() => exportSiteRiskToExcel(rows)}
        >
          Export Excel
        </Button>
        <Button
          size="small"
          variant="outlined"
          startIcon={<PictureAsPdfRoundedIcon />}
          disabled={rows.length === 0}
          onClick={() => exportSiteRiskToPdf(rows)}
        >
          Export PDF
        </Button>
      </FilterBar>

      {isError ? (
        <ErrorState onRetry={refetch} />
      ) : loading ? (
        <LoadingState label="Loading tower risk data..." />
      ) : (
        <>
          <RiskDistributionCharts rows={rows} />

          <div>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
              Site Risk Table
            </Typography>
            <SiteRiskTable rows={rows} />
          </div>

          <div>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
              Regional Forecast Heatmap
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
              Worst overall risk per district, next 5 days
            </Typography>
            {forecastLoading ? <LoadingState label="Loading forecast heatmap..." /> : <RegionalHeatmap sites={sites} days={days} />}
          </div>
        </>
      )}
    </Stack>
  );
}
