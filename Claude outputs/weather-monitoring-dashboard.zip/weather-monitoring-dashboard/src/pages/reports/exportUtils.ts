import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import dayjs from 'dayjs';
import { REPORT_RISK_LABEL } from '@/utils/severity';
import type { SiteRiskRow } from './components/SiteRiskTable';

const EXPORT_COLUMNS = ['Site', 'Code', 'State', 'District', 'Temperature (°C)', 'Rainfall (mm/hr)', 'Wind (km/h)', 'Humidity (%)', 'Lightning', 'Overall Risk'];

function toRows(rows: SiteRiskRow[]): (string | number)[][] {
  return rows.map((r) => [
    r.site.name,
    r.site.code,
    r.site.state,
    r.site.district,
    r.obs.temperature,
    r.obs.rainfallLastHour,
    r.obs.windSpeed,
    r.obs.humidity,
    r.obs.lightningStrikesLastHour,
    REPORT_RISK_LABEL[r.overallRisk],
  ]);
}

export function exportSiteRiskToExcel(rows: SiteRiskRow[]) {
  const wsData = [EXPORT_COLUMNS, ...toRows(rows)];
  const worksheet = XLSX.utils.aoa_to_sheet(wsData);
  worksheet['!cols'] = EXPORT_COLUMNS.map(() => ({ wch: 18 }));
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Tower Risk Report');
  XLSX.writeFile(workbook, `tower-risk-report-${dayjs().format('YYYY-MM-DD')}.xlsx`);
}

export function exportSiteRiskToPdf(rows: SiteRiskRow[]) {
  const doc = new jsPDF({ orientation: 'landscape' });
  doc.setFontSize(14);
  doc.text('Tower Risk Report', 14, 16);
  doc.setFontSize(9);
  doc.text(`Generated ${dayjs().format('DD MMM YYYY, HH:mm')}`, 14, 22);
  autoTable(doc, {
    startY: 28,
    head: [EXPORT_COLUMNS],
    body: toRows(rows),
    styles: { fontSize: 8 },
    headStyles: { fillColor: [37, 99, 235] },
  });
  doc.save(`tower-risk-report-${dayjs().format('YYYY-MM-DD')}.pdf`);
}
