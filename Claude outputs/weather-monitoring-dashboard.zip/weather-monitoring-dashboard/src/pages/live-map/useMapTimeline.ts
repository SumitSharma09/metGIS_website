import { useEffect, useMemo, useRef, useState } from 'react';
import dayjs from 'dayjs';

export type TimelineSpeed = 1 | 2 | 4;

const TIMELINE_DAYS = 5;
const BASE_STEP_MS = 2200;

/**
 * Drives the map's 5-day timeline scrubber: day 0 is "now", days 1-4 are
 * the upcoming forecast horizon. Reuses the same deterministic mock
 * generator as the rest of the app (via the offset -> ISO timestamp this
 * hook produces), so scrubbing forward shows a plausible, stable forecast
 * rather than random noise.
 */
export function useMapTimeline() {
  const [dayOffset, setDayOffset] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState<TimelineSpeed>(1);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (!playing) {
      if (intervalRef.current) window.clearInterval(intervalRef.current);
      return;
    }
    intervalRef.current = window.setInterval(() => {
      setDayOffset((prev) => (prev + 1) % TIMELINE_DAYS);
    }, BASE_STEP_MS / speed);
    return () => {
      if (intervalRef.current) window.clearInterval(intervalRef.current);
    };
  }, [playing, speed]);

  const days = useMemo(
    () =>
      Array.from({ length: TIMELINE_DAYS }, (_, i) => {
        const date = dayjs().add(i, 'day');
        return { offset: i, date, label: i === 0 ? 'Today' : date.format('ddd D MMM') };
      }),
    []
  );

  const selectedDate = days[dayOffset]?.date ?? dayjs();
  // Sample at midday so the "current conditions" snapshot for a future day
  // reads as a representative daytime observation rather than midnight.
  const at = selectedDate.hour(12).minute(0).second(0).toISOString();

  return {
    days,
    dayOffset,
    setDayOffset,
    playing,
    togglePlaying: () => setPlaying((p) => !p),
    speed,
    setSpeed,
    at,
    isToday: dayOffset === 0,
  };
}
