import { useMemo, useState } from 'react';
import Box from '@mui/material/Box';
import Chip from '@mui/material/Chip';
import { MapContainer, TileLayer } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useListSitesQuery, useListStatesQuery } from '@/features/sites/sitesApi';
import { useGetObservationsAtTimeQuery } from '@/features/weather/weatherApi';
import type { CurrentObservation } from '@/features/weather/types';
import { LoadingState } from '@/components/common/LoadingState';
import { ErrorState } from '@/components/common/ErrorState';
import { buildDistrictRiskIndex } from '@/utils/districtRisk';
import { MapControls } from './components/MapControls';
import { RiskLegend } from './components/RiskLegend';
import { TimelineScrubber } from './components/TimelineScrubber';
import { SiteMarkers } from './components/SiteMarkers';
import { DistrictLayer } from './components/DistrictLayer';
import { useMapTimeline } from './useMapTimeline';
import { useDistrictBoundariesForStates } from './useDistrictBoundaries';
import { layerRisk, type MapLayer } from './mapLayers';

export type Basemap = 'street' | 'satellite';

const INDIA_CENTER: [number, number] = [22.9734, 78.6569];

const TILE_LAYERS: Record<Basemap, { url: string; attribution: string }> = {
  street: {
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; OpenStreetMap contributors',
  },
  satellite: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, Maxar, Earthstar Geographics',
  },
};

export default function LiveMapPage() {
  const [state, setState] = useState<string | null>(null);
  const [district, setDistrict] = useState<string | null>(null);
  const [layer, setLayer] = useState<MapLayer>('temperature');
  const [basemap, setBasemap] = useState<Basemap>('street');
  const [showWind, setShowWind] = useState(false);

  const timeline = useMapTimeline();

  const { data: sitesPage, isLoading: sitesLoading, isError: sitesError, refetch } = useListSitesQuery({
    state: state ?? undefined,
    district: district ?? undefined,
    pageSize: 200,
  });
  const sites = useMemo(() => sitesPage?.items ?? [], [sitesPage]);
  const siteIds = useMemo(() => sites.map((s) => s.id), [sites]);

  const { data: observationsList } = useGetObservationsAtTimeQuery(
    { siteIds, at: timeline.at },
    { skip: siteIds.length === 0 }
  );

  const observations = useMemo(() => {
    const map: Record<string, CurrentObservation> = {};
    (observationsList ?? []).forEach((obs) => {
      map[obs.siteId] = obs;
    });
    return map;
  }, [observationsList]);

  // A second, state-scoped-but-not-district-filtered (or, with no state
  // picked yet, nationwide) view of the sites - this is what drives the
  // district choropleth, since every district needs to be colored by its
  // own worst risk, not just whichever single district the dropdown
  // currently has selected.
  const { data: riskScopeSitesPage } = useListSitesQuery({ state: state ?? undefined, pageSize: 500 });
  const riskScopeSites = useMemo(() => riskScopeSitesPage?.items ?? [], [riskScopeSitesPage]);
  const riskScopeSiteIds = useMemo(() => riskScopeSites.map((s) => s.id), [riskScopeSites]);

  const { data: riskScopeObservationsList } = useGetObservationsAtTimeQuery(
    { siteIds: riskScopeSiteIds, at: timeline.at },
    { skip: riskScopeSiteIds.length === 0 }
  );

  const districtRiskIndex = useMemo(() => {
    const obsBySite: Record<string, CurrentObservation> = {};
    (riskScopeObservationsList ?? []).forEach((obs) => {
      obsBySite[obs.siteId] = obs;
    });
    return buildDistrictRiskIndex(riskScopeSites, obsBySite, (site, obs) => layerRisk(layer, obs, site));
  }, [riskScopeSites, riskScopeObservationsList, layer]);

  // Which states' district boundary files to load: just the one picked
  // state when drilling down, or every state that has a monitored site
  // when nothing's picked yet - so the map shows colored districts
  // Pan-India by default, matching the reference product, instead of an
  // empty map until a state is chosen.
  const { data: allStates = [] } = useListStatesQuery();
  const targetStates = useMemo(() => (state ? [state] : allStates), [state, allStates]);
  const { get: getBoundary } = useDistrictBoundariesForStates(targetStates);

  const boundaryStatuses = targetStates.map((s) => getBoundary(s));
  const anyBoundaryLoading = boundaryStatuses.some((s) => s.loading);
  const totalBoundaryFeatures = boundaryStatuses.reduce((n, s) => n + s.features.length, 0);
  const allBoundariesFailed =
    targetStates.length > 0 && boundaryStatuses.every((s) => !s.loading) && totalBoundaryFeatures === 0;

  const handleSelectDistrict = (districtName: string, districtState: string) => {
    setState(districtState);
    setDistrict(districtName);
  };

  if (sitesLoading) return <LoadingState label="Loading tower network..." />;
  if (sitesError) return <ErrorState title="Failed to load sites" onRetry={refetch} />;

  return (
    <Box sx={{ position: 'relative', flex: 1, minHeight: 0 }}>
      <MapContainer
        center={INDIA_CENTER}
        zoom={5}
        minZoom={4}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          key={basemap}
          url={TILE_LAYERS[basemap].url}
          attribution={TILE_LAYERS[basemap].attribution}
        />
        {targetStates.map((s) => {
          const { features } = getBoundary(s);
          if (features.length === 0) return null;
          return (
            <DistrictLayer
              key={s}
              stateName={s}
              features={features}
              districtRisk={districtRiskIndex}
              selectedDistrict={district}
              onSelectDistrict={handleSelectDistrict}
              enableFitBounds={targetStates.length === 1}
            />
          );
        })}
        <SiteMarkers sites={sites} observations={observations} layer={layer} showWind={showWind} />
      </MapContainer>

      {anyBoundaryLoading && (
        <Chip
          label="Loading district boundaries..."
          size="small"
          sx={{ position: 'absolute', bottom: 84, left: '50%', transform: 'translateX(-50%)', zIndex: 1000 }}
        />
      )}
      {!anyBoundaryLoading && allBoundariesFailed && (
        <Chip
          label="District boundaries unavailable - showing site markers only"
          size="small"
          color="warning"
          sx={{ position: 'absolute', bottom: 84, left: '50%', transform: 'translateX(-50%)', zIndex: 1000 }}
        />
      )}

      <MapControls
        state={state}
        onChangeState={setState}
        district={district}
        onChangeDistrict={setDistrict}
        layer={layer}
        onChangeLayer={setLayer}
        basemap={basemap}
        onChangeBasemap={setBasemap}
        showWind={showWind}
        onToggleWind={setShowWind}
      />
      <RiskLegend />
      <TimelineScrubber
        days={timeline.days}
        dayOffset={timeline.dayOffset}
        onChangeOffset={timeline.setDayOffset}
        playing={timeline.playing}
        onTogglePlaying={timeline.togglePlaying}
        speed={timeline.speed}
        onChangeSpeed={timeline.setSpeed}
      />
    </Box>
  );
}
