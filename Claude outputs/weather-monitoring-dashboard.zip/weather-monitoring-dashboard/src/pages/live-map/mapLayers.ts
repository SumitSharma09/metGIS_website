import type { CurrentObservation } from '@/features/weather/types';
import type { Site } from '@/features/sites/types';
import {
  getParameterRisk,
  getCloudRisk,
  getVisibilityRisk,
  getSnowfallRisk,
  getAvalancheRisk,
  type RiskLevel,
} from '@/utils/severity';

export type MapLayer = 'temperature' | 'rainfall' | 'wind' | 'cloud' | 'visibility' | 'fog' | 'lightning' | 'snowfall' | 'avalanche';

export const MAP_LAYERS: { value: MapLayer; label: string }[] = [
  { value: 'temperature', label: 'Temperature' },
  { value: 'rainfall', label: 'Rainfall' },
  { value: 'cloud', label: 'Cloud' },
  { value: 'visibility', label: 'Visibility' },
  { value: 'fog', label: 'Fog' },
  { value: 'wind', label: 'Wind' },
  { value: 'lightning', label: 'Lightning' },
  { value: 'snowfall', label: 'Snowfall' },
  { value: 'avalanche', label: 'Avalanche' },
];

/** Reading + unit shown on a marker/popup for the currently active layer.
 *  `site` is only needed for the elevation-dependent hazards (snowfall/
 *  avalanche) - every other layer ignores it. */
export function layerReading(
  layer: MapLayer,
  obs: CurrentObservation,
  site?: Pick<Site, 'elevationMeters'>
): { value: number; unit: string; label: string } {
  switch (layer) {
    case 'temperature':
      return { value: obs.temperature, unit: '°C', label: 'Temperature' };
    case 'rainfall':
      return { value: obs.rainfallLastHour, unit: 'mm/hr', label: 'Rainfall (last hr)' };
    case 'wind':
      return { value: obs.windSpeed, unit: 'km/h', label: 'Wind speed' };
    case 'cloud':
      return { value: obs.humidity, unit: '%', label: 'Humidity (proxy)' };
    case 'visibility':
      return { value: obs.visibilityKm, unit: 'km', label: 'Visibility' };
    case 'fog':
      return { value: obs.visibilityKm, unit: 'km', label: 'Visibility (fog)' };
    case 'lightning':
      return { value: obs.lightningStrikesLastHour, unit: '/hr', label: 'Lightning strikes' };
    case 'snowfall':
      return { value: site?.elevationMeters ?? 0, unit: 'm elev.', label: 'Snowfall risk (by elevation)' };
    case 'avalanche':
      return { value: site?.elevationMeters ?? 0, unit: 'm elev.', label: 'Avalanche risk (by elevation)' };
    default:
      return { value: 0, unit: '', label: '' };
  }
}

/** Risk classification for a site under the currently active layer -
 *  this drives marker color and the legend, using the same thresholds
 *  shared with the Alerts feed and Tower Risk Reports. */
export function layerRisk(layer: MapLayer, obs: CurrentObservation, site?: Pick<Site, 'elevationMeters'>): RiskLevel {
  switch (layer) {
    case 'temperature':
      return getParameterRisk('temperature', obs.temperature);
    case 'rainfall':
      return getParameterRisk('rainfall', obs.rainfallLastHour);
    case 'wind':
      return getParameterRisk('windSpeed', obs.windSpeed);
    case 'cloud':
      return getCloudRisk(obs.condition);
    case 'visibility':
      return getVisibilityRisk(obs.visibilityKm);
    case 'fog':
      return obs.condition === 'fog' ? getVisibilityRisk(obs.visibilityKm) : 'none';
    case 'lightning':
      return getParameterRisk('lightning', obs.lightningStrikesLastHour);
    case 'snowfall':
      return site ? getSnowfallRisk(site.elevationMeters, obs.temperature) : 'none';
    case 'avalanche':
      return site ? getAvalancheRisk(site.elevationMeters, obs.temperature, obs.windSpeed) : 'none';
    default:
      return 'none';
  }
}
