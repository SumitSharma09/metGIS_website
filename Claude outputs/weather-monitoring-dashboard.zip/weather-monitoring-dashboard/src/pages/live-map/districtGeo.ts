/**
 * Real India district-boundary polygons, fetched at runtime from a public,
 * per-state GeoJSON source (this only happens in the end user's browser -
 * not from the build/dev environment - so it isn't affected by any
 * sandboxed network restrictions during development).
 *
 * Source: udit-001/india-maps-data (MIT-licensed, actively maintained),
 * served via the jsDelivr GitHub CDN - one small file per state rather than
 * one huge nationwide file, which is both faster to load and far more
 * reliable (no risk of hitting a Git-LFS pointer or a multi-tens-of-MB
 * payload, which is what a couple of the older "one big national file"
 * mirrors are prone to).
 *
 * Confirmed feature property keys on this source: `district` and `st_nm`
 * (plus `dt_code`/`st_code`/`year`, which we don't need).
 */

import { normalizeName } from '@/utils/districtRisk';

const REPO_REF = 'main';

function stateSlug(stateName: string): string {
  return stateName
    .toLowerCase()
    .trim()
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function districtGeoJsonUrl(stateName: string): string {
  return `https://cdn.jsdelivr.net/gh/udit-001/india-maps-data@${REPO_REF}/geojson/states/${stateSlug(stateName)}.geojson`;
}

export type DistrictFeature = GeoJSON.Feature<GeoJSON.Geometry, Record<string, unknown>>;
export type DistrictFeatureCollection = GeoJSON.FeatureCollection<GeoJSON.Geometry, Record<string, unknown>>;

/** Pulls {state, district} out of a feature's properties. Primarily
 *  `district`/`st_nm` (this source's actual keys), with a couple of
 *  fallback spellings kept in case the source ever changes shape. */
export function extractNames(feature: DistrictFeature): { state: string; district: string } | null {
  const props = feature.properties ?? {};
  const state = firstString(props, ['st_nm', 'STATE', 'state', 'NAME_1']);
  const district = firstString(props, ['district', 'DISTRICT', 'NAME_2', 'dtname']);
  if (!state || !district) return null;
  return { state, district };
}

function firstString(props: Record<string, unknown>, keys: string[]): string | undefined {
  for (const key of keys) {
    const value = props[key];
    if (typeof value === 'string' && value.trim() !== '') return value.trim();
  }
  return undefined;
}

// Known spelling differences between this boundary source and the district
// names used in our own site records (renames, combined vs. split
// districts, older Census-era spellings). Keyed by
// `${normalizedBoundaryDistrict}|${normalizedState}` so a name is only
// remapped within the right state. If a district stays gray on the map
// despite having a monitored site, add its exact boundary-source spelling
// here (open the browser console - a dev-mode warning logs any monitored
// site whose district didn't match a polygon).
const DISTRICT_ALIASES: Record<string, string> = {
  'bangalore|karnataka': 'Bengaluru Urban',
  'bangalore urban|karnataka': 'Bengaluru Urban',
  'bengaluru|karnataka': 'Bengaluru Urban',
  'mumbai|maharashtra': 'Mumbai Suburban',
  'mumbai city|maharashtra': 'Mumbai Suburban',
  'bombay|maharashtra': 'Mumbai Suburban',
  'delhi|delhi': 'New Delhi',
  'central delhi|delhi': 'New Delhi',
  'new delhi|delhi': 'New Delhi',
  'gurgaon|haryana': 'Gurugram',
  'kamrup|assam': 'Kamrup Metropolitan',
  'kamrup metropolitan|assam': 'Kamrup Metropolitan',
  'madras|tamil nadu': 'Chennai',
};

export function canonicalDistrictName(rawDistrict: string, rawState: string): string {
  const key = `${normalizeName(rawDistrict)}|${normalizeName(rawState)}`;
  return DISTRICT_ALIASES[key] ?? rawDistrict;
}

const stateCache = new Map<string, Promise<DistrictFeatureCollection>>();

/** Fetches (and memoizes for the lifetime of the tab) one state's district
 *  boundary FeatureCollection. */
export function fetchStateDistricts(stateName: string): Promise<DistrictFeatureCollection> {
  const cacheKey = normalizeName(stateName);
  const cached = stateCache.get(cacheKey);
  if (cached) return cached;

  const promise = (async () => {
    const res = await fetch(districtGeoJsonUrl(stateName));
    if (!res.ok) throw new Error(`HTTP ${res.status} loading district boundaries for ${stateName}`);
    const data = (await res.json()) as DistrictFeatureCollection;
    if (!data?.features?.length) throw new Error(`No district boundaries returned for ${stateName}`);
    return data;
  })();

  stateCache.set(cacheKey, promise);
  // Don't cache a rejected promise - let the next caller retry.
  promise.catch(() => stateCache.delete(cacheKey));

  return promise;
}
