import { useEffect, useRef, useState } from 'react';
import { fetchStateDistricts, type DistrictFeature } from './districtGeo';

interface StateBoundaryStatus {
  features: DistrictFeature[];
  loading: boolean;
  error: boolean;
}

const EMPTY_STATUS: StateBoundaryStatus = { features: [], loading: false, error: false };

/**
 * Loads district-boundary polygons for a set of states, one small
 * per-state file each (cached in `districtGeo.ts` for the tab's lifetime),
 * fetched in parallel. Used two ways by the Live Map:
 *  - no state picked yet -> pass every state that has a monitored site, so
 *    the whole country shows colored districts on first load (matching the
 *    reference product's default view);
 *  - a state picked -> pass just that one state, for the zoomed-in view.
 *
 * Implemented as one hook tracking a dynamic list (rather than one
 * `useDistrictBoundaries(stateName)` call per state) so the number of
 * states being watched can change from render to render without breaking
 * the rules of hooks.
 */
export function useDistrictBoundariesForStates(stateNames: string[]) {
  const [statusByState, setStatusByState] = useState<Record<string, StateBoundaryStatus>>({});
  const requested = useRef<Set<string>>(new Set());
  const key = [...stateNames].sort().join('|');

  useEffect(() => {
    stateNames.forEach((name) => {
      if (requested.current.has(name)) return;
      requested.current.add(name);
      setStatusByState((prev) => ({ ...prev, [name]: { features: [], loading: true, error: false } }));
      fetchStateDistricts(name)
        .then((collection) => {
          setStatusByState((prev) => ({ ...prev, [name]: { features: collection.features, loading: false, error: false } }));
        })
        .catch(() => {
          requested.current.delete(name); // allow a retry if this state is requested again later
          setStatusByState((prev) => ({ ...prev, [name]: { features: [], loading: false, error: true } }));
        });
    });
    // `key` (the sorted, joined state list) is the real dependency - it only
    // changes when the actual set of requested states changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  return {
    get: (stateName: string): StateBoundaryStatus => statusByState[stateName] ?? EMPTY_STATUS,
  };
}
