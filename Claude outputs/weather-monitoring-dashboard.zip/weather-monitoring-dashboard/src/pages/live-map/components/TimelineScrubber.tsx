import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Slider from '@mui/material/Slider';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import PlayArrowRoundedIcon from '@mui/icons-material/PlayArrowRounded';
import PauseRoundedIcon from '@mui/icons-material/PauseRounded';
import type { TimelineSpeed } from '../useMapTimeline';

interface TimelineScrubberProps {
  days: { offset: number; label: string }[];
  dayOffset: number;
  onChangeOffset: (offset: number) => void;
  playing: boolean;
  onTogglePlaying: () => void;
  speed: TimelineSpeed;
  onChangeSpeed: (speed: TimelineSpeed) => void;
}

export function TimelineScrubber({
  days,
  dayOffset,
  onChangeOffset,
  playing,
  onTogglePlaying,
  speed,
  onChangeSpeed,
}: TimelineScrubberProps) {
  const marks = days.map((d) => ({ value: d.offset, label: d.label }));

  return (
    <Paper
      elevation={4}
      sx={{
        position: 'absolute',
        left: 12,
        right: 12,
        bottom: 12,
        zIndex: 1000,
        px: 3,
        py: 1.5,
        backgroundColor: 'background.paper',
        opacity: 0.97,
        display: { xs: 'none', md: 'block' },
      }}
    >
      <Stack direction="row" alignItems="center" spacing={2}>
        <IconButton color="primary" onClick={onTogglePlaying} size="small">
          {playing ? <PauseRoundedIcon /> : <PlayArrowRoundedIcon />}
        </IconButton>
        <Typography variant="caption" color="text.secondary" sx={{ minWidth: 90 }}>
          5-day outlook
        </Typography>
        <Slider
          value={dayOffset}
          onChange={(_e, value) => onChangeOffset(value as number)}
          min={0}
          max={days.length - 1}
          step={1}
          marks={marks}
          sx={{ flex: 1, mx: 1 }}
        />
        <ToggleButtonGroup
          size="small"
          exclusive
          value={speed}
          onChange={(_e, value: TimelineSpeed | null) => value && onChangeSpeed(value)}
        >
          <ToggleButton value={1}>1x</ToggleButton>
          <ToggleButton value={2}>2x</ToggleButton>
          <ToggleButton value={4}>4x</ToggleButton>
        </ToggleButtonGroup>
      </Stack>
    </Paper>
  );
}
