import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { RISK_LEVELS, RISK_COLOR, MAP_RISK_LABEL, NO_DATA_COLOR } from '@/utils/severity';

export function RiskLegend() {
  return (
    <Paper
      elevation={4}
      sx={{
        position: 'absolute',
        left: 12,
        bottom: 12,
        zIndex: 1000,
        px: 1.5,
        py: 1,
        backgroundColor: 'background.paper',
        opacity: 0.96,
      }}
    >
      <Typography variant="caption" fontWeight={700} color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
        RISK LEVEL
      </Typography>
      <Stack direction="row" spacing={1.5}>
        {RISK_LEVELS.map((level) => (
          <Stack key={level} direction="row" alignItems="center" spacing={0.5}>
            <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: RISK_COLOR[level] }} />
            <Typography variant="caption">{MAP_RISK_LABEL[level]}</Typography>
          </Stack>
        ))}
        <Stack direction="row" alignItems="center" spacing={0.5}>
          <Box sx={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: NO_DATA_COLOR }} />
          <Typography variant="caption">No data</Typography>
        </Stack>
      </Stack>
    </Paper>
  );
}
