import { useMemo } from 'react';
import L from 'leaflet';
import { CircleMarker, Marker, Popup } from 'react-leaflet';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Chip from '@mui/material/Chip';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import { useNavigate } from 'react-router-dom';
import type { Site } from '@/features/sites/types';
import type { CurrentObservation } from '@/features/weather/types';
import { RISK_COLOR, MAP_RISK_LABEL } from '@/utils/severity';
import { layerReading, layerRisk, type MapLayer } from '../mapLayers';
import { ROUTES } from '@/routes/routePaths';
import { formatWithUnit } from '@/utils/formatters';

interface SiteMarkersProps {
  sites: Site[];
  observations: Record<string, CurrentObservation>;
  layer: MapLayer;
  showWind: boolean;
}

export function SiteMarkers({ sites, observations, layer, showWind }: SiteMarkersProps) {
  return (
    <>
      {sites.map((site) => {
        const obs = observations[site.id];
        if (!obs) return null;
        return <SiteMarker key={site.id} site={site} obs={obs} layer={layer} />;
      })}
      {showWind &&
        sites.map((site) => {
          const obs = observations[site.id];
          if (!obs) return null;
          return <WindArrow key={`wind-${site.id}`} site={site} obs={obs} />;
        })}
    </>
  );
}

function SiteMarker({ site, obs, layer }: { site: Site; obs: CurrentObservation; layer: MapLayer }) {
  const navigate = useNavigate();
  const risk = layerRisk(layer, obs, site);
  const reading = layerReading(layer, obs, site);
  const color = RISK_COLOR[risk];

  return (
    <CircleMarker
      center={[site.latitude, site.longitude]}
      radius={risk === 'none' ? 7 : 10}
      pathOptions={{
        color: '#ffffff',
        weight: 1.5,
        fillColor: color,
        fillOpacity: 0.9,
      }}
    >
      <Popup>
        <Stack spacing={0.75} sx={{ minWidth: 200 }}>
          <Typography variant="subtitle2" fontWeight={700}>
            {site.name}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {site.district}, {site.state}
          </Typography>
          <Divider sx={{ my: 0.5 }} />
          <Stack direction="row" justifyContent="space-between" alignItems="center">
            <Typography variant="body2">{reading.label}</Typography>
            <Typography variant="body2" fontWeight={700}>
              {formatWithUnit(reading.value, reading.unit)}
            </Typography>
          </Stack>
          <Chip
            size="small"
            label={MAP_RISK_LABEL[risk]}
            sx={{ backgroundColor: color, color: '#fff', fontWeight: 700, alignSelf: 'flex-start' }}
          />
          <Button size="small" variant="outlined" onClick={() => navigate(ROUTES.siteDetail(site.id))} sx={{ mt: 0.5 }}>
            View site details
          </Button>
        </Stack>
      </Popup>
    </CircleMarker>
  );
}

/**
 * Simplified wind-flow indicator: a rotated arrow icon per site, scaled and
 * colored by wind speed with a subtle CSS animation to suggest motion. Real
 * streamline rendering needs a dense gridded wind-vector field which the
 * per-site mock data doesn't model, so this point-based approximation
 * stands in for it - each arrow still points true to that site's live wind
 * direction and speed.
 */
function WindArrow({ site, obs }: { site: Site; obs: CurrentObservation }) {
  const icon = useMemo(() => {
    const scale = Math.min(1.6, 0.7 + obs.windSpeed / 40);
    const color = obs.windSpeed > 40 ? '#dc2626' : obs.windSpeed > 25 ? '#f97316' : '#0ea5a4';
    return L.divIcon({
      className: 'ops-wind-arrow',
      html: `<div style="
        transform: rotate(${obs.windDirection}deg) scale(${scale});
        color:${color};
        font-size:20px;
        line-height:1;
        filter: drop-shadow(0 0 2px rgba(0,0,0,0.6));
        animation: ops-wind-drift 1.8s ease-in-out infinite;
      ">&#8593;</div>`,
      iconSize: [20, 20],
      iconAnchor: [10, 10],
    });
  }, [obs.windDirection, obs.windSpeed]);

  return <Marker position={[site.latitude, site.longitude]} icon={icon} interactive={false} />;
}
