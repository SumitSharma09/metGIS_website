import { useEffect, useMemo } from 'react';
import L from 'leaflet';
import { GeoJSON, useMap } from 'react-leaflet';
import type { Layer, LeafletMouseEvent, StyleFunction } from 'leaflet';
import { RISK_COLOR, NO_DATA_COLOR, type RiskLevel } from '@/utils/severity';
import { normalizeName, type DistrictRiskInfo } from '@/utils/districtRisk';
import {
  extractNames,
  canonicalDistrictName,
  type DistrictFeature,
  type DistrictFeatureCollection,
} from '../districtGeo';

export type { DistrictRiskInfo };

interface DistrictLayerProps {
  stateName: string;
  features: DistrictFeature[];
  /** Keyed by normalizeName(canonical district name). */
  districtRisk: Map<string, DistrictRiskInfo>;
  selectedDistrict: string | null;
  /** Called with the clicked district's canonical name AND its state, so a
   *  click while zoomed out (Pan-India, many states rendered at once) can
   *  drill down into the right state, not just set a district name. */
  onSelectDistrict: (districtName: string, stateName: string) => void;
  /** Only the layer for the currently "active" state should steer the
   *  map's camera - when many states are rendered at once (nothing picked
   *  yet), none of them should fight over `flyToBounds`. */
  enableFitBounds: boolean;
}

export function DistrictLayer({
  stateName,
  features,
  districtRisk,
  selectedDistrict,
  onSelectDistrict,
  enableFitBounds,
}: DistrictLayerProps) {
  const collection: DistrictFeatureCollection = useMemo(
    () => ({ type: 'FeatureCollection', features }),
    [features]
  );

  const lookup = useMemo(() => {
    return (feature: DistrictFeature): DistrictRiskInfo & { rawName: string } | null => {
      const names = extractNames(feature);
      if (!names) return null;
      const canonical = canonicalDistrictName(names.district, names.state);
      const info = districtRisk.get(normalizeName(canonical));
      return { ...(info ?? { risk: 'none' as RiskLevel, siteCount: 0, canonicalName: canonical }), rawName: canonical };
    };
  }, [districtRisk]);

  // Re-key the layer whenever the risk coloring should change, so Leaflet
  // rebuilds styles/tooltips instead of reusing stale ones (react-leaflet's
  // GeoJSON only reacts to a handful of props automatically).
  const riskFingerprint = useMemo(
    () => Array.from(districtRisk.entries()).map(([name, info]) => `${name}:${info.risk}`).join('|'),
    [districtRisk]
  );

  // Dev-only sanity check: warn about any monitored district that never
  // matched a polygon in this state's boundary file, so a naming mismatch
  // (add it to DISTRICT_ALIASES in districtGeo.ts) is easy to spot instead
  // of silently rendering as an unremarkable gray "no data" district.
  useEffect(() => {
    if (!import.meta.env.DEV || features.length === 0) return;
    const matched = new Set(
      features.map((f) => {
        const names = extractNames(f);
        return names ? normalizeName(canonicalDistrictName(names.district, names.state)) : null;
      })
    );
    districtRisk.forEach((info, key) => {
      if (info.siteCount > 0 && !matched.has(key)) {
        // eslint-disable-next-line no-console
        console.warn(
          `[DistrictLayer] "${info.canonicalName}" has ${info.siteCount} monitored site(s) but didn't match any polygon in ${stateName}'s boundary file. Add an alias in src/pages/live-map/districtGeo.ts if this is a spelling mismatch.`
        );
      }
    });
  }, [features, districtRisk, stateName]);

  const style: StyleFunction<Record<string, unknown>> = (feature) => {
    if (!feature) return {};
    const info = lookup(feature as DistrictFeature);
    const isMonitored = (info?.siteCount ?? 0) > 0;
    const isSelected = !!selectedDistrict && info?.rawName === selectedDistrict;
    return {
      color: isSelected ? '#ffffff' : 'rgba(255,255,255,0.35)',
      weight: isSelected ? 3 : 1,
      fillColor: isMonitored ? RISK_COLOR[info!.risk] : NO_DATA_COLOR,
      fillOpacity: isSelected ? 0.85 : isMonitored ? 0.65 : 0.35,
    };
  };

  const onEachFeature = (feature: DistrictFeature, layer: Layer) => {
    const info = lookup(feature);
    if (!info) return;
    const label = info.siteCount > 0
      ? `<strong>${info.rawName}</strong><br/>${info.siteCount} monitored site${info.siteCount === 1 ? '' : 's'}`
      : `<strong>${info.rawName}</strong><br/>No monitored sites`;
    layer.bindTooltip(label, { sticky: true, direction: 'top' });
    layer.on('click', (e: LeafletMouseEvent) => {
      L.DomEvent.stopPropagation(e);
      onSelectDistrict(info.rawName, stateName);
    });
    layer.on('mouseover', () => (layer as L.Path).setStyle({ weight: 3 }));
    layer.on('mouseout', () => (layer as L.Path).setStyle({ weight: selectedDistrict === info.rawName ? 3 : 1 }));
  };

  return (
    <>
      <GeoJSON
        key={`${stateName}-${riskFingerprint}-${selectedDistrict ?? ''}`}
        data={collection}
        style={style}
        onEachFeature={onEachFeature}
      />
      {enableFitBounds && (
        <FitBoundsToState features={features} selectedDistrict={selectedDistrict} lookup={lookup} />
      )}
    </>
  );
}

/** Zooms/pans the map to the selected state's districts, and refines to a
 *  single district's bounds when one is selected (from either the dropdown
 *  filter or a click on the map itself - both flow through the same
 *  `selectedDistrict` value, which is what keeps the two in sync). */
function FitBoundsToState({
  features,
  selectedDistrict,
  lookup,
}: {
  features: DistrictFeature[];
  selectedDistrict: string | null;
  lookup: (feature: DistrictFeature) => (DistrictRiskInfo & { rawName: string }) | null;
}) {
  const map = useMap();

  useEffect(() => {
    if (features.length === 0) return;
    const focusFeature = selectedDistrict
      ? features.find((f) => lookup(f)?.rawName === selectedDistrict)
      : undefined;

    const target = focusFeature ? [focusFeature] : features;
    const bounds = L.geoJSON({ type: 'FeatureCollection', features: target } as GeoJSON.GeoJsonObject).getBounds();
    if (bounds.isValid()) {
      map.flyToBounds(bounds, { padding: [50, 50], duration: 0.6, maxZoom: focusFeature ? 10 : 8 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [features, selectedDistrict]);

  return null;
}
