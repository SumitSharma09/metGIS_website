import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import Divider from '@mui/material/Divider';
import SatelliteAltRoundedIcon from '@mui/icons-material/SatelliteAltRounded';
import MapRoundedIcon from '@mui/icons-material/MapRounded';
import Chip from '@mui/material/Chip';
import LockRoundedIcon from '@mui/icons-material/LockRounded';
import { useListStatesQuery, useListDistrictsQuery } from '@/features/sites/sitesApi';
import { useScopedStates } from '@/features/users/useScopedStates';
import { MAP_LAYERS, type MapLayer } from '../mapLayers';
import type { Basemap } from '../LiveMapPage';

interface MapControlsProps {
  state: string | null;
  onChangeState: (state: string | null) => void;
  district: string | null;
  onChangeDistrict: (district: string | null) => void;
  layer: MapLayer;
  onChangeLayer: (layer: MapLayer) => void;
  basemap: Basemap;
  onChangeBasemap: (basemap: Basemap) => void;
  showWind: boolean;
  onToggleWind: (show: boolean) => void;
}

export function MapControls({
  state,
  onChangeState,
  district,
  onChangeDistrict,
  layer,
  onChangeLayer,
  basemap,
  onChangeBasemap,
  showWind,
  onToggleWind,
}: MapControlsProps) {
  const { data: states = [] } = useListStatesQuery();
  const { data: districts = [] } = useListDistrictsQuery(state ?? undefined);
  const { isPanIndia, assignedStates } = useScopedStates();

  return (
    <Paper
      elevation={4}
      sx={{
        position: 'absolute',
        top: 12,
        left: 12,
        zIndex: 1000,
        p: 2,
        width: 280,
        maxHeight: 'calc(100% - 96px)',
        overflowY: 'auto',
        backgroundColor: 'background.paper',
        opacity: 0.97,
      }}
    >
      <Stack spacing={2}>
        <div>
          <Typography variant="caption" fontWeight={700} color="text.secondary">
            REGION
          </Typography>
          <Stack spacing={1.5} sx={{ mt: 1 }}>
            <Autocomplete
              size="small"
              options={states}
              value={state}
              onChange={(_e, value) => {
                onChangeState(value);
                onChangeDistrict(null);
              }}
              renderInput={(params) => <TextField {...params} label="State" />}
            />
            <Autocomplete
              size="small"
              options={districts}
              value={district}
              disabled={districts.length === 0}
              onChange={(_e, value) => onChangeDistrict(value)}
              renderInput={(params) => <TextField {...params} label="District" />}
            />
            <Typography variant="caption" color="text.secondary">
              Tip: click a district on the map to select it too.
            </Typography>
            {!isPanIndia && (
              <Chip
                size="small"
                variant="outlined"
                color="primary"
                icon={<LockRoundedIcon fontSize="small" />}
                label={`Scoped to: ${assignedStates.join(', ') || 'none assigned'}`}
                sx={{ alignSelf: 'flex-start' }}
              />
            )}
          </Stack>
        </div>

        <Divider />

        <div>
          <Typography variant="caption" fontWeight={700} color="text.secondary">
            PARAMETER LAYER
          </Typography>
          <ToggleButtonGroup
            size="small"
            exclusive
            value={layer}
            onChange={(_e, value: MapLayer | null) => value && onChangeLayer(value)}
            sx={{ mt: 1, flexWrap: 'wrap', gap: 0.5, '& .MuiToggleButtonGroup-grouped': { border: '1px solid', borderColor: 'divider', borderRadius: '8px !important' } }}
          >
            {MAP_LAYERS.map((item) => (
              <ToggleButton key={item.value} value={item.value} sx={{ px: 1.25 }}>
                {item.label}
              </ToggleButton>
            ))}
          </ToggleButtonGroup>
        </div>

        <Divider />

        <div>
          <Typography variant="caption" fontWeight={700} color="text.secondary">
            BASEMAP
          </Typography>
          <ToggleButtonGroup
            size="small"
            exclusive
            fullWidth
            value={basemap}
            onChange={(_e, value: Basemap | null) => value && onChangeBasemap(value)}
            sx={{ mt: 1 }}
          >
            <ToggleButton value="street">
              <MapRoundedIcon fontSize="small" sx={{ mr: 0.5 }} /> Street
            </ToggleButton>
            <ToggleButton value="satellite">
              <SatelliteAltRoundedIcon fontSize="small" sx={{ mr: 0.5 }} /> Satellite
            </ToggleButton>
          </ToggleButtonGroup>
        </div>

        <Divider />

        <FormControlLabel
          control={<Switch size="small" checked={showWind} onChange={(e) => onToggleWind(e.target.checked)} />}
          label={
            <Typography variant="body2">Wind flow overlay</Typography>
          }
        />
      </Stack>
    </Paper>
  );
}
