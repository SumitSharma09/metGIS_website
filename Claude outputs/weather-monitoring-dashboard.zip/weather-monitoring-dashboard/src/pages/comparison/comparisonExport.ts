import * as XLSX from 'xlsx';
import dayjs from 'dayjs';
import type { ComparisonRow } from './comparisonData';

const COLUMNS = ['Date', 'Site', 'Forecast Temp (°C)', 'Actual Temp (°C)', 'Forecast Rainfall (mm)', 'Actual Rainfall (mm)', 'Accuracy (%)'];

export function exportComparisonToExcel(rows: ComparisonRow[]) {
  const data = [
    COLUMNS,
    ...rows.map((r) => [r.date, r.siteName, r.forecastTemp, r.actualTemp, r.forecastRainfall, r.actualRainfall, r.accuracyPct]),
  ];
  const worksheet = XLSX.utils.aoa_to_sheet(data);
  worksheet['!cols'] = COLUMNS.map(() => ({ wch: 20 }));
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Forecast vs Actual');
  XLSX.writeFile(workbook, `forecast-vs-actual-${dayjs().format('YYYY-MM-DD')}.xlsx`);
}
