import axios, { AxiosError } from 'axios';
import { API_BASE_URL, AUTH_TOKEN_STORAGE_KEY } from '@/utils/constants';
import type { ApiError } from '@/types/common';

// Single axios instance used for every real backend call (mock mode bypasses
// this entirely - see src/api/queryHelpers.ts). Centralizing it here means
// auth headers, base URL and error shape only need to be handled once.
export const axiosClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 20000,
  headers: {
    'Content-Type': 'application/json',
  },
});

axiosClient.interceptors.request.use((config) => {
  const token = localStorage.getItem(AUTH_TOKEN_STORAGE_KEY);
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

axiosClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError<{ message?: string }>) => {
    const apiError: ApiError = {
      status: error.response?.status ?? 0,
      message: error.response?.data?.message ?? error.message ?? 'Unexpected network error',
    };

    if (apiError.status === 401) {
      // Token expired / invalid - clear local session. The auth slice's
      // subscription to storage (or a dispatched logout on next render)
      // takes care of redirecting to /login.
      localStorage.removeItem(AUTH_TOKEN_STORAGE_KEY);
    }

    return Promise.reject(apiError);
  }
);
