import type { Site } from '@/features/sites/types';

// Representative infrastructure sites spread across Indian telecom circles.
// Coordinates are approximate city centers, fine for map/demo purposes.
const RAW_SITES: Omit<Site, 'id'>[] = [
  { code: 'MUM-001', name: 'Bandra Kurla Complex', circle: 'Mumbai', state: 'Maharashtra', district: 'Mumbai Suburban', latitude: 19.0665, longitude: 72.8686, address: 'BKC, Bandra East, Mumbai', status: 'active', elevationMeters: 11, installedOn: '2019-03-12', contactPerson: 'Rahul Deshmukh', contactPhone: '+91 98200 11223', towerType: 'GBT' },
  { code: 'MUM-014', name: 'Andheri MIDC', circle: 'Mumbai', state: 'Maharashtra', district: 'Mumbai Suburban', latitude: 19.1197, longitude: 72.8697, address: 'MIDC, Andheri East, Mumbai', status: 'active', elevationMeters: 14, installedOn: '2018-07-04', contactPerson: 'Sneha Kulkarni', contactPhone: '+91 98200 44556', towerType: 'RTT' },
  { code: 'DEL-002', name: 'Connaught Place', circle: 'Delhi NCR', state: 'Delhi', district: 'New Delhi', latitude: 28.6315, longitude: 77.2167, address: 'Connaught Place, New Delhi', status: 'active', elevationMeters: 216, installedOn: '2017-11-20', contactPerson: 'Vikram Singh', contactPhone: '+91 98110 22334', towerType: 'GBT' },
  { code: 'DEL-019', name: 'Gurugram Cyber Hub', circle: 'Delhi NCR', state: 'Haryana', district: 'Gurugram', latitude: 28.4949, longitude: 77.0891, address: 'Cyber Hub, Gurugram', status: 'maintenance', elevationMeters: 227, installedOn: '2020-01-15', contactPerson: 'Anita Sharma', contactPhone: '+91 98110 55667', towerType: 'Monopole' },
  { code: 'BLR-003', name: 'Whitefield', circle: 'Bangalore', state: 'Karnataka', district: 'Bengaluru Urban', latitude: 12.9698, longitude: 77.7500, address: 'Whitefield, Bengaluru', status: 'active', elevationMeters: 902, installedOn: '2016-05-09', contactPerson: 'Manjunath Rao', contactPhone: '+91 98450 33445', towerType: 'GBT' },
  { code: 'BLR-021', name: 'Electronic City', circle: 'Bangalore', state: 'Karnataka', district: 'Bengaluru Urban', latitude: 12.8452, longitude: 77.6602, address: 'Electronic City Phase 1, Bengaluru', status: 'active', elevationMeters: 884, installedOn: '2021-02-27', contactPerson: 'Divya Reddy', contactPhone: '+91 98450 66778', towerType: 'RTT' },
  { code: 'CHN-004', name: 'OMR IT Corridor', circle: 'Chennai', state: 'Tamil Nadu', district: 'Chennai', latitude: 12.8996, longitude: 80.2270, address: 'OMR, Chennai', status: 'active', elevationMeters: 6, installedOn: '2015-09-18', contactPerson: 'Karthik Subramaniam', contactPhone: '+91 98840 11223', towerType: 'GBT' },
  { code: 'HYD-005', name: 'HITEC City', circle: 'Hyderabad', state: 'Telangana', district: 'Hyderabad', latitude: 17.4483, longitude: 78.3915, address: 'HITEC City, Hyderabad', status: 'active', elevationMeters: 536, installedOn: '2018-12-01', contactPerson: 'Srinivas Rao', contactPhone: '+91 98490 22335', towerType: 'Monopole' },
  { code: 'KOL-006', name: 'Salt Lake Sector V', circle: 'Kolkata', state: 'West Bengal', district: 'North 24 Parganas', latitude: 22.5726, longitude: 88.4310, address: 'Sector V, Salt Lake, Kolkata', status: 'active', elevationMeters: 9, installedOn: '2017-06-23', contactPerson: 'Sourav Banerjee', contactPhone: '+91 98300 33446', towerType: 'GBT' },
  { code: 'PUN-007', name: 'Hinjewadi Phase 2', circle: 'Pune', state: 'Maharashtra', district: 'Pune', latitude: 18.5908, longitude: 73.7397, address: 'Hinjewadi, Pune', status: 'active', elevationMeters: 560, installedOn: '2019-08-30', contactPerson: 'Prasad Joshi', contactPhone: '+91 98220 44557', towerType: 'RTT' },
  { code: 'AHM-008', name: 'SG Highway', circle: 'Ahmedabad', state: 'Gujarat', district: 'Ahmedabad', latitude: 23.0395, longitude: 72.5066, address: 'SG Highway, Ahmedabad', status: 'inactive', elevationMeters: 53, installedOn: '2014-04-11', contactPerson: 'Nirav Patel', contactPhone: '+91 98790 55668', towerType: 'GBT' },
  { code: 'JAI-009', name: 'Malviya Nagar', circle: 'Jaipur', state: 'Rajasthan', district: 'Jaipur', latitude: 26.8544, longitude: 75.8055, address: 'Malviya Nagar, Jaipur', status: 'active', elevationMeters: 431, installedOn: '2020-10-02', contactPerson: 'Rohit Agarwal', contactPhone: '+91 98290 66779', towerType: 'Monopole' },
  { code: 'LKO-010', name: 'Gomti Nagar', circle: 'Lucknow', state: 'Uttar Pradesh', district: 'Lucknow', latitude: 26.8467, longitude: 81.0331, address: 'Gomti Nagar, Lucknow', status: 'active', elevationMeters: 123, installedOn: '2016-01-19', contactPerson: 'Amit Verma', contactPhone: '+91 98390 77880', towerType: 'GBT' },
  { code: 'BHO-011', name: 'Arera Colony', circle: 'Bhopal', state: 'Madhya Pradesh', district: 'Bhopal', latitude: 23.2156, longitude: 77.4126, address: 'Arera Colony, Bhopal', status: 'active', elevationMeters: 527, installedOn: '2018-03-28', contactPerson: 'Deepak Chouhan', contactPhone: '+91 98262 88991', towerType: 'RTT' },
  { code: 'PAT-012', name: 'Boring Road', circle: 'Patna', state: 'Bihar', district: 'Patna', latitude: 25.6127, longitude: 85.1197, address: 'Boring Road, Patna', status: 'maintenance', elevationMeters: 53, installedOn: '2015-12-07', contactPerson: 'Rajesh Kumar', contactPhone: '+91 98350 99002', towerType: 'GBT' },
  { code: 'GUW-013', name: 'Ganeshguri', circle: 'Guwahati', state: 'Assam', district: 'Kamrup Metropolitan', latitude: 26.1584, longitude: 91.7896, address: 'Ganeshguri, Guwahati', status: 'active', elevationMeters: 55, installedOn: '2019-05-14', contactPerson: 'Bikash Bora', contactPhone: '+91 98640 10112', towerType: 'Monopole' },
  { code: 'CHD-015', name: 'Sector 17', circle: 'Chandigarh', state: 'Chandigarh', district: 'Chandigarh', latitude: 30.7410, longitude: 76.7822, address: 'Sector 17, Chandigarh', status: 'active', elevationMeters: 321, installedOn: '2017-02-08', contactPerson: 'Harpreet Singh', contactPhone: '+91 98150 21123', towerType: 'GBT' },
  { code: 'KOC-016', name: 'Infopark Kakkanad', circle: 'Kochi', state: 'Kerala', district: 'Ernakulam', latitude: 10.0159, longitude: 76.3419, address: 'Infopark, Kochi', status: 'active', elevationMeters: 8, installedOn: '2021-06-25', contactPerson: 'Anoop Menon', contactPhone: '+91 98470 32234', towerType: 'RTT' },
  { code: 'IND-017', name: 'Vijay Nagar', circle: 'Indore', state: 'Madhya Pradesh', district: 'Indore', latitude: 22.7533, longitude: 75.8937, address: 'Vijay Nagar, Indore', status: 'active', elevationMeters: 553, installedOn: '2016-09-16', contactPerson: 'Sanjay Malhotra', contactPhone: '+91 98261 43345', towerType: 'GBT' },
  { code: 'NAG-018', name: 'Civil Lines', circle: 'Nagpur', state: 'Maharashtra', district: 'Nagpur', latitude: 21.1544, longitude: 79.0821, address: 'Civil Lines, Nagpur', status: 'active', elevationMeters: 310, installedOn: '2020-04-04', contactPerson: 'Pooja Deshpande', contactPhone: '+91 98220 54456', towerType: 'Monopole' },
];

export const sites: Site[] = RAW_SITES.map((site, index) => ({
  id: `site-${index + 1}`,
  ...site,
}));

export const getSiteById = (id: string): Site | undefined => sites.find((s) => s.id === id);

export const circles: string[] = Array.from(new Set(sites.map((s) => s.circle))).sort();

export const states: string[] = Array.from(new Set(sites.map((s) => s.state))).sort();

export const districtsForState = (state?: string): string[] =>
  Array.from(new Set(sites.filter((s) => !state || s.state === state).map((s) => s.district))).sort();

export const sitesForScope = (state?: string, district?: string): Site[] =>
  sites.filter((s) => (!state || s.state === state) && (!district || s.district === district));
