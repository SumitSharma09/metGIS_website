import dayjs from 'dayjs';
import type { UserProfile } from '@/features/users/types';

export const demoUsers: (UserProfile & { password: string })[] = [
  {
    id: 'user-1',
    username: 'admin',
    password: 'admin123',
    fullName: 'Sumit Sharma',
    email: 'sumit.javadeveloper09@gmail.com',
    phone: '+91 98200 12345',
    role: 'admin',
    designation: 'Network Operations Manager',
    lastLoginAt: dayjs().subtract(2, 'hour').toISOString(),
    assignedStates: [], // Pan-India
  },
  {
    id: 'user-2',
    username: 'operator',
    password: 'operator123',
    fullName: 'Priya Nair',
    email: 'priya.nair@example.com',
    phone: '+91 98450 67890',
    role: 'operator',
    designation: 'Field Operations Executive',
    lastLoginAt: dayjs().subtract(1, 'day').toISOString(),
    // Mirrors the Spring Boot DataSeeder's seeded operator scope.
    assignedStates: ['Delhi', 'Haryana'],
  },
  {
    id: 'user-3',
    username: 'viewer',
    password: 'viewer123',
    fullName: 'Arjun Mehta',
    email: 'arjun.mehta@example.com',
    phone: '+91 98110 45678',
    role: 'viewer',
    designation: 'Regional Analyst',
    lastLoginAt: dayjs().subtract(5, 'day').toISOString(),
    // Mirrors the Spring Boot DataSeeder's seeded viewer scope.
    assignedStates: ['Karnataka'],
  },
];

export const findUserByCredentials = (username: string, password: string) =>
  demoUsers.find((u) => u.username === username && u.password === password);

export const findUserById = (id: string) => demoUsers.find((u) => u.id === id);
