import dayjs from 'dayjs';
import { getSiteById } from './sites';
import { hashStringToSeed, seededRandom, randomInRange, pick } from '../rng';
import type { CurrentObservation, ForecastDay, HistoricalPoint, WeatherCondition } from '@/features/weather/types';

const CONDITIONS: WeatherCondition[] = ['clear', 'partly-cloudy', 'cloudy', 'rain', 'thunderstorm', 'fog', 'windy'];

/** Base temperature (deg C) skewed by latitude: sites nearer the equator run warmer. */
function baseTemperatureFor(siteId: string): number {
  const site = getSiteById(siteId);
  if (!site) return 27;
  const latitudeFactor = Math.max(0, 30 - Math.abs(site.latitude)); // 0..30
  return 22 + latitudeFactor * 0.35; // roughly 22-32 base
}

/** Is `date` within the Indian monsoon window (June - September)? */
function isMonsoonSeason(date: dayjs.Dayjs): boolean {
  const month = date.month() + 1; // 1-12
  return month >= 6 && month <= 9;
}

function conditionFromRainfall(rainfall: number, windSpeed: number, rand: () => number): WeatherCondition {
  if (rainfall > 12) return 'thunderstorm';
  if (rainfall > 2) return 'rain';
  if (windSpeed > 35) return 'windy';
  return pick(rand, ['clear', 'partly-cloudy', 'cloudy', 'clear', 'fog'] as WeatherCondition[]);
}

export function generateObservationAt(siteId: string, at: dayjs.Dayjs): CurrentObservation {
  const seed = hashStringToSeed(`${siteId}-${at.format('YYYY-MM-DD-HH')}`);
  const rand = seededRandom(seed);
  const base = baseTemperatureFor(siteId);

  const hour = at.hour();
  const dailyCycle = Math.sin(((hour - 6) / 24) * Math.PI * 2) * 5; // peak mid-afternoon
  const temperature = base + dailyCycle + randomInRange(rand, -1.5, 1.5);

  const monsoon = isMonsoonSeason(at);
  const rainChance = monsoon ? 0.55 : 0.12;
  const isRaining = rand() < rainChance;
  const rainfallLastHour = isRaining ? randomInRange(rand, 0.5, monsoon ? 28 : 10) : 0;
  const rainfallToday = rainfallLastHour * randomInRange(rand, 1.5, 4.5);

  const windSpeed = randomInRange(rand, 4, monsoon ? 45 : 28);
  const windGust = windSpeed + randomInRange(rand, 2, 18);
  const humidity = monsoon
    ? randomInRange(rand, 65, 95)
    : randomInRange(rand, 30, 70);
  const pressure = randomInRange(rand, 1000, 1018);
  const lightning = isRaining && rand() > 0.5 ? Math.round(randomInRange(rand, 1, 40)) : 0;

  return {
    siteId,
    timestamp: at.toISOString(),
    temperature: Number(temperature.toFixed(1)),
    feelsLike: Number((temperature + randomInRange(rand, -1, 3)).toFixed(1)),
    humidity: Number(humidity.toFixed(0)),
    rainfallLastHour: Number(rainfallLastHour.toFixed(1)),
    rainfallToday: Number(rainfallToday.toFixed(1)),
    windSpeed: Number(windSpeed.toFixed(1)),
    windGust: Number(windGust.toFixed(1)),
    windDirection: Math.round(randomInRange(rand, 0, 359)),
    pressure: Number(pressure.toFixed(0)),
    lightningStrikesLastHour: lightning,
    condition: conditionFromRainfall(rainfallLastHour, windSpeed, rand),
    visibilityKm: Number(randomInRange(rand, isRaining ? 1 : 5, 12).toFixed(1)),
  };
}

export function getCurrentObservation(siteId: string): CurrentObservation {
  return generateObservationAt(siteId, dayjs());
}

export function getHistoricalSeries(
  siteId: string,
  from: string,
  to: string,
  interval: 'hourly' | 'daily' = 'hourly'
): HistoricalPoint[] {
  const start = dayjs(from);
  const end = dayjs(to);
  const stepUnit = interval === 'hourly' ? 'hour' : 'day';
  const stepAmount = 1;
  const points: HistoricalPoint[] = [];

  let cursor = start;
  let guard = 0;
  while ((cursor.isBefore(end) || cursor.isSame(end)) && guard < 2000) {
    const obs = generateObservationAt(siteId, cursor);
    points.push({
      timestamp: obs.timestamp,
      temperature: obs.temperature,
      humidity: obs.humidity,
      rainfall: obs.rainfallLastHour,
      windSpeed: obs.windSpeed,
      pressure: obs.pressure,
      lightningStrikes: obs.lightningStrikesLastHour,
    });
    cursor = cursor.add(stepAmount, stepUnit);
    guard += 1;
  }
  return points;
}

function forecastDay(siteId: string, date: dayjs.Dayjs, seedKey: string): ForecastDay {
  const seed = hashStringToSeed(`${siteId}-forecast-${seedKey}`);
  const rand = seededRandom(seed);
  const base = baseTemperatureFor(siteId);
  const monsoon = isMonsoonSeason(date);
  const minTemp = base - randomInRange(rand, 3, 6);
  const maxTemp = base + randomInRange(rand, 3, 7);
  const rainfallProbability = Math.round(monsoon ? randomInRange(rand, 40, 90) : randomInRange(rand, 5, 35));
  const expectedRainfallMm = rainfallProbability > 50 ? randomInRange(rand, 5, 60) : randomInRange(rand, 0, 4);
  const windSpeed = randomInRange(rand, 6, monsoon ? 38 : 22);
  const condition = conditionFromRainfall(expectedRainfallMm, windSpeed, rand);

  return {
    date: date.format('YYYY-MM-DD'),
    minTemp: Number(minTemp.toFixed(1)),
    maxTemp: Number(maxTemp.toFixed(1)),
    rainfallProbability,
    expectedRainfallMm: Number(expectedRainfallMm.toFixed(1)),
    windSpeed: Number(windSpeed.toFixed(1)),
    condition,
    summary: summaryFor(condition, rainfallProbability),
  };
}

export function getForecast(siteId: string, days = 7): ForecastDay[] {
  const result: ForecastDay[] = [];
  for (let i = 0; i < days; i += 1) {
    const date = dayjs().add(i, 'day');
    result.push(forecastDay(siteId, date, date.format('YYYY-MM-DD')));
  }
  return result;
}

/**
 * Same synthetic model as `getForecast`, but lets the caller pin the
 * "as-of" day the run was issued on, independent of today's real date.
 * Two calls for the same `targetDate` but different `issuedDate` values
 * deterministically diverge - modeling how a forecast model's output for a
 * given day changes as new runs come in on approach to that day. Mirrors
 * the backend's `WeatherGenerator.forecastAsOf` (see DeviationService)
 * and is what src/api/mock/data/deviations.ts diffs successive runs with.
 */
export function forecastAsOf(siteId: string, targetDate: dayjs.Dayjs, issuedDate: dayjs.Dayjs): ForecastDay {
  const targetKey = targetDate.format('YYYY-MM-DD');
  const issuedKey = issuedDate.format('YYYY-MM-DD');
  return forecastDay(siteId, targetDate, `${targetKey}-asof-${issuedKey}`);
}

function summaryFor(condition: WeatherCondition, rainfallProbability: number): string {
  switch (condition) {
    case 'thunderstorm':
      return `Thunderstorms likely, ${rainfallProbability}% chance of rain`;
    case 'rain':
      return `Rain expected, ${rainfallProbability}% chance`;
    case 'windy':
      return 'Strong winds expected';
    case 'fog':
      return 'Foggy conditions in the morning';
    case 'cloudy':
      return 'Overcast through the day';
    case 'partly-cloudy':
      return 'Partly cloudy skies';
    default:
      return 'Clear skies expected';
  }
}

export { CONDITIONS };
