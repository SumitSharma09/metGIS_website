import type { Site } from '@/features/sites/types';
import type { CurrentObservation } from '@/features/weather/types';
import { worseRisk, type RiskLevel } from './severity';

/** Lowercase, trim, and collapse whitespace/punctuation so names like
 *  "North  24-Parganas" and "North 24 Parganas" compare equal. Shared by
 *  every place that keys a lookup by district (or state) name: the Live
 *  Map's district-boundary matching, and the district-level risk
 *  aggregation below. */
export function normalizeName(name: string): string {
  return name
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '') // strip diacritics
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

export interface DistrictRiskInfo {
  risk: RiskLevel;
  siteCount: number;
  canonicalName: string;
}

/**
 * Aggregates a set of sites' observations into one risk level per district
 * - a district's risk is the worst risk among its monitored sites, under
 * whatever `riskFn` the caller wants (a single parameter, an aggregate
 * "overall" risk, or a synthetic hazard like flood/snowfall/avalanche).
 * Shared by the Live Map's district choropleth and the Hazards page's
 * flood map / risk-intensity tables so they never disagree about how
 * "district risk" is computed.
 */
export function buildDistrictRiskIndex(
  sites: Site[],
  obsBySiteId: Record<string, CurrentObservation>,
  riskFn: (site: Site, obs: CurrentObservation) => RiskLevel
): Map<string, DistrictRiskInfo> {
  const map = new Map<string, DistrictRiskInfo>();
  sites.forEach((site) => {
    const obs = obsBySiteId[site.id];
    if (!obs) return;
    const risk = riskFn(site, obs);
    const key = normalizeName(site.district);
    const prev = map.get(key);
    map.set(
      key,
      prev
        ? { risk: worseRisk(prev.risk, risk), siteCount: prev.siteCount + 1, canonicalName: prev.canonicalName }
        : { risk, siteCount: 1, canonicalName: site.district }
    );
  });
  return map;
}
