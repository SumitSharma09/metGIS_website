import type { WeatherParameter } from './constants';
import type { WeatherCondition } from '@/features/weather/types';

/**
 * Four-band risk classification used across the Live Map legend, the
 * Alerts feed, and the Tower Risk Reports page. The same four bands are
 * labeled differently depending on context (the map calls them
 * "Warning/Alert/Watch/No warning"; risk reports call them
 * "Extreme/High/Moderate/Normal") but represent the same severity scale.
 */
export type RiskLevel = 'none' | 'watch' | 'alert' | 'warning';

export const RISK_LEVELS: RiskLevel[] = ['warning', 'alert', 'watch', 'none'];

export const MAP_RISK_LABEL: Record<RiskLevel, string> = {
  warning: 'Warning',
  alert: 'Alert',
  watch: 'Watch',
  none: 'No warning',
};

export const REPORT_RISK_LABEL: Record<RiskLevel, string> = {
  warning: 'Extreme',
  alert: 'High',
  watch: 'Moderate',
  none: 'Normal',
};

export const RISK_COLOR: Record<RiskLevel, string> = {
  warning: '#dc2626',
  alert: '#f97316',
  watch: '#eab308',
  none: '#16a34a',
};

/** Neutral fill used for map regions (districts) with no monitored sites -
 *  distinct from any risk color so "no data" is never mistaken for "safe". */
export const NO_DATA_COLOR = '#5b6472';

/** Ordinal rank of each risk band, low to high, used to combine risk levels
 *  (e.g. a district's overall risk = the worst risk among its sites). */
export const RISK_RANK: Record<RiskLevel, number> = { none: 0, watch: 1, alert: 2, warning: 3 };

/** The more severe of two risk levels. */
export function worseRisk(a: RiskLevel, b: RiskLevel): RiskLevel {
  return RISK_RANK[a] >= RISK_RANK[b] ? a : b;
}

interface Band {
  min: number;
  level: RiskLevel;
}

// Each list is checked from the highest threshold down; the first band whose
// `min` the value meets or exceeds wins. Tuned to be broadly representative
// (not sourced from any proprietary threshold table).
const BANDS: Record<WeatherParameter, Band[]> = {
  temperature: [
    { min: 45, level: 'warning' },
    { min: 40, level: 'alert' },
    { min: 35, level: 'watch' },
    { min: -Infinity, level: 'none' },
  ],
  rainfall: [
    { min: 40, level: 'warning' },
    { min: 20, level: 'alert' },
    { min: 10, level: 'watch' },
    { min: -Infinity, level: 'none' },
  ],
  windSpeed: [
    { min: 60, level: 'warning' },
    { min: 40, level: 'alert' },
    { min: 30, level: 'watch' },
    { min: -Infinity, level: 'none' },
  ],
  humidity: [
    { min: 95, level: 'warning' },
    { min: 90, level: 'alert' },
    { min: 80, level: 'watch' },
    { min: -Infinity, level: 'none' },
  ],
  // Pressure risk rises as the value *drops*, the opposite direction from
  // every other parameter, so it's handled as a special case in
  // getParameterRisk() below rather than fitting the "min" band shape here.
  pressure: [],
  lightning: [
    { min: 20, level: 'warning' },
    { min: 10, level: 'alert' },
    { min: 1, level: 'watch' },
    { min: -Infinity, level: 'none' },
  ],
  windDirection: [{ min: -Infinity, level: 'none' }],
};

export function getParameterRisk(parameter: WeatherParameter, value: number): RiskLevel {
  if (parameter === 'pressure') {
    if (value < 990) return 'warning';
    if (value < 995) return 'alert';
    if (value < 1000) return 'watch';
    return 'none';
  }
  const bands = BANDS[parameter] ?? [];
  for (const band of bands) {
    if (value >= band.min) return band.level;
  }
  return 'none';
}

/** Synthetic cloud-cover percentage derived from the observed condition
 *  (the mock weather generator doesn't track cloud % directly). */
export function estimateCloudCoverPercent(condition: WeatherCondition): number {
  const map: Record<WeatherCondition, number> = {
    clear: 8,
    'partly-cloudy': 40,
    cloudy: 75,
    rain: 85,
    thunderstorm: 95,
    fog: 60,
    windy: 30,
  };
  return map[condition];
}

export function getCloudRisk(condition: WeatherCondition): RiskLevel {
  const pct = estimateCloudCoverPercent(condition);
  if (pct >= 90) return 'warning';
  if (pct >= 70) return 'alert';
  if (pct >= 40) return 'watch';
  return 'none';
}

export function getVisibilityRisk(visibilityKm: number): RiskLevel {
  if (visibilityKm < 1) return 'warning';
  if (visibilityKm < 2) return 'alert';
  if (visibilityKm < 4) return 'watch';
  return 'none';
}

/** Synthetic snowfall risk: our sites/observations don't model snow
 *  accumulation directly, so this proxies it from elevation + temperature
 *  (snow needs both altitude and cold). Every current demo site is a
 *  lowland/mid-elevation city tower, so this will read "none" for all of
 *  them today - it's here so the hazard toggle and thresholds exist and
 *  light up correctly once a high-Himalaya site is added to the network. */
export function getSnowfallRisk(elevationMeters: number, temperatureC: number): RiskLevel {
  if (elevationMeters < 1500 || temperatureC > 4) return 'none';
  if (temperatureC <= -8) return 'warning';
  if (temperatureC <= -2) return 'alert';
  if (temperatureC <= 2) return 'watch';
  return 'none';
}

/** Synthetic avalanche risk: proxies the classic "steep, cold, windy
 *  high-altitude slope" combination from elevation + temperature + wind
 *  speed, since slope angle and snowpack aren't modeled. Same caveat as
 *  snowfall above - none of today's demo sites sit at avalanche-relevant
 *  elevations. */
export function getAvalancheRisk(elevationMeters: number, temperatureC: number, windSpeedKmph: number): RiskLevel {
  const snow = getSnowfallRisk(elevationMeters, temperatureC);
  if (snow === 'none' || elevationMeters < 2000) return 'none';
  const windBoost = windSpeedKmph > 40 ? 1 : windSpeedKmph > 20 ? 0.5 : 0;
  const score = RISK_RANK[snow] + windBoost;
  if (score >= 3.5) return 'warning';
  if (score >= 2.5) return 'alert';
  if (score >= 1) return 'watch';
  return 'none';
}
