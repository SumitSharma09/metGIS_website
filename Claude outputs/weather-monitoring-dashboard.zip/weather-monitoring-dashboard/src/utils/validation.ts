import { z } from 'zod';

export const loginSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  rememberMe: z.boolean().optional(),
});
export type LoginFormValues = z.infer<typeof loginSchema>;

export const profileSchema = z.object({
  fullName: z.string().min(2, 'Full name is required'),
  email: z.string().email('Enter a valid email address'),
  phone: z
    .string()
    .regex(/^[0-9+\-\s]{7,15}$/, 'Enter a valid phone number')
    .optional()
    .or(z.literal('')),
  designation: z.string().optional(),
});
export type ProfileFormValues = z.infer<typeof profileSchema>;

export const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, 'Current password is required'),
    newPassword: z.string().min(8, 'New password must be at least 8 characters'),
    confirmPassword: z.string().min(1, 'Please confirm the new password'),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });
export type ChangePasswordFormValues = z.infer<typeof changePasswordSchema>;

export const reportRequestSchema = z.object({
  title: z.string().min(3, 'Title is required'),
  siteIds: z.array(z.string()).min(1, 'Select at least one site'),
  parameters: z.array(z.string()).min(1, 'Select at least one parameter'),
  dateFrom: z.string().min(1, 'Start date is required'),
  dateTo: z.string().min(1, 'End date is required'),
  format: z.enum(['pdf', 'csv', 'xlsx']),
});
export type ReportRequestFormValues = z.infer<typeof reportRequestSchema>;
