import ReactApexChart from 'react-apexcharts';
import type { ApexOptions } from 'apexcharts';
import { useTheme } from '@mui/material/styles';

interface DonutChartProps {
  labels: string[];
  series: number[];
  colors: string[];
  height?: number;
}

export function DonutChart({ labels, series, colors, height = 260 }: DonutChartProps) {
  const theme = useTheme();
  const options: ApexOptions = {
    chart: { foreColor: theme.palette.text.secondary, fontFamily: theme.typography.fontFamily },
    labels,
    colors,
    legend: { position: 'bottom', fontSize: '12px' },
    dataLabels: { enabled: false },
    stroke: { width: 0 },
    plotOptions: {
      pie: {
        donut: {
          size: '70%',
          labels: {
            show: true,
            total: { show: true, label: 'Total', fontSize: '13px' },
          },
        },
      },
    },
  };

  return <ReactApexChart options={options} series={series} type="donut" height={height} />;
}
