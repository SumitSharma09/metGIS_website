import dayjs from 'dayjs';
import { apiSlice } from '@/api/apiSlice';
import { restRequest, isMockMode, currentMockUser } from '@/api/queryHelpers';
import { mockResponse } from '@/api/mock/db';
import { getCurrentObservation, getHistoricalSeries, getForecast, generateObservationAt } from '@/api/mock/data/weather';
import { sites, getSiteById } from '@/api/mock/data/sites';
import { canAccessState, restrictSites } from '@/utils/accessScope';
import type { CurrentObservation, ForecastDay, ForecastQuery, HistoricalPoint, HistoricalQuery } from './types';

/**
 * REST contract:
 *   GET /weather/current?siteIds=id1,id2      -> CurrentObservation[]   (all sites if omitted)
 *   GET /weather/current/:siteId              -> CurrentObservation
 *   GET /weather/current?siteIds=&at=<iso>     -> CurrentObservation[]  (observation snapshot at a point in
 *                                                 time - past or forecast - used by the Live Map timeline
 *                                                 scrubber and the Comparison page)
 *   GET /weather/historical?siteId=&from=&to=&interval=hourly|daily -> HistoricalPoint[]
 *   GET /weather/forecast/:siteId?days=7      -> ForecastDay[]
 */
export const weatherApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getCurrentObservations: builder.query<CurrentObservation[], string[] | void>({
      queryFn: async (siteIds, api) => {
        if (isMockMode) {
          const user = currentMockUser(api);
          // RBAC: "all sites" only ever means "all sites in scope"; a
          // caller naming specific IDs only gets back the in-scope ones.
          const ids = siteIds && siteIds.length
            ? siteIds.filter((id) => canAccessState(user, getSiteById(id)?.state))
            : restrictSites(user, sites).map((s) => s.id);
          const data = await mockResponse(ids.map((id) => getCurrentObservation(id)));
          return { data };
        }
        return restRequest<CurrentObservation[]>({
          url: '/weather/current',
          params: siteIds ? { siteIds: siteIds.join(',') } : undefined,
        });
      },
    }),
    getCurrentObservationBySite: builder.query<CurrentObservation, string>({
      queryFn: async (siteId, api) => {
        if (isMockMode) {
          if (!canAccessState(currentMockUser(api), getSiteById(siteId)?.state)) {
            return { error: { status: 404, message: 'Site not found' } };
          }
          const data = await mockResponse(getCurrentObservation(siteId));
          return { data };
        }
        return restRequest<CurrentObservation>({ url: `/weather/current/${siteId}` });
      },
    }),
    getObservationsAtTime: builder.query<CurrentObservation[], { siteIds?: string[]; at: string }>({
      queryFn: async ({ siteIds, at }, api) => {
        if (isMockMode) {
          const user = currentMockUser(api);
          const ids = siteIds && siteIds.length
            ? siteIds.filter((id) => canAccessState(user, getSiteById(id)?.state))
            : restrictSites(user, sites).map((s) => s.id);
          const data = await mockResponse(ids.map((id) => generateObservationAt(id, dayjs(at))));
          return { data };
        }
        return restRequest<CurrentObservation[]>({
          url: '/weather/current',
          params: { siteIds: siteIds?.join(','), at },
        });
      },
    }),
    getHistoricalData: builder.query<HistoricalPoint[], HistoricalQuery>({
      queryFn: async ({ siteId, from, to, interval }, api) => {
        if (isMockMode) {
          if (!canAccessState(currentMockUser(api), getSiteById(siteId)?.state)) {
            return { error: { status: 404, message: 'Site not found' } };
          }
          const data = await mockResponse(getHistoricalSeries(siteId, from, to, interval));
          return { data };
        }
        return restRequest<HistoricalPoint[]>({
          url: '/weather/historical',
          params: { siteId, from, to, interval },
        });
      },
    }),
    getForecast: builder.query<ForecastDay[], ForecastQuery>({
      queryFn: async ({ siteId, days }, api) => {
        if (isMockMode) {
          if (!canAccessState(currentMockUser(api), getSiteById(siteId)?.state)) {
            return { error: { status: 404, message: 'Site not found' } };
          }
          const data = await mockResponse(getForecast(siteId, days));
          return { data };
        }
        return restRequest<ForecastDay[]>({ url: `/weather/forecast/${siteId}`, params: { days } });
      },
    }),
  }),
});

export const {
  useGetCurrentObservationsQuery,
  useGetCurrentObservationBySiteQuery,
  useGetObservationsAtTimeQuery,
  useGetHistoricalDataQuery,
  useGetForecastQuery,
} = weatherApi;
