export type WeatherCondition =
  | 'clear'
  | 'partly-cloudy'
  | 'cloudy'
  | 'rain'
  | 'thunderstorm'
  | 'fog'
  | 'windy';

export interface CurrentObservation {
  siteId: string;
  timestamp: string; // ISO datetime
  temperature: number; // deg C
  feelsLike: number;
  humidity: number; // %
  rainfallLastHour: number; // mm
  rainfallToday: number; // mm
  windSpeed: number; // km/h
  windGust: number; // km/h
  windDirection: number; // degrees 0-359
  pressure: number; // hPa
  lightningStrikesLastHour: number;
  condition: WeatherCondition;
  visibilityKm: number;
}

export interface HistoricalPoint {
  timestamp: string;
  temperature: number;
  humidity: number;
  rainfall: number;
  windSpeed: number;
  pressure: number;
  lightningStrikes: number;
}

export interface HistoricalQuery {
  siteId: string;
  from: string; // ISO date
  to: string; // ISO date
  interval?: 'hourly' | 'daily';
}

export interface ForecastDay {
  date: string; // ISO date
  minTemp: number;
  maxTemp: number;
  rainfallProbability: number; // %
  expectedRainfallMm: number;
  windSpeed: number;
  condition: WeatherCondition;
  summary: string;
}

export interface ForecastQuery {
  siteId: string;
  days?: number;
}
