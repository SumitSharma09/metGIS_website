import { apiSlice } from '@/api/apiSlice';
import { restRequest, isMockMode } from '@/api/queryHelpers';
import { mockResponse, mockError, delay } from '@/api/mock/db';
import { findUserByCredentials } from '@/api/mock/data/users';
import type { LoginPayload, LoginResponse } from './types';

/**
 * REST contract (used once VITE_USE_MOCK_API=false):
 *   POST /auth/login   { username, password }        -> { token, user }
 *   POST /auth/logout  (Authorization header only)    -> 204
 */
export const authApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    login: builder.mutation<LoginResponse, LoginPayload>({
      queryFn: async (payload) => {
        if (isMockMode) {
          const user = findUserByCredentials(payload.username, payload.password);
          if (!user) {
            try {
              await mockError(401, 'Invalid username or password');
            } catch (error) {
              return { error: error as { status: number; message: string } };
            }
          }
          const { password: _password, ...profile } = user!;
          const data = await mockResponse<LoginResponse>({
            token: `mock-token-${profile.id}-${Date.now()}`,
            user: profile,
          });
          return { data };
        }
        return restRequest<LoginResponse>({ url: '/auth/login', method: 'POST', data: payload });
      },
    }),
    logout: builder.mutation<void, void>({
      queryFn: async () => {
        if (isMockMode) {
          await delay(150);
          return { data: undefined };
        }
        return restRequest<void>({ url: '/auth/logout', method: 'POST' });
      },
    }),
  }),
});

export const { useLoginMutation, useLogoutMutation } = authApi;
