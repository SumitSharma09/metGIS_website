export type UserRole = 'admin' | 'operator' | 'viewer';

export interface UserProfile {
  id: string;
  username: string;
  fullName: string;
  email: string;
  phone: string;
  role: UserRole;
  designation: string;
  avatarUrl?: string;
  lastLoginAt: string;
  /**
   * States this user is restricted to (scope doc section 5, RBAC by
   * state/circle/district). An 'admin' is always Pan-India regardless of
   * this list; for 'operator'/'viewer' it's the exact set that should
   * narrow every state dropdown and, on the mock backend, every list of
   * sites/alerts/reports. Undefined/empty means unrestricted.
   */
  assignedStates?: string[];
}
