# WeatherOps Backend (Spring Boot)

A Spring Boot REST API implementing the exact contract the `weather-monitoring-dashboard`
frontend expects (see the frontend's `README.md#api-contract` and each `src/features/*/types.ts`).
Point the frontend at this backend and flip `VITE_USE_MOCK_API=false` and every screen —
Live Map, Alerts, Reports, Comparison, auth, profile — works against real data.

## Tech stack

- Java 17, Spring Boot 3.3 (Web, Data JPA, Security, Validation)
- H2 in-memory database for dev (swap to MySQL/PostgreSQL for anything persistent — see below)
- JWT auth (`jjwt`), stateless sessions, BCrypt password hashing
- Maven

## Running it

Requires JDK 17+ and Maven (or use the included wrapper if you generate one via `mvn -N io.takari:maven:wrapper`).

```bash
cd backend
mvn spring-boot:run
```

The API starts on `http://localhost:8080`. On first boot, `DataSeeder` populates the H2
database with the same ~20 representative sites as the frontend's mock layer (across
Indian states/districts), three demo users, and a batch of sample alerts/reports — so
there's no separate data-loading step.

Demo login (matches the frontend's mock credentials):

| Role     | Username  | Password      |
|----------|-----------|---------------|
| Admin    | `admin`   | `admin123`    |
| Operator | `operator`| `operator123` |
| Viewer   | `viewer`  | `viewer123`   |

`POST /auth/login` returns `{ token, user }`; send `Authorization: Bearer <token>` on every
other request (the frontend's `axiosClient` already does this once `VITE_USE_MOCK_API=false`).

H2's web console is available at `http://localhost:8080/h2-console` (JDBC URL
`jdbc:h2:mem:weatherops`, user `sa`, empty password) — handy for poking at seeded data.

> **Note on this deliverable:** this project was authored in an environment without
> Maven Central / package-registry access, so `mvn` has not been run here. The code
> targets current, stable APIs for Spring Boot 3.3 / jjwt 0.12 / H2, but please run
> `mvn spring-boot:run` (or `mvn test`) as your first step and let us know if a dependency
> version needs adjusting.

## Configuration

All of this lives in `src/main/resources/application.yml`:

- `spring.datasource.*` — the H2 connection; see the comment there for switching to
  MySQL/PostgreSQL (add the driver dependency to `pom.xml`, change the URL/driver/creds —
  no application code changes needed, since everything goes through Spring Data JPA
  repositories against the entities in `domain/`).
- `app.cors.allowed-origins` — comma-separated list; defaults to the Vite dev server
  (`http://localhost:5173`). Add your deployed frontend origin(s) here.
- `app.jwt.secret` / `app.jwt.expiration-minutes` — override `JWT_SECRET` via an
  environment variable in any real deployment; never commit a real secret.

## Project structure

```
src/main/java/com/weatherops/backend/
  config/        SecurityConfig (JWT filter chain, CORS, password encoder)
  security/      JwtService, JwtAuthFilter, UserPrincipal, AppUserDetailsService
  domain/        JPA entities (Site, User, AlertItem, ReportItem) + enums
  repository/    Spring Data JPA repositories
  dto/           Request/response DTOs, one package per feature area
  service/       Business logic per feature area (mirrors the frontend's features/*)
  controller/    REST controllers - one per feature area, matching the documented contract
  weather/       WeatherGenerator - deterministic synthetic observations/forecast
                 (the backend's equivalent of the frontend's src/api/mock/data/weather.ts)
  seed/          DataSeeder - populates H2 with sites/users/alerts/reports on first boot
```

## Endpoints implemented

Auth: `POST /auth/login`, `POST /auth/logout`
Users: `GET /users`, `GET /users/:id`, `PUT /users/:id`, `POST /users/:id/change-password`
Sites: `GET /sites`, `GET /sites/:id`, `GET /sites/circles`, `GET /sites/states`, `GET /sites/districts`
Weather: `GET /weather/current`, `GET /weather/current/:siteId`, `GET /weather/historical`, `GET /weather/forecast/:siteId`
Alerts: `GET /alerts`, `GET /alerts/:id`, `PATCH /alerts/:id/read`, `PATCH /alerts/:id/status`, `GET /alerts/unread-count`
Reports: `GET /reports`, `POST /reports`, `DELETE /reports/:id`, `GET /reports/:id/download`
Dashboard: `GET /dashboard/stats`
Search: `GET /search?q=`

See the frontend README's API contract section for exact query params and response shapes;
the DTOs in `dto/` mirror the frontend's TypeScript types field-for-field.

## Known simplifications (call these out before a production rollout)

- **Weather data is synthetic**, generated deterministically per (site, hour) by
  `WeatherGenerator` rather than sourced from a real weather feed or sensor network.
  Swap it for a real integration (or a persisted `observations` table fed by field
  hardware) when ready — every controller/service already isolates this behind
  `WeatherService`, so only that layer needs to change.
- **Report files aren't actually rendered.** `POST /reports` marks a report `READY`
  immediately and `GET /reports/:id/download` streams a small CSV built from the report's
  metadata, not a real generated PDF/XLSX. Wire this to a real document-generation
  pipeline (and probably an async job queue) before relying on it.
- **No forecast-accuracy archive.** The frontend's Comparison page derives its own
  "forecast vs actual" data client-side (see its README notes) because there's no
  persisted log of past forecast issuances to diff against yet. A real implementation
  would log each forecast at issuance time and expose `GET /reports/forecast-accuracy`
  from that log.
- **JWT has no revocation list** — logout is a no-op server-side (stateless tokens expire
  on their own after `app.jwt.expiration-minutes`). Add a denylist (e.g. Redis-backed) if
  immediate server-side revocation matters for your deployment.
- **Site management is read-only** (matching the frontend, which doesn't yet expose
  create/edit-site UI). Add `POST`/`PUT`/`DELETE /sites` when that UI exists.
