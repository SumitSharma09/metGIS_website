package com.weatherops.backend.domain;

import jakarta.persistence.*;

import java.time.Instant;
import java.time.LocalDate;

/**
 * A detected swing between two successive forecast runs for one site/day/
 * parameter (scope doc section 2, Deviation Alert Mechanism) - e.g.
 * "Rainfall forecast for Mumbai revised from 12mm to 38mm". Raised by
 * {@link com.weatherops.backend.service.DeviationService} whenever a new
 * {@link ForecastRun} differs from the previous run for the same target
 * day by more than that parameter's threshold.
 */
@Entity
@Table(name = "deviation_alert")
public class DeviationAlert {

    @Id
    private String id;

    @Column(nullable = false)
    private String siteId;

    @Column(nullable = false)
    private String siteName;

    /** The day the diverging forecasts are both for. */
    @Column(nullable = false)
    private LocalDate forecastDate;

    /** "temperature" | "rainfall" | "windSpeed" - kept as a plain string
     *  rather than WeatherParameter since a deviation is about a forecast
     *  figure, not an observed threshold breach. */
    @Column(nullable = false)
    private String parameter;

    private double previousValue;
    private double updatedValue;
    private double deltaAbsolute;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DeviationSeverity severity;

    @Column(nullable = false)
    private LocalDate previousIssuedDate;

    @Column(nullable = false)
    private LocalDate updatedIssuedDate;

    @Column(nullable = false)
    private Instant detectedAt;

    private boolean acknowledged;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public LocalDate getForecastDate() {
        return forecastDate;
    }

    public void setForecastDate(LocalDate forecastDate) {
        this.forecastDate = forecastDate;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    public double getPreviousValue() {
        return previousValue;
    }

    public void setPreviousValue(double previousValue) {
        this.previousValue = previousValue;
    }

    public double getUpdatedValue() {
        return updatedValue;
    }

    public void setUpdatedValue(double updatedValue) {
        this.updatedValue = updatedValue;
    }

    public double getDeltaAbsolute() {
        return deltaAbsolute;
    }

    public void setDeltaAbsolute(double deltaAbsolute) {
        this.deltaAbsolute = deltaAbsolute;
    }

    public DeviationSeverity getSeverity() {
        return severity;
    }

    public void setSeverity(DeviationSeverity severity) {
        this.severity = severity;
    }

    public LocalDate getPreviousIssuedDate() {
        return previousIssuedDate;
    }

    public void setPreviousIssuedDate(LocalDate previousIssuedDate) {
        this.previousIssuedDate = previousIssuedDate;
    }

    public LocalDate getUpdatedIssuedDate() {
        return updatedIssuedDate;
    }

    public void setUpdatedIssuedDate(LocalDate updatedIssuedDate) {
        this.updatedIssuedDate = updatedIssuedDate;
    }

    public Instant getDetectedAt() {
        return detectedAt;
    }

    public void setDetectedAt(Instant detectedAt) {
        this.detectedAt = detectedAt;
    }

    public boolean isAcknowledged() {
        return acknowledged;
    }

    public void setAcknowledged(boolean acknowledged) {
        this.acknowledged = acknowledged;
    }
}
