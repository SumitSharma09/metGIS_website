package com.weatherops.backend.dto.site;

import com.weatherops.backend.domain.Site;

import java.time.LocalDate;

public class SiteDto {
    public String id;
    public String code;
    public String name;
    public String circle;
    public String state;
    public String district;
    public double latitude;
    public double longitude;
    public String address;
    public String status; // 'active' | 'inactive' | 'maintenance'
    public int elevationMeters;
    public LocalDate installedOn;
    public String contactPerson;
    public String contactPhone;
    public String towerType; // 'GBT' | 'RTT' | 'Monopole'

    public static SiteDto from(Site site) {
        SiteDto dto = new SiteDto();
        dto.id = site.getId();
        dto.code = site.getCode();
        dto.name = site.getName();
        dto.circle = site.getCircle();
        dto.state = site.getState();
        dto.district = site.getDistrict();
        dto.latitude = site.getLatitude();
        dto.longitude = site.getLongitude();
        dto.address = site.getAddress();
        dto.status = site.getStatus().toJson();
        dto.elevationMeters = site.getElevationMeters();
        dto.installedOn = site.getInstalledOn();
        dto.contactPerson = site.getContactPerson();
        dto.contactPhone = site.getContactPhone();
        dto.towerType = site.getTowerType().toJson();
        return dto;
    }
}
