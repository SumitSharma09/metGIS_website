package com.weatherops.backend.notification;

import com.weatherops.backend.dto.deviation.DeviationAlertDto;
import com.weatherops.backend.dto.report.ReportItemDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Single entry point for pushing a message out over every enabled delivery
 * channel (scope doc sections 1 & 4: Daily Weather Alerts Report,
 * Deviation Alert Mechanism, and WhatsApp Alerting all share the same
 * Email + WhatsApp + Portal delivery matrix). Callers never touch a
 * {@link NotificationChannel} directly - that keeps every call site
 * channel-agnostic, so adding a third channel later (SMS, Slack, ...) is a
 * new {@link NotificationChannel} bean, not a change to every caller.
 * <p>
 * Both channels are scaffolds today (see their classes) - this service is
 * fully wired and called from real hook points (new deviation alerts,
 * newly-created reports), but every send is a log line until the user
 * supplies real SMTP / WhatsApp Business API credentials in application.yml.
 */
@Service
public class NotificationService {

    private final List<NotificationChannel> channels;
    private final String defaultRecipientEmail;
    private final String defaultRecipientPhone;

    public NotificationService(
            List<NotificationChannel> channels,
            @Value("${app.notifications.default-recipient-email:}") String defaultRecipientEmail,
            @Value("${app.notifications.default-recipient-phone:}") String defaultRecipientPhone) {
        this.channels = channels;
        this.defaultRecipientEmail = defaultRecipientEmail;
        this.defaultRecipientPhone = defaultRecipientPhone;
    }

    /** Sends one message over every registered channel, falling back to the
     *  configured default recipient for a channel the message didn't name
     *  one for. */
    public void send(NotificationMessage message) {
        NotificationMessage resolved = new NotificationMessage(
                message.getType(),
                message.getSubject(),
                message.getBody(),
                message.getRecipientEmail() != null ? message.getRecipientEmail() : defaultRecipientEmail,
                message.getRecipientPhone() != null ? message.getRecipientPhone() : defaultRecipientPhone);
        for (NotificationChannel channel : channels) {
            channel.send(resolved);
        }
    }

    /** Hook point: called by DeviationService whenever a new deviation is
     *  detected (scope doc section 2). */
    public void notifyDeviationAlert(DeviationAlertDto deviation) {
        send(new NotificationMessage(
                NotificationType.DEVIATION_ALERT,
                "Forecast deviation: " + deviation.siteName,
                deviation.message,
                null, null));
    }

    /** Hook point: called by ReportService once a requested report is
     *  ready (scope doc section 1, Daily Weather Alerts Report). */
    public void notifyReportReady(ReportItemDto report) {
        send(new NotificationMessage(
                NotificationType.DAILY_REPORT,
                "Report ready: " + report.title,
                String.format("\"%s\" covering %d site(s) is ready to download.", report.title, report.siteIds.size()),
                null, null));
    }

    /** Manual test send (POST /notifications/test) - lets an admin confirm
     *  the wiring once real credentials are added, without waiting for a
     *  real alert/report/deviation to trigger one. */
    public void sendTest(String body, String recipientEmail, String recipientPhone) {
        send(new NotificationMessage(NotificationType.TEST, "WeatherOps test notification", body, recipientEmail, recipientPhone));
    }

    /** True if at least one channel has real credentials configured -
     *  callers can use this to warn ("notifications are scaffolded, not
     *  live") rather than silently no-op. */
    public boolean anyChannelLive() {
        return channels.stream().anyMatch(NotificationChannel::isConfigured);
    }

    /** Per-channel configured/not-configured status, for a settings page or
     *  a quick GET /notifications/status check. */
    public Map<String, Boolean> channelStatus() {
        Map<String, Boolean> status = new LinkedHashMap<>();
        for (NotificationChannel channel : channels) {
            status.put(channel.getChannelName(), channel.isConfigured());
        }
        return status;
    }
}
