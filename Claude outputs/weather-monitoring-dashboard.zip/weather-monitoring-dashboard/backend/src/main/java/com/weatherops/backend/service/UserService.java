package com.weatherops.backend.service;

import com.weatherops.backend.common.ApiException;
import com.weatherops.backend.domain.User;
import com.weatherops.backend.dto.user.ChangePasswordRequest;
import com.weatherops.backend.dto.user.UpdateUserRequest;
import com.weatherops.backend.dto.user.UserProfileDto;
import com.weatherops.backend.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<UserProfileDto> listUsers() {
        return userRepository.findAll().stream().map(UserProfileDto::from).toList();
    }

    public UserProfileDto getUser(String id) {
        return UserProfileDto.from(findOrThrow(id));
    }

    public UserProfileDto updateUser(String id, UpdateUserRequest request) {
        User user = findOrThrow(id);
        user.setFullName(request.fullName);
        user.setEmail(request.email);
        user.setPhone(request.phone);
        return UserProfileDto.from(userRepository.save(user));
    }

    public void changePassword(String id, ChangePasswordRequest request) {
        User user = findOrThrow(id);
        if (!passwordEncoder.matches(request.currentPassword, user.getPasswordHash())) {
            throw ApiException.badRequest("Current password is incorrect");
        }
        user.setPasswordHash(passwordEncoder.encode(request.newPassword));
        userRepository.save(user);
    }

    private User findOrThrow(String id) {
        return userRepository.findById(id).orElseThrow(() -> ApiException.notFound("User not found"));
    }
}
