package com.weatherops.backend.domain;

public enum WeatherParameter {
    TEMPERATURE, RAINFALL, WIND_SPEED, WIND_DIRECTION, HUMIDITY, PRESSURE, LIGHTNING;

    /** Serializes to the frontend's camelCase literal union. */
    public String toJson() {
        return switch (this) {
            case WIND_SPEED -> "windSpeed";
            case WIND_DIRECTION -> "windDirection";
            default -> name().toLowerCase();
        };
    }
}
