package com.weatherops.backend.dto.auth;

import com.weatherops.backend.dto.user.UserProfileDto;

public class LoginResponse {
    public String token;
    public UserProfileDto user;

    public LoginResponse(String token, UserProfileDto user) {
        this.token = token;
        this.user = user;
    }
}
