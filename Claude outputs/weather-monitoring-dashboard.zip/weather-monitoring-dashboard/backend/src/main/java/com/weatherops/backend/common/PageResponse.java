package com.weatherops.backend.common;

import java.util.List;

/** Mirrors the frontend's PaginatedResult&lt;T&gt; shape exactly. */
public class PageResponse<T> {
    private List<T> items;
    private long total;
    private int page;
    private int pageSize;

    public PageResponse() {
    }

    public PageResponse(List<T> items, long total, int page, int pageSize) {
        this.items = items;
        this.total = total;
        this.page = page;
        this.pageSize = pageSize;
    }

    public List<T> getItems() {
        return items;
    }

    public void setItems(List<T> items) {
        this.items = items;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
