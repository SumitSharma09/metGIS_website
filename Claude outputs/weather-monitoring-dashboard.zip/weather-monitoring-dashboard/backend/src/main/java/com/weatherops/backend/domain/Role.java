package com.weatherops.backend.domain;

public enum Role {
    ADMIN, OPERATOR, VIEWER
}
