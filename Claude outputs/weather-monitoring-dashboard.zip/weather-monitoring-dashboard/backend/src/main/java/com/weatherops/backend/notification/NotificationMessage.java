package com.weatherops.backend.notification;

/**
 * A single message to deliver over whichever channels are enabled. Plain
 * value holder - {@link NotificationService} is what decides which
 * {@link NotificationChannel}s actually see it.
 */
public class NotificationMessage {
    private final NotificationType type;
    private final String subject;
    private final String body;
    private final String recipientEmail; // null -> NotificationService falls back to the configured default
    private final String recipientPhone; // null -> NotificationService falls back to the configured default

    public NotificationMessage(NotificationType type, String subject, String body, String recipientEmail, String recipientPhone) {
        this.type = type;
        this.subject = subject;
        this.body = body;
        this.recipientEmail = recipientEmail;
        this.recipientPhone = recipientPhone;
    }

    public NotificationType getType() {
        return type;
    }

    public String getSubject() {
        return subject;
    }

    public String getBody() {
        return body;
    }

    public String getRecipientEmail() {
        return recipientEmail;
    }

    public String getRecipientPhone() {
        return recipientPhone;
    }
}
