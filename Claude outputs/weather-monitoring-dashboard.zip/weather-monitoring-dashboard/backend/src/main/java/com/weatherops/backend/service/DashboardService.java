package com.weatherops.backend.service;

import com.weatherops.backend.domain.AlertItem;
import com.weatherops.backend.domain.AlertStatus;
import com.weatherops.backend.domain.Site;
import com.weatherops.backend.domain.SiteStatus;
import com.weatherops.backend.dto.dashboard.DashboardStatsDto;
import com.weatherops.backend.dto.weather.CurrentObservationDto;
import com.weatherops.backend.repository.AlertRepository;
import com.weatherops.backend.repository.SiteRepository;
import com.weatherops.backend.security.AccessScope;
import com.weatherops.backend.weather.WeatherGenerator;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class DashboardService {

    private final SiteRepository siteRepository;
    private final AlertRepository alertRepository;
    private final WeatherGenerator generator;

    public DashboardService(SiteRepository siteRepository, AlertRepository alertRepository, WeatherGenerator generator) {
        this.siteRepository = siteRepository;
        this.alertRepository = alertRepository;
        this.generator = generator;
    }

    public DashboardStatsDto getStats() {
        List<Site> sites = AccessScope.restrictToScope(siteRepository.findAll());
        Set<String> inScopeSiteIds = sites.stream().map(Site::getId).collect(java.util.stream.Collectors.toSet());
        List<AlertItem> activeAlerts = alertRepository.findAll().stream()
                .filter(a -> a.getStatus() != AlertStatus.RESOLVED)
                .filter(a -> inScopeSiteIds.contains(a.getSiteId()))
                .toList();

        Instant now = Instant.now();
        Map<String, CurrentObservationDto> observations = new LinkedHashMap<>();
        for (Site site : sites) {
            observations.put(site.getId(), generator.currentAt(site, now));
        }

        DashboardStatsDto dto = new DashboardStatsDto();
        dto.totalSites = sites.size();
        dto.activeSites = (int) sites.stream().filter(s -> s.getStatus() == SiteStatus.ACTIVE).count();
        dto.maintenanceSites = (int) sites.stream().filter(s -> s.getStatus() == SiteStatus.MAINTENANCE).count();
        dto.inactiveSites = (int) sites.stream().filter(s -> s.getStatus() == SiteStatus.INACTIVE).count();

        Map<String, Integer> bySeverity = new LinkedHashMap<>();
        for (AlertItem a : activeAlerts) {
            bySeverity.merge(a.getSeverity().toJson(), 1, Integer::sum);
        }
        dto.activeAlertsBySeverity = bySeverity;

        dto.avgTemperature = observations.values().stream().mapToDouble(o -> o.temperature).average().orElse(0);
        dto.totalRainfallToday = observations.values().stream().mapToDouble(o -> o.rainfallToday).sum();

        dto.topRainfallSites = sites.stream()
                .sorted(Comparator.comparingDouble((Site s) -> observations.get(s.getId()).rainfallToday).reversed())
                .limit(5)
                .map(s -> new DashboardStatsDto.TopRainfallSite(s.getId(), s.getName(), observations.get(s.getId()).rainfallToday))
                .toList();

        dto.circleSummaries = sites.stream()
                .map(Site::getCircle)
                .distinct()
                .sorted()
                .map(circle -> {
                    List<Site> circleSites = sites.stream().filter(s -> s.getCircle().equals(circle)).toList();
                    double avgTemp = circleSites.stream()
                            .mapToDouble(s -> observations.get(s.getId()).temperature)
                            .average().orElse(0);
                    return new DashboardStatsDto.CircleSummary(circle, circleSites.size(), Math.round(avgTemp * 10) / 10.0);
                })
                .toList();

        return dto;
    }
}
