package com.weatherops.backend.service;

import com.weatherops.backend.common.ApiException;
import com.weatherops.backend.common.PageResponse;
import com.weatherops.backend.domain.Site;
import com.weatherops.backend.dto.site.SiteDto;
import com.weatherops.backend.repository.SiteRepository;
import com.weatherops.backend.security.AccessScope;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

@Service
public class SiteService {

    private final SiteRepository siteRepository;

    public SiteService(SiteRepository siteRepository) {
        this.siteRepository = siteRepository;
    }

    /**
     * Small dataset (~20 sites), so filtering/sorting/paginating in memory
     * keeps this readable; a larger deployment should push this down into a
     * JPA Specification / native query instead.
     */
    public PageResponse<SiteDto> listSites(String search, String circle, String state, String district,
                                            String status, Integer page, Integer pageSize,
                                            String sortBy, String sortDir) {
        List<Site> all = siteRepository.findAll();

        List<Site> filtered = all.stream()
                .filter(s -> circle == null || circle.isBlank() || s.getCircle().equalsIgnoreCase(circle))
                .filter(s -> state == null || state.isBlank() || s.getState().equalsIgnoreCase(state))
                .filter(s -> district == null || district.isBlank() || s.getDistrict().equalsIgnoreCase(district))
                .filter(s -> status == null || status.isBlank() || s.getStatus().toJson().equalsIgnoreCase(status))
                .filter(s -> matchesSearch(s, search))
                .sorted(comparatorFor(sortBy, sortDir))
                .toList();
        // RBAC: a non-admin only ever sees sites in their assigned states,
        // regardless of what the caller asked for (an out-of-scope `state`
        // filter just yields an empty page, not an error).
        filtered = AccessScope.restrictToScope(filtered);

        int p = page == null || page < 1 ? 1 : page;
        int size = pageSize == null || pageSize < 1 ? 10 : pageSize;
        int from = Math.min((p - 1) * size, filtered.size());
        int to = Math.min(from + size, filtered.size());

        List<SiteDto> pageItems = filtered.subList(from, to).stream().map(SiteDto::from).toList();
        return new PageResponse<>(pageItems, filtered.size(), p, size);
    }

    public SiteDto getSite(String id) {
        return SiteDto.from(findOrThrow(id));
    }

    public Site findOrThrow(String id) {
        Site site = siteRepository.findById(id).orElseThrow(() -> ApiException.notFound("Site not found"));
        if (!AccessScope.canAccessState(site.getState())) {
            // Deliberately the same "not found" a real lookup miss would
            // give - a 403 with a state name in the body would tell a
            // non-admin exactly which real site IDs exist outside their
            // scope, which is its own small information leak.
            throw ApiException.notFound("Site not found");
        }
        return site;
    }

    public List<String> listCircles() {
        if (AccessScope.isPanIndia()) return siteRepository.findDistinctCircles();
        return AccessScope.restrictToScope(siteRepository.findAll()).stream()
                .map(Site::getCircle).distinct().sorted().toList();
    }

    public List<String> listStates() {
        List<String> all = siteRepository.findDistinctStates();
        if (AccessScope.isPanIndia()) return all;
        return all.stream().filter(AccessScope::canAccessState).toList();
    }

    public List<String> listDistricts(String state) {
        if (state != null && !state.isBlank() && !AccessScope.canAccessState(state)) {
            return List.of();
        }
        if (state != null && !state.isBlank()) {
            return siteRepository.findDistinctDistricts(state);
        }
        // No state filter: restrict the nationwide district list down to
        // districts that actually belong to an in-scope state.
        if (AccessScope.isPanIndia()) return siteRepository.findDistinctDistricts(null);
        return AccessScope.restrictToScope(siteRepository.findAll()).stream()
                .map(Site::getDistrict).distinct().sorted().toList();
    }

    private boolean matchesSearch(Site s, String search) {
        if (search == null || search.isBlank()) return true;
        String q = search.toLowerCase();
        return s.getName().toLowerCase().contains(q)
                || s.getCode().toLowerCase().contains(q)
                || s.getCircle().toLowerCase().contains(q)
                || s.getState().toLowerCase().contains(q)
                || s.getDistrict().toLowerCase().contains(q);
    }

    private Comparator<Site> comparatorFor(String sortBy, String sortDir) {
        Function<Site, String> key = switch (sortBy == null ? "" : sortBy) {
            case "code" -> Site::getCode;
            case "circle" -> Site::getCircle;
            case "state" -> Site::getState;
            case "district" -> Site::getDistrict;
            default -> Site::getName;
        };
        Comparator<Site> comparator = Comparator.comparing(key, String.CASE_INSENSITIVE_ORDER);
        return "desc".equalsIgnoreCase(sortDir) ? comparator.reversed() : comparator;
    }
}
