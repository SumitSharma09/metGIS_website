package com.weatherops.backend.domain;

import jakarta.persistence.*;

import java.time.Instant;
import java.time.LocalDate;

/**
 * One forecast "run" for a single site/target-day, as issued on a
 * particular day. Successive runs for the same (siteId, forecastDate) but
 * different issuedDate are what {@link com.weatherops.backend.service.DeviationService}
 * diffs to detect and raise deviation alerts (scope doc section 2).
 */
@Entity
@Table(name = "forecast_run", uniqueConstraints = @UniqueConstraint(columnNames = {"site_id", "forecast_date", "issued_date"}))
public class ForecastRun {

    @Id
    private String id;

    @Column(nullable = false)
    private String siteId;

    /** The day this run is forecasting for. */
    @Column(nullable = false)
    private LocalDate forecastDate;

    /** The day this run was generated/issued on. */
    @Column(nullable = false)
    private LocalDate issuedDate;

    @Column(nullable = false)
    private Instant issuedAt;

    private double minTemp;
    private double maxTemp;
    private double expectedRainfallMm;
    private double windSpeed;
    private String condition;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public LocalDate getForecastDate() {
        return forecastDate;
    }

    public void setForecastDate(LocalDate forecastDate) {
        this.forecastDate = forecastDate;
    }

    public LocalDate getIssuedDate() {
        return issuedDate;
    }

    public void setIssuedDate(LocalDate issuedDate) {
        this.issuedDate = issuedDate;
    }

    public Instant getIssuedAt() {
        return issuedAt;
    }

    public void setIssuedAt(Instant issuedAt) {
        this.issuedAt = issuedAt;
    }

    public double getMinTemp() {
        return minTemp;
    }

    public void setMinTemp(double minTemp) {
        this.minTemp = minTemp;
    }

    public double getMaxTemp() {
        return maxTemp;
    }

    public void setMaxTemp(double maxTemp) {
        this.maxTemp = maxTemp;
    }

    public double getExpectedRainfallMm() {
        return expectedRainfallMm;
    }

    public void setExpectedRainfallMm(double expectedRainfallMm) {
        this.expectedRainfallMm = expectedRainfallMm;
    }

    public double getWindSpeed() {
        return windSpeed;
    }

    public void setWindSpeed(double windSpeed) {
        this.windSpeed = windSpeed;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }
}
