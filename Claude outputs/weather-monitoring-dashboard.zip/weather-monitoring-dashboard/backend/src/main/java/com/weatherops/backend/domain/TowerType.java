package com.weatherops.backend.domain;

public enum TowerType {
    GBT, RTT, MONOPOLE;

    /** Frontend uses 'Monopole' (mixed case) alongside 'GBT'/'RTT'. */
    public String toJson() {
        return this == MONOPOLE ? "Monopole" : name();
    }
}
