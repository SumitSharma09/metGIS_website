package com.weatherops.backend.service;

import com.weatherops.backend.common.PageResponse;
import com.weatherops.backend.domain.DeviationAlert;
import com.weatherops.backend.domain.DeviationSeverity;
import com.weatherops.backend.domain.ForecastRun;
import com.weatherops.backend.domain.Site;
import com.weatherops.backend.dto.deviation.DeviationAlertDto;
import com.weatherops.backend.dto.weather.ForecastDayDto;
import com.weatherops.backend.notification.NotificationService;
import com.weatherops.backend.repository.DeviationAlertRepository;
import com.weatherops.backend.repository.ForecastRunRepository;
import com.weatherops.backend.repository.SiteRepository;
import com.weatherops.backend.security.AccessScope;
import com.weatherops.backend.weather.WeatherGenerator;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Deviation Alert Mechanism (scope doc section 2): issues a fresh forecast
 * "run" for each site/day, compares it against the previous run for the
 * same target day, and raises a {@link DeviationAlert} wherever a headline
 * figure (max temperature, expected rainfall, wind speed) moved by more
 * than that parameter's threshold - e.g. "Rainfall forecast for Mumbai
 * revised from 12mm to 38mm".
 * <p>
 * In this synthetic-data demo, {@link WeatherGenerator#forecastAsOf} is
 * what makes two runs for the same target day actually differ: it seeds
 * its pseudo-randomness by (site, target day, issued day), so calling it
 * again on a later "as-of" day deterministically produces a different but
 * reproducible number - modeling a forecast model's output shifting as new
 * runs come in on approach to that day.
 */
@Service
public class DeviationService {

    private static final int LEAD_DAYS = 3;

    private static final double TEMP_MINOR = 3.0;
    private static final double TEMP_MODERATE = 5.0;
    private static final double TEMP_MAJOR = 8.0;

    private static final double RAINFALL_MINOR = 8.0;
    private static final double RAINFALL_MODERATE = 20.0;
    private static final double RAINFALL_MAJOR = 40.0;

    private static final double WIND_MINOR = 10.0;
    private static final double WIND_MODERATE = 20.0;
    private static final double WIND_MAJOR = 35.0;

    private final SiteRepository siteRepository;
    private final ForecastRunRepository forecastRunRepository;
    private final DeviationAlertRepository deviationAlertRepository;
    private final WeatherGenerator generator;
    private final NotificationService notificationService;

    public DeviationService(SiteRepository siteRepository, ForecastRunRepository forecastRunRepository,
                             DeviationAlertRepository deviationAlertRepository, WeatherGenerator generator,
                             NotificationService notificationService) {
        this.siteRepository = siteRepository;
        this.forecastRunRepository = forecastRunRepository;
        this.deviationAlertRepository = deviationAlertRepository;
        this.generator = generator;
        this.notificationService = notificationService;
    }

    /** Issues today's runs (for tomorrow through tomorrow+LEAD_DAYS-1) across
     *  every site and returns any newly detected deviations. This is what
     *  the "Run deviation check" action on the Alerts page's Deviations tab
     *  calls, and what a real deployment would put on a daily scheduler. */
    public List<DeviationAlertDto> runDailyCycle() {
        return runCycleFor(LocalDate.now(ZoneOffset.UTC));
    }

    /** Same as {@link #runDailyCycle()} but with an explicit "as-of" issued
     *  date - used by DataSeeder to backfill a few days of run history so
     *  the feature has something to show on first startup. */
    public List<DeviationAlertDto> runCycleFor(LocalDate issuedDate) {
        List<Site> sites = siteRepository.findAll();
        List<DeviationAlert> newDeviations = new ArrayList<>();

        for (Site site : sites) {
            for (int lead = 1; lead <= LEAD_DAYS; lead++) {
                LocalDate targetDate = issuedDate.plusDays(lead);
                if (forecastRunRepository.findBySiteIdAndForecastDateAndIssuedDate(site.getId(), targetDate, issuedDate).isPresent()) {
                    continue; // already ran this site/day/as-of combination
                }

                ForecastDayDto forecastDay = generator.forecastAsOf(site, targetDate, issuedDate);
                ForecastRun run = new ForecastRun();
                run.setId(UUID.randomUUID().toString());
                run.setSiteId(site.getId());
                run.setForecastDate(targetDate);
                run.setIssuedDate(issuedDate);
                run.setIssuedAt(Instant.now());
                run.setMinTemp(forecastDay.minTemp);
                run.setMaxTemp(forecastDay.maxTemp);
                run.setExpectedRainfallMm(forecastDay.expectedRainfallMm);
                run.setWindSpeed(forecastDay.windSpeed);
                run.setCondition(forecastDay.condition);
                forecastRunRepository.save(run);

                Optional<ForecastRun> previous = forecastRunRepository
                        .findTopBySiteIdAndForecastDateAndIssuedDateLessThanOrderByIssuedDateDesc(site.getId(), targetDate, issuedDate);
                previous.ifPresent(prev -> newDeviations.addAll(compare(site, prev, run)));
            }
        }

        deviationAlertRepository.saveAll(newDeviations);
        List<DeviationAlertDto> dtos = newDeviations.stream().map(DeviationAlertDto::from).toList();
        // Alert Delivery Matrix (scope doc section 4): a deviation goes out
        // over Email/WhatsApp same as any other alert type.
        dtos.forEach(notificationService::notifyDeviationAlert);
        return dtos;
    }

    private List<DeviationAlert> compare(Site site, ForecastRun previous, ForecastRun updated) {
        List<DeviationAlert> deviations = new ArrayList<>();
        addIfBeyondThreshold(deviations, site, previous, updated, "temperature",
                previous.getMaxTemp(), updated.getMaxTemp(), TEMP_MINOR, TEMP_MODERATE, TEMP_MAJOR);
        addIfBeyondThreshold(deviations, site, previous, updated, "rainfall",
                previous.getExpectedRainfallMm(), updated.getExpectedRainfallMm(), RAINFALL_MINOR, RAINFALL_MODERATE, RAINFALL_MAJOR);
        addIfBeyondThreshold(deviations, site, previous, updated, "windSpeed",
                previous.getWindSpeed(), updated.getWindSpeed(), WIND_MINOR, WIND_MODERATE, WIND_MAJOR);
        return deviations;
    }

    private void addIfBeyondThreshold(List<DeviationAlert> out, Site site, ForecastRun previous, ForecastRun updated,
                                       String parameter, double previousValue, double updatedValue,
                                       double minor, double moderate, double major) {
        double delta = Math.abs(updatedValue - previousValue);
        DeviationSeverity severity;
        if (delta >= major) {
            severity = DeviationSeverity.MAJOR;
        } else if (delta >= moderate) {
            severity = DeviationSeverity.MODERATE;
        } else if (delta >= minor) {
            severity = DeviationSeverity.MINOR;
        } else {
            return; // within normal run-to-run noise, not a reportable deviation
        }

        DeviationAlert alert = new DeviationAlert();
        alert.setId(UUID.randomUUID().toString());
        alert.setSiteId(site.getId());
        alert.setSiteName(site.getName());
        alert.setForecastDate(updated.getForecastDate());
        alert.setParameter(parameter);
        alert.setPreviousValue(previousValue);
        alert.setUpdatedValue(updatedValue);
        alert.setDeltaAbsolute(Math.round(delta * 10) / 10.0);
        alert.setSeverity(severity);
        alert.setPreviousIssuedDate(previous.getIssuedDate());
        alert.setUpdatedIssuedDate(updated.getIssuedDate());
        alert.setDetectedAt(Instant.now());
        alert.setAcknowledged(false);
        out.add(alert);
    }

    public PageResponse<DeviationAlertDto> listDeviations(String siteId, String severity, Integer page, Integer pageSize) {
        Set<String> inScope = AccessScope.restrictToScope(siteRepository.findAll()).stream()
                .map(Site::getId).collect(Collectors.toSet());

        List<DeviationAlert> filtered = deviationAlertRepository.findAll().stream()
                .filter(d -> inScope.contains(d.getSiteId()))
                .filter(d -> siteId == null || siteId.isBlank() || d.getSiteId().equals(siteId))
                .filter(d -> severity == null || severity.isBlank() || d.getSeverity().toJson().equalsIgnoreCase(severity))
                .sorted(Comparator.comparing(DeviationAlert::getDetectedAt).reversed())
                .toList();

        int p = page == null || page < 1 ? 1 : page;
        int size = pageSize == null || pageSize < 1 ? 20 : pageSize;
        int from = Math.min((p - 1) * size, filtered.size());
        int to = Math.min(from + size, filtered.size());

        List<DeviationAlertDto> pageItems = filtered.subList(from, to).stream().map(DeviationAlertDto::from).toList();
        return new PageResponse<>(pageItems, filtered.size(), p, size);
    }

    public DeviationAlertDto acknowledge(String id) {
        DeviationAlert alert = deviationAlertRepository.findById(id)
                .orElseThrow(() -> com.weatherops.backend.common.ApiException.notFound("Deviation alert not found"));
        Set<String> inScope = AccessScope.restrictToScope(siteRepository.findAll()).stream()
                .map(Site::getId).collect(Collectors.toSet());
        if (!inScope.contains(alert.getSiteId())) {
            throw com.weatherops.backend.common.ApiException.notFound("Deviation alert not found");
        }
        alert.setAcknowledged(true);
        return DeviationAlertDto.from(deviationAlertRepository.save(alert));
    }
}
