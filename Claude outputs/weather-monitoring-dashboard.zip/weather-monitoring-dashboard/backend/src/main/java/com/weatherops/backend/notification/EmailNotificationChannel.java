package com.weatherops.backend.notification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Email delivery channel (scope doc sections 1 & 4 - Daily Report /
 * Deviation Alert / Advisory all go out over Email too).
 * <p>
 * This is a scaffold, not a live integration: {@code app.notifications.email.enabled}
 * defaults to false, and even when true, {@link #send} only logs what it
 * would have sent - there is no SMTP client wired up yet, since that needs
 * real credentials (host/username/password) the user hasn't supplied. To go
 * live: add {@code spring-boot-starter-mail} to pom.xml, inject a
 * {@code JavaMailSender}, and replace the body of {@link #send} with an
 * actual {@code mailSender.send(...)} call - everything else (config keys,
 * the NotificationService call sites) is already in place.
 */
@Component
public class EmailNotificationChannel implements NotificationChannel {

    private static final Logger log = LoggerFactory.getLogger(EmailNotificationChannel.class);

    private final boolean enabled;
    private final String host;
    private final int port;
    private final String from;

    public EmailNotificationChannel(
            @Value("${app.notifications.email.enabled:false}") boolean enabled,
            @Value("${app.notifications.email.host:}") String host,
            @Value("${app.notifications.email.port:587}") int port,
            @Value("${app.notifications.email.from:}") String from) {
        this.enabled = enabled;
        this.host = host;
        this.port = port;
        this.from = from;
    }

    @Override
    public String getChannelName() {
        return "email";
    }

    @Override
    public boolean isConfigured() {
        return enabled && !host.isBlank() && !from.isBlank();
    }

    @Override
    public void send(NotificationMessage message) {
        String to = message.getRecipientEmail();
        if (to == null || to.isBlank()) {
            log.warn("[email] Skipped {} - no recipient email configured or supplied", message.getType());
            return;
        }
        if (!isConfigured()) {
            log.info("[email] (not configured - would send via {}:{}) To: {} | Subject: {} | {}",
                    host.isBlank() ? "<unset host>" : host, port, to, message.getSubject(), message.getBody());
            return;
        }
        // TODO(real integration): send via JavaMailSender once SMTP
        // credentials are supplied. Left as a log line until then so the
        // rest of the pipeline (who gets notified, when, with what
        // content) is fully wired and testable without live credentials.
        log.info("[email] Sending via {}:{} from {} To: {} | Subject: {}", host, port, from, to, message.getSubject());
    }
}
