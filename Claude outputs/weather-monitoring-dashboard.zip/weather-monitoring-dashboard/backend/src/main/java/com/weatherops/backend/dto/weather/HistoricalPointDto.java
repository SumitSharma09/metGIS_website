package com.weatherops.backend.dto.weather;

import java.time.Instant;

public class HistoricalPointDto {
    public Instant timestamp;
    public double temperature;
    public int humidity;
    public double rainfall;
    public double windSpeed;
    public int pressure;
    public int lightningStrikes;
}
