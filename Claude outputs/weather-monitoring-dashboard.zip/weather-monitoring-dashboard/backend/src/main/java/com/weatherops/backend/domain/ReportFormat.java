package com.weatherops.backend.domain;

public enum ReportFormat {
    PDF, CSV, XLSX;

    public String toJson() {
        return name().toLowerCase();
    }

    public static ReportFormat fromJson(String value) {
        try {
            return ReportFormat.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException | NullPointerException ex) {
            throw new IllegalArgumentException("format must be one of: pdf, csv, xlsx");
        }
    }
}
