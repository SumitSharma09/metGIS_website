package com.weatherops.backend.controller;

import com.weatherops.backend.common.ApiException;
import com.weatherops.backend.common.PageResponse;
import com.weatherops.backend.dto.report.CreateReportRequest;
import com.weatherops.backend.dto.report.ReportItemDto;
import com.weatherops.backend.repository.ReportRepository;
import com.weatherops.backend.service.ReportService;
import jakarta.validation.Valid;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.Map;

@RestController
@RequestMapping("/reports")
public class ReportController {

    private final ReportService reportService;
    private final ReportRepository reportRepository;

    public ReportController(ReportService reportService, ReportRepository reportRepository) {
        this.reportService = reportService;
        this.reportRepository = reportRepository;
    }

    @GetMapping
    public PageResponse<ReportItemDto> listReports(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer pageSize) {
        return reportService.listReports(search, status, page, pageSize);
    }

    @PostMapping
    public ReportItemDto createReport(@Valid @RequestBody CreateReportRequest request) {
        return reportService.createReport(request);
    }

    @DeleteMapping("/{id}")
    public Map<String, Boolean> deleteReport(@PathVariable String id) {
        reportService.deleteReport(id);
        return Map.of("success", true);
    }

    /**
     * Demo download: streams a small CSV summary of the report's stored
     * metadata rather than a real generated PDF/XLSX binary, since no report
     * files are actually rendered/stored server-side yet. Swap this for a
     * real file stream (e.g. from object storage) once report generation is
     * wired to a document-rendering pipeline.
     */
    @GetMapping("/{id}/download")
    public ResponseEntity<byte[]> download(@PathVariable String id) {
        var report = reportRepository.findById(id).orElseThrow(() -> ApiException.notFound("Report not found"));
        String csv = "title,sites,dateFrom,dateTo,format\n"
                + report.getTitle() + ",\"" + String.join("; ", report.getSiteNames()) + "\","
                + report.getDateFrom() + "," + report.getDateTo() + "," + report.getFormat().toJson();
        byte[] body = csv.getBytes(StandardCharsets.UTF_8);

        ContentDisposition disposition = ContentDisposition.attachment()
                .filename(report.getTitle().replaceAll("\\s+", "_") + ".csv")
                .build();

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, disposition.toString())
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(body);
    }
}
