package com.weatherops.backend.controller;

import com.weatherops.backend.common.PageResponse;
import com.weatherops.backend.dto.site.SiteDto;
import com.weatherops.backend.service.SiteService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sites")
public class SiteController {

    private final SiteService siteService;

    public SiteController(SiteService siteService) {
        this.siteService = siteService;
    }

    @GetMapping
    public PageResponse<SiteDto> listSites(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String circle,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) String district,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer pageSize,
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String sortDir) {
        return siteService.listSites(search, circle, state, district, status, page, pageSize, sortBy, sortDir);
    }

    @GetMapping("/circles")
    public List<String> listCircles() {
        return siteService.listCircles();
    }

    // NOTE: registered before "/{id}" so "states"/"districts" aren't captured as a site id path variable.
    @GetMapping("/states")
    public List<String> listStates() {
        return siteService.listStates();
    }

    @GetMapping("/districts")
    public List<String> listDistricts(@RequestParam(required = false) String state) {
        return siteService.listDistricts(state);
    }

    @GetMapping("/{id}")
    public SiteDto getSite(@PathVariable String id) {
        return siteService.getSite(id);
    }
}
