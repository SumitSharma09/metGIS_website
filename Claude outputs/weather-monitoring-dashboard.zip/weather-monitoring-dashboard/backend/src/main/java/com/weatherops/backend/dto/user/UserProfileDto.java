package com.weatherops.backend.dto.user;

import com.weatherops.backend.domain.User;

import java.time.Instant;
import java.util.List;

/** Mirrors the frontend's UserProfile type. Public fields keep DTOs short;
 *  Jackson serializes/deserializes public fields without extra boilerplate. */
public class UserProfileDto {
    public String id;
    public String username;
    public String fullName;
    public String email;
    public String phone;
    public String role; // lowercase: 'admin' | 'operator' | 'viewer'
    public Instant lastLoginAt;
    /** States this user may see (scope doc section 5, RBAC). Empty for an
     *  ADMIN, who is Pan-India regardless of this list; for OPERATOR/VIEWER
     *  it's the exact set the backend enforces via AccessScope. */
    public List<String> assignedStates;

    public static UserProfileDto from(User user) {
        UserProfileDto dto = new UserProfileDto();
        dto.id = user.getId();
        dto.username = user.getUsername();
        dto.fullName = user.getFullName();
        dto.email = user.getEmail();
        dto.phone = user.getPhone();
        dto.role = user.getRole().name().toLowerCase();
        dto.lastLoginAt = user.getLastLoginAt();
        dto.assignedStates = List.copyOf(user.getAssignedStates());
        return dto;
    }
}
