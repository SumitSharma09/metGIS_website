package com.weatherops.backend.dto.dashboard;

import java.util.List;
import java.util.Map;

public class DashboardStatsDto {
    public int totalSites;
    public int activeSites;
    public int maintenanceSites;
    public int inactiveSites;
    public Map<String, Integer> activeAlertsBySeverity;
    public double avgTemperature;
    public double totalRainfallToday;
    public List<TopRainfallSite> topRainfallSites;
    public List<CircleSummary> circleSummaries;

    public static class TopRainfallSite {
        public String siteId;
        public String siteName;
        public double rainfallToday;

        public TopRainfallSite(String siteId, String siteName, double rainfallToday) {
            this.siteId = siteId;
            this.siteName = siteName;
            this.rainfallToday = rainfallToday;
        }
    }

    public static class CircleSummary {
        public String circle;
        public int siteCount;
        public double avgTemperature;

        public CircleSummary(String circle, int siteCount, double avgTemperature) {
            this.circle = circle;
            this.siteCount = siteCount;
            this.avgTemperature = avgTemperature;
        }
    }
}
