package com.weatherops.backend.weather;

/**
 * Deterministic pseudo-random generator (Park-Miller minimal standard LCG),
 * mirroring the approach used by the frontend's mock data layer
 * (src/api/mock/rng.ts) so weather stays stable across requests instead of
 * using Math.random(). Two identical (siteId, timestamp) seeds always
 * produce the same observation.
 */
public class Rng {
    private long state;

    public Rng(long seed) {
        long s = seed % 2147483647L;
        if (s <= 0) s += 2147483646L;
        this.state = s;
    }

    public double next() {
        state = (state * 16807) % 2147483647L;
        return (state - 1) / 2147483646.0;
    }

    public double range(double min, double max) {
        return min + next() * (max - min);
    }

    public static long hashStringToSeed(String value) {
        int hash = 0;
        for (int i = 0; i < value.length(); i++) {
            hash = (hash << 5) - hash + value.charAt(i);
        }
        long result = Math.abs((long) hash);
        return result == 0 ? 1 : result;
    }
}
