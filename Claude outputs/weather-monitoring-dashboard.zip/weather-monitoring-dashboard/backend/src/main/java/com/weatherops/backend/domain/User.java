package com.weatherops.backend.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "app_user")
public class User {

    @Id
    private String id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String passwordHash;

    @Column(nullable = false)
    private String fullName;

    @Column(nullable = false)
    private String email;

    private String phone;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    private Instant lastLoginAt;

    /**
     * RBAC scope: the states this user may see, checked against
     * Site#getState() for every request that enumerates sites (and
     * everything derived from sites - weather, alerts, reports, dashboard
     * stats, search). Ignored for ADMIN, who always has Pan-India
     * visibility regardless of what's in this set. See
     * {@code security.AccessScope}.
     */
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "app_user_assigned_state", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "state", nullable = false)
    private Set<String> assignedStates = new LinkedHashSet<>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Instant getLastLoginAt() {
        return lastLoginAt;
    }

    public void setLastLoginAt(Instant lastLoginAt) {
        this.lastLoginAt = lastLoginAt;
    }

    public Set<String> getAssignedStates() {
        return assignedStates;
    }

    public void setAssignedStates(Set<String> assignedStates) {
        this.assignedStates = assignedStates == null ? new LinkedHashSet<>() : assignedStates;
    }

    public boolean isAdmin() {
        return role == Role.ADMIN;
    }
}
