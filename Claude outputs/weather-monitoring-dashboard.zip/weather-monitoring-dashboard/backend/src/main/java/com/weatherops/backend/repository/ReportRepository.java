package com.weatherops.backend.repository;

import com.weatherops.backend.domain.ReportItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository extends JpaRepository<ReportItem, String> {
}
