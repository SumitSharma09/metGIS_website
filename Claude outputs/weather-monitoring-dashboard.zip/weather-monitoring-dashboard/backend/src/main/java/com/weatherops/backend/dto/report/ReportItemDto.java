package com.weatherops.backend.dto.report;

import com.weatherops.backend.domain.ReportItem;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

public class ReportItemDto {
    public String id;
    public String title;
    public List<String> siteIds;
    public List<String> siteNames;
    public List<String> parameters;
    public LocalDate dateFrom;
    public LocalDate dateTo;
    public String format;
    public String status;
    public String generatedBy;
    public Instant generatedAt;
    public int fileSizeKb;

    public static ReportItemDto from(ReportItem r) {
        ReportItemDto dto = new ReportItemDto();
        dto.id = r.getId();
        dto.title = r.getTitle();
        dto.siteIds = r.getSiteIds();
        dto.siteNames = r.getSiteNames();
        dto.parameters = r.getParameters();
        dto.dateFrom = r.getDateFrom();
        dto.dateTo = r.getDateTo();
        dto.format = r.getFormat().toJson();
        dto.status = r.getStatus().toJson();
        dto.generatedBy = r.getGeneratedBy();
        dto.generatedAt = r.getGeneratedAt();
        dto.fileSizeKb = r.getFileSizeKb();
        return dto;
    }
}
