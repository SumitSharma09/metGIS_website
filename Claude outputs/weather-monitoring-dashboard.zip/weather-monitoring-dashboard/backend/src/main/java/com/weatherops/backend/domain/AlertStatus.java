package com.weatherops.backend.domain;

public enum AlertStatus {
    ACTIVE, ACKNOWLEDGED, RESOLVED;

    public String toJson() {
        return name().toLowerCase();
    }

    public static AlertStatus fromJson(String value) {
        try {
            return AlertStatus.valueOf(value.toUpperCase());
        } catch (IllegalArgumentException | NullPointerException ex) {
            throw new IllegalArgumentException("status must be one of: active, acknowledged, resolved");
        }
    }
}
