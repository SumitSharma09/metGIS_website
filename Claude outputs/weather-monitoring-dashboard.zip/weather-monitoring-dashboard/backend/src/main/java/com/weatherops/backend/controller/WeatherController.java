package com.weatherops.backend.controller;

import com.weatherops.backend.dto.weather.CurrentObservationDto;
import com.weatherops.backend.dto.weather.ForecastDayDto;
import com.weatherops.backend.dto.weather.HistoricalPointDto;
import com.weatherops.backend.service.WeatherService;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/weather")
public class WeatherController {

    private final WeatherService weatherService;

    public WeatherController(WeatherService weatherService) {
        this.weatherService = weatherService;
    }

    /** siteIds: comma-separated site ids (all sites if omitted).
     *  at: optional ISO-8601 instant - a past or future snapshot (used by the
     *  Live Map timeline scrubber and the Reports regional heatmap); defaults
     *  to "now" when omitted. */
    @GetMapping("/current")
    public List<CurrentObservationDto> currentObservations(
            @RequestParam(required = false) String siteIds,
            @RequestParam(required = false) String at) {
        List<String> ids = siteIds == null || siteIds.isBlank() ? List.of() : Arrays.asList(siteIds.split(","));
        Instant timestamp = at == null || at.isBlank() ? null : Instant.parse(at);
        return weatherService.currentFor(ids, timestamp);
    }

    @GetMapping("/current/{siteId}")
    public CurrentObservationDto currentForSite(@PathVariable String siteId) {
        return weatherService.currentForSite(siteId);
    }

    @GetMapping("/historical")
    public List<HistoricalPointDto> historical(
            @RequestParam String siteId,
            @RequestParam String from,
            @RequestParam String to,
            @RequestParam(required = false, defaultValue = "hourly") String interval) {
        return weatherService.historical(siteId, Instant.parse(from), Instant.parse(to), interval);
    }

    @GetMapping("/forecast/{siteId}")
    public List<ForecastDayDto> forecast(@PathVariable String siteId, @RequestParam(required = false) Integer days) {
        return weatherService.forecast(siteId, days);
    }
}
