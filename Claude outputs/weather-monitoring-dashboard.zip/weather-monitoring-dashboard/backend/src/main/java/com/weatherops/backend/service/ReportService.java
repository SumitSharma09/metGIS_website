package com.weatherops.backend.service;

import com.weatherops.backend.common.ApiException;
import com.weatherops.backend.common.PageResponse;
import com.weatherops.backend.domain.ReportFormat;
import com.weatherops.backend.domain.ReportItem;
import com.weatherops.backend.domain.ReportStatus;
import com.weatherops.backend.domain.Site;
import com.weatherops.backend.dto.report.CreateReportRequest;
import com.weatherops.backend.dto.report.ReportItemDto;
import com.weatherops.backend.notification.NotificationService;
import com.weatherops.backend.repository.ReportRepository;
import com.weatherops.backend.repository.SiteRepository;
import com.weatherops.backend.security.AccessScope;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ReportService {

    private final ReportRepository reportRepository;
    private final SiteRepository siteRepository;
    private final NotificationService notificationService;

    public ReportService(ReportRepository reportRepository, SiteRepository siteRepository, NotificationService notificationService) {
        this.reportRepository = reportRepository;
        this.siteRepository = siteRepository;
        this.notificationService = notificationService;
    }

    private Set<String> inScopeSiteIds() {
        return AccessScope.restrictToScope(siteRepository.findAll()).stream()
                .map(Site::getId)
                .collect(Collectors.toSet());
    }

    public PageResponse<ReportItemDto> listReports(String search, String status, Integer page, Integer pageSize) {
        Set<String> inScope = inScopeSiteIds();
        List<ReportItem> filtered = reportRepository.findAll().stream()
                // RBAC: a report "belongs" to the states of the sites it covers -
                // hide it unless at least one of those sites is in scope.
                .filter(r -> r.getSiteIds().stream().anyMatch(inScope::contains))
                .filter(r -> status == null || status.isBlank() || r.getStatus().toJson().equalsIgnoreCase(status))
                .filter(r -> matchesSearch(r, search))
                .sorted(Comparator.comparing(ReportItem::getGeneratedAt).reversed())
                .toList();

        int p = page == null || page < 1 ? 1 : page;
        int size = pageSize == null || pageSize < 1 ? 10 : pageSize;
        int from = Math.min((p - 1) * size, filtered.size());
        int to = Math.min(from + size, filtered.size());

        List<ReportItemDto> pageItems = filtered.subList(from, to).stream().map(ReportItemDto::from).toList();
        return new PageResponse<>(pageItems, filtered.size(), p, size);
    }

    public ReportItemDto createReport(CreateReportRequest request) {
        List<Site> sites = siteRepository.findAllById(request.siteIds);
        if (sites.isEmpty()) {
            throw ApiException.badRequest("At least one valid site is required");
        }
        // RBAC: a non-admin can only build a report out of sites within
        // their assigned states, even if they somehow know an out-of-scope
        // site ID to ask for.
        sites = AccessScope.restrictToScope(sites);
        if (sites.isEmpty()) {
            throw ApiException.badRequest("None of the requested sites are within your assigned states");
        }

        ReportItem report = new ReportItem();
        report.setId(UUID.randomUUID().toString());
        report.setTitle(request.title);
        report.setSiteIds(sites.stream().map(Site::getId).toList());
        report.setSiteNames(sites.stream().map(Site::getName).toList());
        report.setParameters(request.parameters == null ? List.of() : request.parameters);
        report.setDateFrom(request.dateFrom);
        report.setDateTo(request.dateTo);
        report.setFormat(ReportFormat.fromJson(request.format));
        // A real backend would queue generation (async job) and flip this to
        // READY once the file is produced; the demo marks it ready immediately.
        report.setStatus(ReportStatus.READY);
        report.setGeneratedBy(currentUsername());
        report.setGeneratedAt(Instant.now());
        report.setFileSizeKb((int) (80 + Math.random() * 4000));

        ReportItemDto dto = ReportItemDto.from(reportRepository.save(report));
        // Alert Delivery Matrix (scope doc section 4): a ready report goes
        // out over Email/WhatsApp too, not just the portal.
        notificationService.notifyReportReady(dto);
        return dto;
    }

    public void deleteReport(String id) {
        ReportItem report = reportRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("Report not found"));
        Set<String> inScope = inScopeSiteIds();
        if (report.getSiteIds().stream().noneMatch(inScope::contains)) {
            throw ApiException.notFound("Report not found");
        }
        reportRepository.deleteById(id);
    }

    private String currentUsername() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth != null ? auth.getName() : "system";
    }

    private boolean matchesSearch(ReportItem r, String search) {
        if (search == null || search.isBlank()) return true;
        return r.getTitle().toLowerCase().contains(search.toLowerCase());
    }
}
