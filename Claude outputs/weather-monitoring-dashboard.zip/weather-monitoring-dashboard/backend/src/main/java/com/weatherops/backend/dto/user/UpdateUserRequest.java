package com.weatherops.backend.dto.user;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public class UpdateUserRequest {
    @NotBlank
    public String fullName;

    @NotBlank
    @Email
    public String email;

    public String phone;
}
