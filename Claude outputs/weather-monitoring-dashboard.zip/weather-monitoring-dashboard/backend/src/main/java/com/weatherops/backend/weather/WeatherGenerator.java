package com.weatherops.backend.weather;

import com.weatherops.backend.domain.Site;
import com.weatherops.backend.dto.weather.CurrentObservationDto;
import com.weatherops.backend.dto.weather.ForecastDayDto;
import com.weatherops.backend.dto.weather.HistoricalPointDto;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Synthetic weather generator - the backend equivalent of the frontend's
 * src/api/mock/data/weather.ts. Deterministic per (siteId, hour) so repeat
 * requests for the same moment return identical data, with a latitude-based
 * base temperature, a monsoon-season (June-Sept) rain-chance boost, and a
 * diurnal (daily) temperature cycle. This is synthetic data for a working
 * demo/dev backend - swap it for a real weather-data integration (or a
 * persisted observations table fed by field sensors) for production use.
 */
@Component
public class WeatherGenerator {

    private static final List<String> FALLBACK_CONDITIONS = List.of("clear", "partly-cloudy", "cloudy", "clear", "fog");
    private static final DateTimeFormatter HOUR_KEY = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH");

    public CurrentObservationDto currentAt(Site site, Instant at) {
        RawObservation raw = generate(site, at);
        CurrentObservationDto dto = new CurrentObservationDto();
        dto.siteId = site.getId();
        dto.timestamp = at;
        dto.temperature = raw.temperature;
        dto.feelsLike = raw.feelsLike;
        dto.humidity = raw.humidity;
        dto.rainfallLastHour = raw.rainfallLastHour;
        dto.rainfallToday = raw.rainfallToday;
        dto.windSpeed = raw.windSpeed;
        dto.windGust = raw.windGust;
        dto.windDirection = raw.windDirection;
        dto.pressure = raw.pressure;
        dto.lightningStrikesLastHour = raw.lightningStrikesLastHour;
        dto.condition = raw.condition;
        dto.visibilityKm = raw.visibilityKm;
        return dto;
    }

    public List<HistoricalPointDto> historical(Site site, Instant from, Instant to, String interval) {
        List<HistoricalPointDto> points = new ArrayList<>();
        boolean hourly = !"daily".equalsIgnoreCase(interval);
        Instant cursor = from;
        int guard = 0;
        while (!cursor.isAfter(to) && guard < 2000) {
            RawObservation raw = generate(site, cursor);
            HistoricalPointDto point = new HistoricalPointDto();
            point.timestamp = cursor;
            point.temperature = raw.temperature;
            point.humidity = raw.humidity;
            point.rainfall = raw.rainfallLastHour;
            point.windSpeed = raw.windSpeed;
            point.pressure = raw.pressure;
            point.lightningStrikes = raw.lightningStrikesLastHour;
            points.add(point);
            cursor = hourly ? cursor.plusSeconds(3600) : cursor.plusSeconds(86400);
            guard++;
        }
        return points;
    }

    public List<ForecastDayDto> forecast(Site site, int days) {
        List<ForecastDayDto> result = new ArrayList<>();
        LocalDate today = LocalDate.now(ZoneOffset.UTC);
        for (int i = 0; i < days; i++) {
            LocalDate date = today.plusDays(i);
            result.add(forecastDay(site, date, date.toString()));
        }
        return result;
    }

    /**
     * Same synthetic model as {@link #forecast}, but lets the caller pin the
     * "as-of" day the run was issued on, independent of the real wall-clock
     * date. Two calls for the same {@code targetDate} with different
     * {@code issuedDate}s deterministically diverge - modeling how a
     * forecast model's output for a given day changes as new runs come in
     * on approach to that day. This is what the Deviation Alert Mechanism
     * (scope doc section 2) diffs successive runs against, via
     * {@link com.weatherops.backend.service.DeviationService}.
     */
    public ForecastDayDto forecastAsOf(Site site, LocalDate targetDate, LocalDate issuedDate) {
        return forecastDay(site, targetDate, targetDate + "-asof-" + issuedDate);
    }

    private ForecastDayDto forecastDay(Site site, LocalDate date, String seedKey) {
        Rng rand = new Rng(Rng.hashStringToSeed(site.getId() + "-forecast-" + seedKey));
        double base = baseTemperature(site);
        boolean monsoon = isMonsoon(date.getMonthValue());
        double minTemp = base - rand.range(3, 6);
        double maxTemp = base + rand.range(3, 7);
        int rainfallProbability = (int) Math.round(monsoon ? rand.range(40, 90) : rand.range(5, 35));
        double expectedRainfallMm = rainfallProbability > 50 ? rand.range(5, 60) : rand.range(0, 4);
        double windSpeed = rand.range(6, monsoon ? 38 : 22);
        String condition = conditionFromRainfall(expectedRainfallMm, windSpeed, rand);

        ForecastDayDto dto = new ForecastDayDto();
        dto.date = date;
        dto.minTemp = round1(minTemp);
        dto.maxTemp = round1(maxTemp);
        dto.rainfallProbability = rainfallProbability;
        dto.expectedRainfallMm = round1(expectedRainfallMm);
        dto.windSpeed = round1(windSpeed);
        dto.condition = condition;
        dto.summary = summaryFor(condition, rainfallProbability);
        return dto;
    }

    private RawObservation generate(Site site, Instant at) {
        ZonedDateTime zdt = at.atZone(ZoneOffset.UTC);
        Rng rand = new Rng(Rng.hashStringToSeed(site.getId() + "-" + HOUR_KEY.format(zdt)));

        double base = baseTemperature(site);
        int hour = zdt.getHour();
        double dailyCycle = Math.sin(((hour - 6) / 24.0) * Math.PI * 2) * 5;
        double temperature = base + dailyCycle + rand.range(-1.5, 1.5);

        boolean monsoon = isMonsoon(zdt.getMonthValue());
        double rainChance = monsoon ? 0.55 : 0.12;
        boolean isRaining = rand.next() < rainChance;
        double rainfallLastHour = isRaining ? rand.range(0.5, monsoon ? 28 : 10) : 0;
        double rainfallToday = rainfallLastHour * rand.range(1.5, 4.5);

        double windSpeed = rand.range(4, monsoon ? 45 : 28);
        double windGust = windSpeed + rand.range(2, 18);
        double humidity = monsoon ? rand.range(65, 95) : rand.range(30, 70);
        double pressure = rand.range(1000, 1018);
        int lightning = (isRaining && rand.next() > 0.5) ? (int) Math.round(rand.range(1, 40)) : 0;

        RawObservation raw = new RawObservation();
        raw.temperature = round1(temperature);
        raw.feelsLike = round1(temperature + rand.range(-1, 3));
        raw.humidity = (int) Math.round(humidity);
        raw.rainfallLastHour = round1(rainfallLastHour);
        raw.rainfallToday = round1(rainfallToday);
        raw.windSpeed = round1(windSpeed);
        raw.windGust = round1(windGust);
        raw.windDirection = (int) Math.round(rand.range(0, 359));
        raw.pressure = (int) Math.round(pressure);
        raw.lightningStrikesLastHour = lightning;
        raw.condition = conditionFromRainfall(rainfallLastHour, windSpeed, rand);
        raw.visibilityKm = round1(rand.range(isRaining ? 1 : 5, 12));
        return raw;
    }

    private double baseTemperature(Site site) {
        double latitudeFactor = Math.max(0, 30 - Math.abs(site.getLatitude()));
        return 22 + latitudeFactor * 0.35;
    }

    private boolean isMonsoon(int month) {
        return month >= 6 && month <= 9;
    }

    private String conditionFromRainfall(double rainfall, double windSpeed, Rng rand) {
        if (rainfall > 12) return "thunderstorm";
        if (rainfall > 2) return "rain";
        if (windSpeed > 35) return "windy";
        int idx = (int) (rand.next() * FALLBACK_CONDITIONS.size()) % FALLBACK_CONDITIONS.size();
        return FALLBACK_CONDITIONS.get(idx);
    }

    private String summaryFor(String condition, int rainfallProbability) {
        return switch (condition) {
            case "thunderstorm" -> "Thunderstorms likely, " + rainfallProbability + "% chance of rain";
            case "rain" -> "Rain expected, " + rainfallProbability + "% chance";
            case "windy" -> "Strong winds expected";
            case "fog" -> "Foggy conditions in the morning";
            case "cloudy" -> "Overcast through the day";
            case "partly-cloudy" -> "Partly cloudy skies";
            default -> "Clear skies expected";
        };
    }

    private double round1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }
}
