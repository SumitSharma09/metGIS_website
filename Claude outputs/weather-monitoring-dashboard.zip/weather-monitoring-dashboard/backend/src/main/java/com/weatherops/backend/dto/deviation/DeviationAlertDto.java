package com.weatherops.backend.dto.deviation;

import com.weatherops.backend.domain.DeviationAlert;

import java.time.Instant;
import java.time.LocalDate;

public class DeviationAlertDto {
    public String id;
    public String siteId;
    public String siteName;
    public LocalDate forecastDate;
    public String parameter;
    public double previousValue;
    public double updatedValue;
    public double deltaAbsolute;
    public String severity; // lowercase: 'minor' | 'moderate' | 'major'
    public LocalDate previousIssuedDate;
    public LocalDate updatedIssuedDate;
    public Instant detectedAt;
    public boolean acknowledged;
    public String message;

    public static DeviationAlertDto from(DeviationAlert d) {
        DeviationAlertDto dto = new DeviationAlertDto();
        dto.id = d.getId();
        dto.siteId = d.getSiteId();
        dto.siteName = d.getSiteName();
        dto.forecastDate = d.getForecastDate();
        dto.parameter = d.getParameter();
        dto.previousValue = d.getPreviousValue();
        dto.updatedValue = d.getUpdatedValue();
        dto.deltaAbsolute = d.getDeltaAbsolute();
        dto.severity = d.getSeverity().toJson();
        dto.previousIssuedDate = d.getPreviousIssuedDate();
        dto.updatedIssuedDate = d.getUpdatedIssuedDate();
        dto.detectedAt = d.getDetectedAt();
        dto.acknowledged = d.isAcknowledged();
        dto.message = messageFor(d);
        return dto;
    }

    private static String messageFor(DeviationAlert d) {
        String label = switch (d.getParameter()) {
            case "temperature" -> "Max temperature forecast";
            case "rainfall" -> "Rainfall forecast";
            case "windSpeed" -> "Wind speed forecast";
            default -> "Forecast";
        };
        String unit = switch (d.getParameter()) {
            case "temperature" -> "°C";
            case "rainfall" -> "mm";
            case "windSpeed" -> "km/h";
            default -> "";
        };
        return String.format(
                "%s for %s (%s) revised from %.1f%s to %.1f%s",
                label, d.getSiteName(), d.getForecastDate(), d.getPreviousValue(), unit, d.getUpdatedValue(), unit);
    }
}
