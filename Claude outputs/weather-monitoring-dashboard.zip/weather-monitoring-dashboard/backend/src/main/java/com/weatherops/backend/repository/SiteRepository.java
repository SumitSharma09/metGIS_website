package com.weatherops.backend.repository;

import com.weatherops.backend.domain.Site;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface SiteRepository extends JpaRepository<Site, String> {

    @Query("select distinct s.circle from Site s order by s.circle")
    List<String> findDistinctCircles();

    @Query("select distinct s.state from Site s order by s.state")
    List<String> findDistinctStates();

    @Query("select distinct s.district from Site s where (:state is null or s.state = :state) order by s.district")
    List<String> findDistinctDistricts(String state);
}
