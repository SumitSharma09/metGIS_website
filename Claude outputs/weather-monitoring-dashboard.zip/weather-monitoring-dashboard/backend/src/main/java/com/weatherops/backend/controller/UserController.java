package com.weatherops.backend.controller;

import com.weatherops.backend.dto.user.ChangePasswordRequest;
import com.weatherops.backend.dto.user.UpdateUserRequest;
import com.weatherops.backend.dto.user.UserProfileDto;
import com.weatherops.backend.service.UserService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public List<UserProfileDto> listUsers() {
        return userService.listUsers();
    }

    @GetMapping("/{id}")
    public UserProfileDto getUser(@PathVariable String id) {
        return userService.getUser(id);
    }

    @PutMapping("/{id}")
    public UserProfileDto updateUser(@PathVariable String id, @Valid @RequestBody UpdateUserRequest request) {
        return userService.updateUser(id, request);
    }

    @PostMapping("/{id}/change-password")
    public Map<String, Boolean> changePassword(@PathVariable String id, @Valid @RequestBody ChangePasswordRequest request) {
        userService.changePassword(id, request);
        return Map.of("success", true);
    }
}
