package com.weatherops.backend.dto.search;

import com.weatherops.backend.dto.alert.AlertItemDto;
import com.weatherops.backend.dto.report.ReportItemDto;
import com.weatherops.backend.dto.site.SiteDto;

import java.util.List;

public class SearchResultDto {
    public List<SiteDto> sites;
    public List<AlertItemDto> alerts;
    public List<ReportItemDto> reports;

    public SearchResultDto(List<SiteDto> sites, List<AlertItemDto> alerts, List<ReportItemDto> reports) {
        this.sites = sites;
        this.alerts = alerts;
        this.reports = reports;
    }
}
