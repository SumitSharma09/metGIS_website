package com.weatherops.backend.controller;

import com.weatherops.backend.dto.auth.LoginRequest;
import com.weatherops.backend.dto.auth.LoginResponse;
import com.weatherops.backend.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public LoginResponse login(@Valid @RequestBody LoginRequest request) {
        return authService.login(request);
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout() {
        // Stateless JWT: nothing to invalidate server-side in this demo; the
        // frontend clears its stored token. A production backend could
        // maintain a short-lived token denylist here if needed.
        return ResponseEntity.noContent().build();
    }
}
