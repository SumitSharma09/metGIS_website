package com.weatherops.backend.common;

/** `{ message: string }` - the error shape every frontend `*Api.ts` file expects. */
public class ErrorResponse {
    private String message;

    public ErrorResponse() {
    }

    public ErrorResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
