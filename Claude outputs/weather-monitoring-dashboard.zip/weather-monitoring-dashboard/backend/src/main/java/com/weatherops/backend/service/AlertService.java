package com.weatherops.backend.service;

import com.weatherops.backend.common.ApiException;
import com.weatherops.backend.common.PageResponse;
import com.weatherops.backend.domain.AlertItem;
import com.weatherops.backend.domain.AlertStatus;
import com.weatherops.backend.domain.Site;
import com.weatherops.backend.dto.alert.AlertItemDto;
import com.weatherops.backend.repository.AlertRepository;
import com.weatherops.backend.repository.SiteRepository;
import com.weatherops.backend.security.AccessScope;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class AlertService {

    private final AlertRepository alertRepository;
    private final SiteRepository siteRepository;

    public AlertService(AlertRepository alertRepository, SiteRepository siteRepository) {
        this.alertRepository = alertRepository;
        this.siteRepository = siteRepository;
    }

    /** IDs of sites the current user may see - every alert query is
     *  filtered against this so RBAC applies here too, not just to the
     *  Sites endpoints. */
    private Set<String> inScopeSiteIds() {
        return AccessScope.restrictToScope(siteRepository.findAll()).stream()
                .map(Site::getId)
                .collect(Collectors.toSet());
    }

    public PageResponse<AlertItemDto> listAlerts(String search, String severity, String status, String siteId,
                                                  Integer page, Integer pageSize) {
        Set<String> inScope = inScopeSiteIds();
        List<AlertItem> filtered = alertRepository.findAll().stream()
                .filter(a -> inScope.contains(a.getSiteId()))
                .filter(a -> severity == null || severity.isBlank() || a.getSeverity().toJson().equalsIgnoreCase(severity))
                .filter(a -> status == null || status.isBlank() || a.getStatus().toJson().equalsIgnoreCase(status))
                .filter(a -> siteId == null || siteId.isBlank() || a.getSiteId().equals(siteId))
                .filter(a -> matchesSearch(a, search))
                .sorted(Comparator.comparing(AlertItem::getTriggeredAt).reversed())
                .toList();

        int p = page == null || page < 1 ? 1 : page;
        int size = pageSize == null || pageSize < 1 ? 10 : pageSize;
        int from = Math.min((p - 1) * size, filtered.size());
        int to = Math.min(from + size, filtered.size());

        List<AlertItemDto> pageItems = filtered.subList(from, to).stream().map(AlertItemDto::from).toList();
        return new PageResponse<>(pageItems, filtered.size(), p, size);
    }

    public AlertItemDto getAlert(String id) {
        return AlertItemDto.from(findOrThrow(id));
    }

    public AlertItemDto markRead(String id) {
        AlertItem alert = findOrThrow(id);
        alert.setRead(true);
        return AlertItemDto.from(alertRepository.save(alert));
    }

    public AlertItemDto updateStatus(String id, String statusJson) {
        AlertItem alert = findOrThrow(id);
        AlertStatus status = AlertStatus.fromJson(statusJson);
        alert.setStatus(status);
        if (status != AlertStatus.ACTIVE) {
            alert.setRead(true);
        }
        return AlertItemDto.from(alertRepository.save(alert));
    }

    public Map<String, Long> unreadCount() {
        Set<String> inScope = inScopeSiteIds();
        long count = alertRepository.findAll().stream()
                .filter(a -> !a.isRead())
                .filter(a -> inScope.contains(a.getSiteId()))
                .count();
        return Map.of("count", count);
    }

    private AlertItem findOrThrow(String id) {
        AlertItem alert = alertRepository.findById(id).orElseThrow(() -> ApiException.notFound("Alert not found"));
        // RBAC: same "not found" (not "forbidden") pattern as SiteService -
        // don't reveal that an out-of-scope alert ID actually exists.
        if (!inScopeSiteIds().contains(alert.getSiteId())) {
            throw ApiException.notFound("Alert not found");
        }
        return alert;
    }

    private boolean matchesSearch(AlertItem a, String search) {
        if (search == null || search.isBlank()) return true;
        String q = search.toLowerCase();
        return a.getSiteName().toLowerCase().contains(q)
                || a.getMessage().toLowerCase().contains(q)
                || a.getParameter().toJson().toLowerCase().contains(q);
    }
}
