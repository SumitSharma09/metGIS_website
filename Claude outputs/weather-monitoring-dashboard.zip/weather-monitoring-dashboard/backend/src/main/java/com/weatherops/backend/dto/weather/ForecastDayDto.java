package com.weatherops.backend.dto.weather;

import java.time.LocalDate;

public class ForecastDayDto {
    public LocalDate date;
    public double minTemp;
    public double maxTemp;
    public int rainfallProbability;
    public double expectedRainfallMm;
    public double windSpeed;
    public String condition;
    public String summary;
}
