package com.weatherops.backend.seed;

import com.weatherops.backend.domain.*;
import com.weatherops.backend.repository.AlertRepository;
import com.weatherops.backend.repository.ReportRepository;
import com.weatherops.backend.repository.SiteRepository;
import com.weatherops.backend.repository.UserRepository;
import com.weatherops.backend.service.DeviationService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Seeds the in-memory H2 database on startup with the same ~20 representative
 * sites (mirroring the frontend's src/api/mock/data/sites.ts), demo users,
 * and a batch of sample alerts/reports - so the backend is immediately
 * usable without a separate data-loading step. Runs only when the database
 * is empty, so it's safe across restarts.
 */
@Component
public class DataSeeder implements CommandLineRunner {

    private final SiteRepository siteRepository;
    private final UserRepository userRepository;
    private final AlertRepository alertRepository;
    private final ReportRepository reportRepository;
    private final PasswordEncoder passwordEncoder;
    private final DeviationService deviationService;

    public DataSeeder(SiteRepository siteRepository, UserRepository userRepository,
                       AlertRepository alertRepository, ReportRepository reportRepository,
                       PasswordEncoder passwordEncoder, DeviationService deviationService) {
        this.siteRepository = siteRepository;
        this.userRepository = userRepository;
        this.alertRepository = alertRepository;
        this.reportRepository = reportRepository;
        this.passwordEncoder = passwordEncoder;
        this.deviationService = deviationService;
    }

    @Override
    public void run(String... args) {
        if (siteRepository.count() > 0) {
            return;
        }

        List<Site> sites = seedSites();
        seedUsers();
        seedAlerts(sites);
        seedReports(sites);
        seedForecastRunHistory();
    }

    /**
     * Backfills three consecutive days of forecast runs (today-2, today-1,
     * today) so the Deviation Alert Mechanism has overlapping-target-date
     * run pairs to diff on first startup, instead of an empty feature until
     * someone clicks "Run deviation check" for a few days running.
     */
    private void seedForecastRunHistory() {
        java.time.LocalDate today = java.time.LocalDate.now(java.time.ZoneOffset.UTC);
        deviationService.runCycleFor(today.minusDays(2));
        deviationService.runCycleFor(today.minusDays(1));
        deviationService.runCycleFor(today);
    }

    private List<Site> seedSites() {
        List<Site> sites = List.of(
                site("MUM-001", "Bandra Kurla Complex", "Mumbai", "Maharashtra", "Mumbai Suburban", 19.0665, 72.8686, "BKC, Bandra East, Mumbai", SiteStatus.ACTIVE, 11, "2019-03-12", "Rahul Deshmukh", "+91 98200 11223", TowerType.GBT),
                site("MUM-014", "Andheri MIDC", "Mumbai", "Maharashtra", "Mumbai Suburban", 19.1197, 72.8697, "MIDC, Andheri East, Mumbai", SiteStatus.ACTIVE, 14, "2018-07-04", "Sneha Kulkarni", "+91 98200 44556", TowerType.RTT),
                site("DEL-002", "Connaught Place", "Delhi NCR", "Delhi", "New Delhi", 28.6315, 77.2167, "Connaught Place, New Delhi", SiteStatus.ACTIVE, 216, "2017-11-20", "Vikram Singh", "+91 98110 22334", TowerType.GBT),
                site("DEL-019", "Gurugram Cyber Hub", "Delhi NCR", "Haryana", "Gurugram", 28.4949, 77.0891, "Cyber Hub, Gurugram", SiteStatus.MAINTENANCE, 227, "2020-01-15", "Anita Sharma", "+91 98110 55667", TowerType.MONOPOLE),
                site("BLR-003", "Whitefield", "Bangalore", "Karnataka", "Bengaluru Urban", 12.9698, 77.7500, "Whitefield, Bengaluru", SiteStatus.ACTIVE, 902, "2016-05-09", "Manjunath Rao", "+91 98450 33445", TowerType.GBT),
                site("BLR-021", "Electronic City", "Bangalore", "Karnataka", "Bengaluru Urban", 12.8452, 77.6602, "Electronic City Phase 1, Bengaluru", SiteStatus.ACTIVE, 884, "2021-02-27", "Divya Reddy", "+91 98450 66778", TowerType.RTT),
                site("CHN-004", "OMR IT Corridor", "Chennai", "Tamil Nadu", "Chennai", 12.8996, 80.2270, "OMR, Chennai", SiteStatus.ACTIVE, 6, "2015-09-18", "Karthik Subramaniam", "+91 98840 11223", TowerType.GBT),
                site("HYD-005", "HITEC City", "Hyderabad", "Telangana", "Hyderabad", 17.4483, 78.3915, "HITEC City, Hyderabad", SiteStatus.ACTIVE, 536, "2018-12-01", "Srinivas Rao", "+91 98490 22335", TowerType.MONOPOLE),
                site("KOL-006", "Salt Lake Sector V", "Kolkata", "West Bengal", "North 24 Parganas", 22.5726, 88.4310, "Sector V, Salt Lake, Kolkata", SiteStatus.ACTIVE, 9, "2017-06-23", "Sourav Banerjee", "+91 98300 33446", TowerType.GBT),
                site("PUN-007", "Hinjewadi Phase 2", "Pune", "Maharashtra", "Pune", 18.5908, 73.7397, "Hinjewadi, Pune", SiteStatus.ACTIVE, 560, "2019-08-30", "Prasad Joshi", "+91 98220 44557", TowerType.RTT),
                site("AHM-008", "SG Highway", "Ahmedabad", "Gujarat", "Ahmedabad", 23.0395, 72.5066, "SG Highway, Ahmedabad", SiteStatus.INACTIVE, 53, "2014-04-11", "Nirav Patel", "+91 98790 55668", TowerType.GBT),
                site("JAI-009", "Malviya Nagar", "Jaipur", "Rajasthan", "Jaipur", 26.8544, 75.8055, "Malviya Nagar, Jaipur", SiteStatus.ACTIVE, 431, "2020-10-02", "Rohit Agarwal", "+91 98290 66779", TowerType.MONOPOLE),
                site("LKO-010", "Gomti Nagar", "Lucknow", "Uttar Pradesh", "Lucknow", 26.8467, 81.0331, "Gomti Nagar, Lucknow", SiteStatus.ACTIVE, 123, "2016-01-19", "Amit Verma", "+91 98390 77880", TowerType.GBT),
                site("BHO-011", "Arera Colony", "Bhopal", "Madhya Pradesh", "Bhopal", 23.2156, 77.4126, "Arera Colony, Bhopal", SiteStatus.ACTIVE, 527, "2018-03-28", "Deepak Chouhan", "+91 98262 88991", TowerType.RTT),
                site("PAT-012", "Boring Road", "Patna", "Bihar", "Patna", 25.6127, 85.1197, "Boring Road, Patna", SiteStatus.MAINTENANCE, 53, "2015-12-07", "Rajesh Kumar", "+91 98350 99002", TowerType.GBT),
                site("GUW-013", "Ganeshguri", "Guwahati", "Assam", "Kamrup Metropolitan", 26.1584, 91.7896, "Ganeshguri, Guwahati", SiteStatus.ACTIVE, 55, "2019-05-14", "Bikash Bora", "+91 98640 10112", TowerType.MONOPOLE),
                site("CHD-015", "Sector 17", "Chandigarh", "Chandigarh", "Chandigarh", 30.7410, 76.7822, "Sector 17, Chandigarh", SiteStatus.ACTIVE, 321, "2017-02-08", "Harpreet Singh", "+91 98150 21123", TowerType.GBT),
                site("KOC-016", "Infopark Kakkanad", "Kochi", "Kerala", "Ernakulam", 10.0159, 76.3419, "Infopark, Kochi", SiteStatus.ACTIVE, 8, "2021-06-25", "Anoop Menon", "+91 98470 32234", TowerType.RTT),
                site("IND-017", "Vijay Nagar", "Indore", "Madhya Pradesh", "Indore", 22.7533, 75.8937, "Vijay Nagar, Indore", SiteStatus.ACTIVE, 553, "2016-09-16", "Sanjay Malhotra", "+91 98261 43345", TowerType.GBT),
                site("NAG-018", "Civil Lines", "Nagpur", "Maharashtra", "Nagpur", 21.1544, 79.0821, "Civil Lines, Nagpur", SiteStatus.ACTIVE, 310, "2020-04-04", "Pooja Deshpande", "+91 98220 54456", TowerType.MONOPOLE)
        );
        return siteRepository.saveAll(sites);
    }

    private Site site(String code, String name, String circle, String state, String district,
                       double lat, double lng, String address, SiteStatus status, int elevation,
                       String installedOn, String contact, String phone, TowerType towerType) {
        Site s = new Site();
        s.setId(UUID.randomUUID().toString());
        s.setCode(code);
        s.setName(name);
        s.setCircle(circle);
        s.setState(state);
        s.setDistrict(district);
        s.setLatitude(lat);
        s.setLongitude(lng);
        s.setAddress(address);
        s.setStatus(status);
        s.setElevationMeters(elevation);
        s.setInstalledOn(LocalDate.parse(installedOn));
        s.setContactPerson(contact);
        s.setContactPhone(phone);
        s.setTowerType(towerType);
        return s;
    }

    private void seedUsers() {
        userRepository.saveAll(List.of(
                // ADMIN stays Pan-India (empty assignedStates - AccessScope treats
                // ADMIN as unrestricted regardless of this set).
                user("admin", "admin123", "Sumit Sharma", "admin@weatherops.example", Role.ADMIN, List.of()),
                // OPERATOR scoped to the Delhi NCR circle's two states, so the
                // RBAC restriction is visible immediately against seeded data.
                user("operator", "operator123", "Priya Nair", "operator@weatherops.example", Role.OPERATOR, List.of("Delhi", "Haryana")),
                // VIEWER scoped to a single state (Karnataka).
                user("viewer", "viewer123", "Arjun Mehta", "viewer@weatherops.example", Role.VIEWER, List.of("Karnataka"))
        ));
    }

    private User user(String username, String password, String fullName, String email, Role role, List<String> assignedStates) {
        User u = new User();
        u.setId(UUID.randomUUID().toString());
        u.setUsername(username);
        u.setPasswordHash(passwordEncoder.encode(password));
        u.setFullName(fullName);
        u.setEmail(email);
        u.setPhone("+91 90000 00000");
        u.setRole(role);
        u.setAssignedStates(new java.util.LinkedHashSet<>(assignedStates));
        return u;
    }

    private void seedAlerts(List<Site> sites) {
        Random rand = new Random(42);
        AlertSeverity[] severities = AlertSeverity.values();
        AlertStatus[] statuses = AlertStatus.values();
        WeatherParameter[] parameters = {
                WeatherParameter.WIND_SPEED, WeatherParameter.RAINFALL, WeatherParameter.LIGHTNING,
                WeatherParameter.TEMPERATURE, WeatherParameter.HUMIDITY, WeatherParameter.PRESSURE
        };

        List<AlertItem> alerts = new java.util.ArrayList<>();
        for (int i = 0; i < 42; i++) {
            Site site = sites.get(rand.nextInt(sites.size()));
            WeatherParameter parameter = parameters[rand.nextInt(parameters.length)];
            AlertSeverity severity = severities[rand.nextInt(severities.length)];
            AlertStatus status = statuses[rand.nextInt(statuses.length)];

            double threshold = thresholdFor(parameter);
            double observed = threshold + rand.nextDouble() * threshold * 0.6;
            Instant triggeredAt = Instant.now().minus(rand.nextInt(24 * 21), ChronoUnit.HOURS);
            Instant expiresAt = triggeredAt.plus(6 + rand.nextInt(42), ChronoUnit.HOURS);

            AlertItem alert = new AlertItem();
            alert.setId(UUID.randomUUID().toString());
            alert.setSiteId(site.getId());
            alert.setSiteName(site.getName());
            alert.setSeverity(severity);
            alert.setParameter(parameter);
            alert.setMessage(messageFor(parameter) + " at " + site.getName());
            alert.setThresholdValue(Math.round(threshold * 10) / 10.0);
            alert.setObservedValue(Math.round(observed * 10) / 10.0);
            alert.setUnit(unitFor(parameter));
            alert.setTriggeredAt(triggeredAt);
            alert.setExpiresAt(expiresAt);
            alert.setStatus(status);
            alert.setRead(status != AlertStatus.ACTIVE || rand.nextDouble() > 0.4);
            alerts.add(alert);
        }
        alertRepository.saveAll(alerts);
    }

    private void seedReports(List<Site> sites) {
        String[] titles = {
                "Monthly Rainfall Summary", "Wind Speed Trend Report", "Lightning Incident Report",
                "Site-wise Weather Compliance", "Quarterly Climate Overview"
        };
        String[] authors = {"Sumit Sharma", "Priya Nair", "Arjun Mehta", "Kavita Iyer"};
        ReportFormat[] formats = ReportFormat.values();
        Random rand = new Random(7);

        List<ReportItem> reports = new java.util.ArrayList<>();
        for (int i = 0; i < 10; i++) {
            List<Site> chosen = sites.subList(0, Math.min(sites.size(), 2 + rand.nextInt(3)));
            Instant generatedAt = Instant.now().minus(rand.nextInt(30), ChronoUnit.DAYS);

            ReportItem report = new ReportItem();
            report.setId(UUID.randomUUID().toString());
            report.setTitle(titles[rand.nextInt(titles.length)] + " #" + (i + 1));
            report.setSiteIds(chosen.stream().map(Site::getId).toList());
            report.setSiteNames(chosen.stream().map(Site::getName).toList());
            report.setParameters(List.of("temperature", "rainfall", "windSpeed"));
            report.setDateFrom(LocalDate.now().minusDays(30));
            report.setDateTo(LocalDate.now().minusDays(1));
            report.setFormat(formats[rand.nextInt(formats.length)]);
            report.setStatus(ReportStatus.READY);
            report.setGeneratedBy(authors[rand.nextInt(authors.length)]);
            report.setGeneratedAt(generatedAt);
            report.setFileSizeKb(80 + rand.nextInt(4000));
            reports.add(report);
        }
        reportRepository.saveAll(reports);
    }

    private double thresholdFor(WeatherParameter parameter) {
        return switch (parameter) {
            case WIND_SPEED -> 40;
            case RAINFALL -> 20;
            case LIGHTNING -> 10;
            case TEMPERATURE -> 42;
            case HUMIDITY -> 95;
            case PRESSURE -> 995;
            default -> 0;
        };
    }

    private String unitFor(WeatherParameter parameter) {
        return switch (parameter) {
            case WIND_SPEED -> "km/h";
            case RAINFALL -> "mm/hr";
            case LIGHTNING -> "strikes";
            case TEMPERATURE -> "°C";
            case HUMIDITY -> "%";
            case PRESSURE -> "hPa";
            default -> "°";
        };
    }

    private String messageFor(WeatherParameter parameter) {
        return switch (parameter) {
            case WIND_SPEED -> "High wind speed detected";
            case RAINFALL -> "Heavy rainfall detected";
            case LIGHTNING -> "Lightning activity detected nearby";
            case TEMPERATURE -> "Extreme temperature detected";
            case HUMIDITY -> "Abnormal humidity levels";
            case PRESSURE -> "Rapid pressure drop detected";
            default -> "Sudden wind direction shift";
        };
    }
}
