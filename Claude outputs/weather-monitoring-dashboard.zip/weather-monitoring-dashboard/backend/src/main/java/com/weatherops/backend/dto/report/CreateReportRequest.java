package com.weatherops.backend.dto.report;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.util.List;

public class CreateReportRequest {
    @NotBlank
    public String title;

    @NotEmpty
    public List<String> siteIds;

    public List<String> parameters;

    @NotNull
    public LocalDate dateFrom;

    @NotNull
    public LocalDate dateTo;

    @NotBlank
    public String format; // 'pdf' | 'csv' | 'xlsx'
}
