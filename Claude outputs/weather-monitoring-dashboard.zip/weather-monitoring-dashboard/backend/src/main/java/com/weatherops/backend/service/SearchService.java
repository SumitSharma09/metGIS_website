package com.weatherops.backend.service;

import com.weatherops.backend.domain.AlertItem;
import com.weatherops.backend.domain.ReportItem;
import com.weatherops.backend.domain.Site;
import com.weatherops.backend.dto.alert.AlertItemDto;
import com.weatherops.backend.dto.report.ReportItemDto;
import com.weatherops.backend.dto.search.SearchResultDto;
import com.weatherops.backend.dto.site.SiteDto;
import com.weatherops.backend.repository.AlertRepository;
import com.weatherops.backend.repository.ReportRepository;
import com.weatherops.backend.repository.SiteRepository;
import com.weatherops.backend.security.AccessScope;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Service
public class SearchService {

    private static final int MAX_RESULTS_PER_TYPE = 5;

    private final SiteRepository siteRepository;
    private final AlertRepository alertRepository;
    private final ReportRepository reportRepository;

    public SearchService(SiteRepository siteRepository, AlertRepository alertRepository, ReportRepository reportRepository) {
        this.siteRepository = siteRepository;
        this.alertRepository = alertRepository;
        this.reportRepository = reportRepository;
    }

    public SearchResultDto search(String query) {
        if (query == null || query.isBlank()) {
            return new SearchResultDto(java.util.List.of(), java.util.List.of(), java.util.List.of());
        }
        String q = query.toLowerCase();

        // RBAC: search must never surface a site, alert or report outside
        // the caller's assigned states, so every result type is filtered
        // through the same in-scope site-id set.
        Set<String> inScopeSiteIds = AccessScope.restrictToScope(siteRepository.findAll()).stream()
                .map(Site::getId)
                .collect(Collectors.toSet());

        var sites = siteRepository.findAll().stream()
                .filter(s -> inScopeSiteIds.contains(s.getId()))
                .filter(s -> matches(s, q))
                .limit(MAX_RESULTS_PER_TYPE)
                .map(SiteDto::from)
                .toList();

        var alerts = alertRepository.findAll().stream()
                .filter(a -> inScopeSiteIds.contains(a.getSiteId()))
                .filter(a -> a.getMessage().toLowerCase().contains(q) || a.getSiteName().toLowerCase().contains(q))
                .limit(MAX_RESULTS_PER_TYPE)
                .map(AlertItemDto::from)
                .toList();

        var reports = reportRepository.findAll().stream()
                .filter(r -> r.getSiteIds().stream().anyMatch(inScopeSiteIds::contains))
                .filter(r -> r.getTitle().toLowerCase().contains(q))
                .limit(MAX_RESULTS_PER_TYPE)
                .map(ReportItemDto::from)
                .toList();

        return new SearchResultDto(sites, alerts, reports);
    }

    private boolean matches(Site s, String q) {
        return s.getName().toLowerCase().contains(q)
                || s.getCode().toLowerCase().contains(q)
                || s.getState().toLowerCase().contains(q)
                || s.getDistrict().toLowerCase().contains(q);
    }
}
