package com.weatherops.backend.repository;

import com.weatherops.backend.domain.AlertItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlertRepository extends JpaRepository<AlertItem, String> {
    long countByReadFalse();
}
