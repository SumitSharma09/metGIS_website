package com.weatherops.backend.controller;

import com.weatherops.backend.dto.search.SearchResultDto;
import com.weatherops.backend.service.SearchService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SearchController {

    private final SearchService searchService;

    public SearchController(SearchService searchService) {
        this.searchService = searchService;
    }

    @GetMapping("/search")
    public SearchResultDto search(@RequestParam(name = "q", required = false) String query) {
        return searchService.search(query);
    }
}
