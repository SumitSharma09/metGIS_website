package com.weatherops.backend.domain;

public enum ReportStatus {
    READY, PROCESSING, FAILED;

    public String toJson() {
        return name().toLowerCase();
    }
}
