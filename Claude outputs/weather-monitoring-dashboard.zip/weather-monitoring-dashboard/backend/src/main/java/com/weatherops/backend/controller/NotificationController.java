package com.weatherops.backend.controller;

import com.weatherops.backend.dto.notification.TestNotificationRequest;
import com.weatherops.backend.notification.NotificationService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * WhatsApp/Email delivery channels (scope doc sections 1 & 4). Both
 * channels are scaffolds until real credentials are added to
 * application.yml (see EmailNotificationChannel / WhatsAppNotificationChannel) -
 * GET /notifications/status shows which ones are actually live, and
 * POST /notifications/test lets an admin confirm the wiring either way
 * (a not-yet-configured channel just logs what it would have sent).
 */
@RestController
@RequestMapping("/notifications")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping("/status")
    public Map<String, Boolean> status() {
        return notificationService.channelStatus();
    }

    @PostMapping("/test")
    public Map<String, Object> sendTest(@Valid @RequestBody TestNotificationRequest request) {
        notificationService.sendTest(request.message, request.recipientEmail, request.recipientPhone);
        return Map.of(
                "sent", true,
                "anyChannelLive", notificationService.anyChannelLive(),
                "channels", notificationService.channelStatus());
    }
}
