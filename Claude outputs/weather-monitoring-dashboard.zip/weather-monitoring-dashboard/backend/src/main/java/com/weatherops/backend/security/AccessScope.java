package com.weatherops.backend.security;

import com.weatherops.backend.domain.Site;
import com.weatherops.backend.domain.User;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;
import java.util.Optional;

/**
 * Central place for role-based-access-control scoping (scope doc section
 * 5, "Role-Based Access Control"): an ADMIN sees every site/circle/state/
 * district Pan-India, while an OPERATOR/VIEWER only sees the states
 * assigned to their account ({@link User#getAssignedStates()}).
 * <p>
 * Every service that enumerates sites - and everything derived from sites
 * (weather, alerts, reports, dashboard stats, search) - should filter
 * through {@link #restrictToScope(List)} / {@link #canAccessState(String)}
 * rather than reading straight from the repository, or RBAC silently does
 * nothing for that endpoint.
 */
public final class AccessScope {

    private AccessScope() {}

    public static Optional<User> currentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !(auth.getPrincipal() instanceof UserPrincipal principal)) {
            return Optional.empty();
        }
        return Optional.of(principal.getUser());
    }

    /** True for ADMIN, or when there's no authenticated user in context
     *  (every real HTTP request here is already required to authenticate
     *  by SecurityConfig, so this only affects a code path invoked outside
     *  a request - none exist today, but "fail open" would be the wrong
     *  default if one appears, so this stays narrow to ADMIN-or-absent). */
    public static boolean isPanIndia() {
        return currentUser().map(User::isAdmin).orElse(true);
    }

    public static boolean canAccessState(String state) {
        if (state == null || isPanIndia()) return true;
        return currentUser()
                .map(u -> u.getAssignedStates().stream().anyMatch(s -> s.equalsIgnoreCase(state)))
                .orElse(false);
    }

    public static List<Site> restrictToScope(List<Site> sites) {
        if (isPanIndia()) return sites;
        return sites.stream().filter(s -> canAccessState(s.getState())).toList();
    }
}
