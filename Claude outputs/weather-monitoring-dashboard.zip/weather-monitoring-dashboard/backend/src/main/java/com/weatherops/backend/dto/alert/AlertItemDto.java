package com.weatherops.backend.dto.alert;

import com.weatherops.backend.domain.AlertItem;

import java.time.Instant;

public class AlertItemDto {
    public String id;
    public String siteId;
    public String siteName;
    public String severity;
    public String parameter;
    public String message;
    public double thresholdValue;
    public double observedValue;
    public String unit;
    public Instant triggeredAt;
    public Instant expiresAt;
    public String status;
    public boolean read;

    public static AlertItemDto from(AlertItem a) {
        AlertItemDto dto = new AlertItemDto();
        dto.id = a.getId();
        dto.siteId = a.getSiteId();
        dto.siteName = a.getSiteName();
        dto.severity = a.getSeverity().toJson();
        dto.parameter = a.getParameter().toJson();
        dto.message = a.getMessage();
        dto.thresholdValue = a.getThresholdValue();
        dto.observedValue = a.getObservedValue();
        dto.unit = a.getUnit();
        dto.triggeredAt = a.getTriggeredAt();
        dto.expiresAt = a.getExpiresAt();
        dto.status = a.getStatus().toJson();
        dto.read = a.isRead();
        return dto;
    }
}
