package com.weatherops.backend.dto.notification;

import jakarta.validation.constraints.NotBlank;

/** Body for POST /notifications/test - lets an admin confirm the
 *  Email/WhatsApp wiring (scope doc sections 1 & 4) once real credentials
 *  are added to application.yml, without waiting for a real alert/report/
 *  deviation to trigger one. */
public class TestNotificationRequest {

    @NotBlank
    public String message;

    /** Optional - falls back to app.notifications.default-recipient-email. */
    public String recipientEmail;

    /** Optional - falls back to app.notifications.default-recipient-phone. */
    public String recipientPhone;
}
