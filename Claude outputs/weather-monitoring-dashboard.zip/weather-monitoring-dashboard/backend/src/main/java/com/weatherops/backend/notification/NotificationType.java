package com.weatherops.backend.notification;

/** What kind of message this is (scope doc's Alert Delivery Matrix:
 *  Daily Report / Deviation Alert / Advisory all go out over the same
 *  Email + WhatsApp + Portal channels). Purely informational here -
 *  it doesn't change delivery behavior, only what gets logged/labeled. */
public enum NotificationType {
    DAILY_REPORT,
    DEVIATION_ALERT,
    THRESHOLD_ALERT,
    WEEKLY_ADVISORY,
    TEST
}
