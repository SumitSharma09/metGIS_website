package com.weatherops.backend.repository;

import com.weatherops.backend.domain.ForecastRun;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ForecastRunRepository extends JpaRepository<ForecastRun, String> {

    Optional<ForecastRun> findBySiteIdAndForecastDateAndIssuedDate(String siteId, LocalDate forecastDate, LocalDate issuedDate);

    /** Most recent prior run for the same target day, strictly before the
     *  given issued date - the "previous" side of the diff. */
    Optional<ForecastRun> findTopBySiteIdAndForecastDateAndIssuedDateLessThanOrderByIssuedDateDesc(
            String siteId, LocalDate forecastDate, LocalDate issuedDate);

    List<ForecastRun> findBySiteIdAndForecastDate(String siteId, LocalDate forecastDate);
}
