package com.weatherops.backend.weather;

/** Internal full observation - mapped to CurrentObservationDto or HistoricalPointDto by the caller. */
class RawObservation {
    double temperature;
    double feelsLike;
    int humidity;
    double rainfallLastHour;
    double rainfallToday;
    double windSpeed;
    double windGust;
    int windDirection;
    int pressure;
    int lightningStrikesLastHour;
    String condition;
    double visibilityKm;
}
