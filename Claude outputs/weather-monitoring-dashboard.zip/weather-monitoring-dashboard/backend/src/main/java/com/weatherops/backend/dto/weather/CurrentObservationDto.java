package com.weatherops.backend.dto.weather;

import java.time.Instant;

public class CurrentObservationDto {
    public String siteId;
    public Instant timestamp;
    public double temperature;
    public double feelsLike;
    public int humidity;
    public double rainfallLastHour;
    public double rainfallToday;
    public double windSpeed;
    public double windGust;
    public int windDirection;
    public int pressure;
    public int lightningStrikesLastHour;
    public String condition; // WeatherCondition union
    public double visibilityKm;
}
