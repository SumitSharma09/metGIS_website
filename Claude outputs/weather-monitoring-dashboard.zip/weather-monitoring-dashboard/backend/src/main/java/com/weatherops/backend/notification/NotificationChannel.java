package com.weatherops.backend.notification;

/**
 * One delivery channel (Email, WhatsApp, ...). Implementations are pluggable:
 * {@link NotificationService} sends every enabled channel each message and
 * doesn't care which underlying provider it uses.
 */
public interface NotificationChannel {

    String getChannelName();

    /** Whether this channel has real credentials configured. When false,
     *  the channel should still accept {@link #send} calls (so callers
     *  don't need to check first) but only log its intent rather than
     *  attempt a real delivery. */
    boolean isConfigured();

    void send(NotificationMessage message);
}
