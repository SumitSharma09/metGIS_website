package com.weatherops.backend.domain;

public enum AlertSeverity {
    CRITICAL, HIGH, MODERATE, LOW, INFO;

    public String toJson() {
        return name().toLowerCase();
    }
}
