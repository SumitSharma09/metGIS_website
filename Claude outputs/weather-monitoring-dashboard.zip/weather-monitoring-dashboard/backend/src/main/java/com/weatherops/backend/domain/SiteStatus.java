package com.weatherops.backend.domain;

public enum SiteStatus {
    ACTIVE, INACTIVE, MAINTENANCE;

    /** Serializes to the frontend's lowercase literal union ('active' | 'inactive' | 'maintenance'). */
    public String toJson() {
        return name().toLowerCase();
    }
}
