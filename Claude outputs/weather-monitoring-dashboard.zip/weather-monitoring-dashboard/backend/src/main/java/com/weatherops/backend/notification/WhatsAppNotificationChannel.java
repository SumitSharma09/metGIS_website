package com.weatherops.backend.notification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * WhatsApp delivery channel (scope doc sections 1 & 4 - Daily Report /
 * Deviation Alert / Advisory all go out over WhatsApp too, per the Alert
 * Delivery Matrix).
 * <p>
 * Same scaffold-only status as {@link EmailNotificationChannel}:
 * {@code app.notifications.whatsapp.enabled} defaults to false, and
 * {@link #send} only logs what it would have sent, since sending a real
 * message needs a WhatsApp Business API (or BSP) phone-number-id and
 * access token the user hasn't supplied. To go live: add an HTTP client
 * call to the configured {@code api-url} with the access token, following
 * whichever provider's WhatsApp template-message API the partner uses -
 * everything else (config keys, the NotificationService call sites) is
 * already in place.
 */
@Component
public class WhatsAppNotificationChannel implements NotificationChannel {

    private static final Logger log = LoggerFactory.getLogger(WhatsAppNotificationChannel.class);

    private final boolean enabled;
    private final String apiUrl;
    private final String phoneNumberId;
    private final String accessToken;

    public WhatsAppNotificationChannel(
            @Value("${app.notifications.whatsapp.enabled:false}") boolean enabled,
            @Value("${app.notifications.whatsapp.api-url:}") String apiUrl,
            @Value("${app.notifications.whatsapp.phone-number-id:}") String phoneNumberId,
            @Value("${app.notifications.whatsapp.access-token:}") String accessToken) {
        this.enabled = enabled;
        this.apiUrl = apiUrl;
        this.phoneNumberId = phoneNumberId;
        this.accessToken = accessToken;
    }

    @Override
    public String getChannelName() {
        return "whatsapp";
    }

    @Override
    public boolean isConfigured() {
        return enabled && !phoneNumberId.isBlank() && !accessToken.isBlank();
    }

    @Override
    public void send(NotificationMessage message) {
        String to = message.getRecipientPhone();
        if (to == null || to.isBlank()) {
            log.warn("[whatsapp] Skipped {} - no recipient phone configured or supplied", message.getType());
            return;
        }
        if (!isConfigured()) {
            log.info("[whatsapp] (not configured - would POST to {}/{}/messages) To: {} | {}",
                    apiUrl.isBlank() ? "<unset api-url>" : apiUrl,
                    phoneNumberId.isBlank() ? "<unset phone-number-id>" : phoneNumberId, to, message.getBody());
            return;
        }
        // TODO(real integration): POST to {apiUrl}/{phoneNumberId}/messages
        // with the access token once WhatsApp Business API credentials are
        // supplied. Left as a log line until then so the rest of the
        // pipeline is fully wired and testable without live credentials.
        log.info("[whatsapp] Sending via {} To: {} | {}", apiUrl, to, message.getBody());
    }
}
