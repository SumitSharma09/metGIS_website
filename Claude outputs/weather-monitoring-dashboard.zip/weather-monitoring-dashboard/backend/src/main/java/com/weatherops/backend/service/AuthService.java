package com.weatherops.backend.service;

import com.weatherops.backend.common.ApiException;
import com.weatherops.backend.domain.User;
import com.weatherops.backend.dto.auth.LoginRequest;
import com.weatherops.backend.dto.auth.LoginResponse;
import com.weatherops.backend.dto.user.UserProfileDto;
import com.weatherops.backend.repository.UserRepository;
import com.weatherops.backend.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public LoginResponse login(LoginRequest request) {
        User user = userRepository.findByUsernameIgnoreCase(request.username)
                .orElseThrow(() -> ApiException.unauthorized("Invalid username or password"));

        if (!passwordEncoder.matches(request.password, user.getPasswordHash())) {
            throw ApiException.unauthorized("Invalid username or password");
        }

        user.setLastLoginAt(Instant.now());
        userRepository.save(user);

        String token = jwtService.generateToken(user);
        return new LoginResponse(token, UserProfileDto.from(user));
    }
}
