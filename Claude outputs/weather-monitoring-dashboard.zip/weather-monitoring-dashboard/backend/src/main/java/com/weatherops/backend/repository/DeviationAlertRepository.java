package com.weatherops.backend.repository;

import com.weatherops.backend.domain.DeviationAlert;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeviationAlertRepository extends JpaRepository<DeviationAlert, String> {
}
