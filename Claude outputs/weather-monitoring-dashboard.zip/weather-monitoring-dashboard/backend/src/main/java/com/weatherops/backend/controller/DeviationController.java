package com.weatherops.backend.controller;

import com.weatherops.backend.common.PageResponse;
import com.weatherops.backend.dto.deviation.DeviationAlertDto;
import com.weatherops.backend.service.DeviationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Deviation Alert Mechanism (scope doc section 2). GET /deviations lists
 * detected forecast-run deviations (RBAC-scoped, same as /alerts);
 * POST /deviations/run manually triggers a check (a real deployment would
 * put this on a daily scheduler instead).
 */
@RestController
@RequestMapping("/deviations")
public class DeviationController {

    private final DeviationService deviationService;

    public DeviationController(DeviationService deviationService) {
        this.deviationService = deviationService;
    }

    @GetMapping
    public PageResponse<DeviationAlertDto> listDeviations(
            @RequestParam(required = false) String siteId,
            @RequestParam(required = false) String severity,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer pageSize) {
        return deviationService.listDeviations(siteId, severity, page, pageSize);
    }

    @PostMapping("/run")
    public List<DeviationAlertDto> runCheck() {
        return deviationService.runDailyCycle();
    }

    @PatchMapping("/{id}/acknowledge")
    public DeviationAlertDto acknowledge(@PathVariable String id) {
        return deviationService.acknowledge(id);
    }
}
