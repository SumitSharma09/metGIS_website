package com.weatherops.backend.domain;

/** How large a swing between two successive forecast runs is, for one
 *  parameter of one site/day (scope doc section 2, Deviation Alert
 *  Mechanism). Thresholds live in DeviationService, next to the parameter
 *  they classify. */
public enum DeviationSeverity {
    MINOR,
    MODERATE,
    MAJOR;

    public String toJson() {
        return name().toLowerCase();
    }

    public static DeviationSeverity fromJson(String value) {
        return DeviationSeverity.valueOf(value.toUpperCase());
    }
}
