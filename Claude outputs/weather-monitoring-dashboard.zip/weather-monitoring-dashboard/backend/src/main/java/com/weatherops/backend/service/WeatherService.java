package com.weatherops.backend.service;

import com.weatherops.backend.domain.Site;
import com.weatherops.backend.dto.weather.CurrentObservationDto;
import com.weatherops.backend.dto.weather.ForecastDayDto;
import com.weatherops.backend.dto.weather.HistoricalPointDto;
import com.weatherops.backend.repository.SiteRepository;
import com.weatherops.backend.security.AccessScope;
import com.weatherops.backend.weather.WeatherGenerator;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class WeatherService {

    private final SiteRepository siteRepository;
    private final SiteService siteService;
    private final WeatherGenerator generator;

    public WeatherService(SiteRepository siteRepository, SiteService siteService, WeatherGenerator generator) {
        this.siteRepository = siteRepository;
        this.siteService = siteService;
        this.generator = generator;
    }

    public List<CurrentObservationDto> currentFor(List<String> siteIds, Instant at) {
        Instant timestamp = at != null ? at : Instant.now();
        List<Site> sites = (siteIds == null || siteIds.isEmpty())
                ? siteRepository.findAll()
                : siteRepository.findAllById(siteIds);
        // RBAC: whether the caller asked for "all sites" or named specific
        // IDs, a non-admin only ever gets observations for sites in scope.
        sites = AccessScope.restrictToScope(sites);
        return sites.stream().map(s -> generator.currentAt(s, timestamp)).toList();
    }

    public CurrentObservationDto currentForSite(String siteId) {
        Site site = siteService.findOrThrow(siteId);
        return generator.currentAt(site, Instant.now());
    }

    public List<HistoricalPointDto> historical(String siteId, Instant from, Instant to, String interval) {
        Site site = siteService.findOrThrow(siteId);
        return generator.historical(site, from, to, interval);
    }

    public List<ForecastDayDto> forecast(String siteId, Integer days) {
        Site site = siteService.findOrThrow(siteId);
        return generator.forecast(site, days == null ? 7 : days);
    }
}
