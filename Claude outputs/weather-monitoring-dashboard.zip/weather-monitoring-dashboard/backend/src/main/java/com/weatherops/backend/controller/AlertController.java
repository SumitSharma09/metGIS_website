package com.weatherops.backend.controller;

import com.weatherops.backend.common.PageResponse;
import com.weatherops.backend.dto.alert.AlertItemDto;
import com.weatherops.backend.dto.alert.UpdateAlertStatusRequest;
import com.weatherops.backend.service.AlertService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/alerts")
public class AlertController {

    private final AlertService alertService;

    public AlertController(AlertService alertService) {
        this.alertService = alertService;
    }

    @GetMapping
    public PageResponse<AlertItemDto> listAlerts(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String severity,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String siteId,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer pageSize) {
        return alertService.listAlerts(search, severity, status, siteId, page, pageSize);
    }

    // Registered before "/{id}" for readability; Spring dispatches by specificity regardless of order.
    @GetMapping("/unread-count")
    public Map<String, Long> unreadCount() {
        return alertService.unreadCount();
    }

    @GetMapping("/{id}")
    public AlertItemDto getAlert(@PathVariable String id) {
        return alertService.getAlert(id);
    }

    @PatchMapping("/{id}/read")
    public AlertItemDto markRead(@PathVariable String id) {
        return alertService.markRead(id);
    }

    @PatchMapping("/{id}/status")
    public AlertItemDto updateStatus(@PathVariable String id, @Valid @RequestBody UpdateAlertStatusRequest request) {
        return alertService.updateStatus(id, request.status);
    }
}
