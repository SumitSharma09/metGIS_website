package com.weatherops.backend.dto.alert;

import jakarta.validation.constraints.NotBlank;

public class UpdateAlertStatusRequest {
    @NotBlank
    public String status; // 'active' | 'acknowledged' | 'resolved'
}
