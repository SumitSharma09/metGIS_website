package com.weatherops.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendApplicationTests {

    @Test
    void contextLoads() {
        // Verifies the Spring context (security, JPA, controllers, seeder) wires up cleanly.
    }
}
