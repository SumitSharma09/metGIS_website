"""Ramer-Douglas-Peucker line simplification applied per-ring to a
FeatureCollection of Polygon/MultiPolygon features, to shrink the
hand-converted Survey-of-India-derived state/district boundary files down
to a size reasonable to ship as a static asset with the frontend app.
Pure Python, no dependencies (same reasoning as shp_to_geojson.py)."""
import json
import sys


def perpendicular_distance(pt, start, end):
    (x, y), (x1, y1), (x2, y2) = pt, start, end
    dx, dy = x2 - x1, y2 - y1
    if dx == 0 and dy == 0:
        return ((x - x1) ** 2 + (y - y1) ** 2) ** 0.5
    t = ((x - x1) * dx + (y - y1) * dy) / (dx * dx + dy * dy)
    t = max(0.0, min(1.0, t))
    proj_x, proj_y = x1 + t * dx, y1 + t * dy
    return ((x - proj_x) ** 2 + (y - proj_y) ** 2) ** 0.5


def rdp(points, epsilon):
    if len(points) < 3:
        return points
    start, end = points[0], points[-1]
    max_dist = 0.0
    idx = 0
    for i in range(1, len(points) - 1):
        d = perpendicular_distance(points[i], start, end)
        if d > max_dist:
            max_dist = d
            idx = i
    if max_dist > epsilon:
        left = rdp(points[:idx + 1], epsilon)
        right = rdp(points[idx:], epsilon)
        return left[:-1] + right
    return [start, end]


def simplify_ring(ring, epsilon, min_points=4):
    simplified = rdp(ring, epsilon)
    if len(simplified) < min_points:
        return ring  # keep original rather than degenerate a tiny ring away
    if simplified[0] != simplified[-1]:
        simplified.append(simplified[0])
    return simplified


def simplify_geometry(geom, epsilon):
    if geom['type'] == 'Polygon':
        return {'type': 'Polygon', 'coordinates': [simplify_ring([tuple(p) for p in ring], epsilon) for ring in geom['coordinates']]}
    if geom['type'] == 'MultiPolygon':
        return {
            'type': 'MultiPolygon',
            'coordinates': [
                [simplify_ring([tuple(p) for p in ring], epsilon) for ring in poly]
                for poly in geom['coordinates']
            ],
        }
    return geom


def round_coords(geom, ndigits=5):
    def rnd(ring):
        return [[round(x, ndigits), round(y, ndigits)] for x, y in ring]
    if geom['type'] == 'Polygon':
        return {'type': 'Polygon', 'coordinates': [rnd(r) for r in geom['coordinates']]}
    if geom['type'] == 'MultiPolygon':
        return {'type': 'MultiPolygon', 'coordinates': [[rnd(r) for r in poly] for poly in geom['coordinates']]}
    return geom


def simplify_file(in_path, out_path, epsilon, ndigits=5):
    data = json.load(open(in_path))
    out_features = []
    for feat in data['features']:
        geom = simplify_geometry(feat['geometry'], epsilon)
        geom = round_coords(geom, ndigits)
        out_features.append({'type': 'Feature', 'properties': feat['properties'], 'geometry': geom})
    fc = {'type': 'FeatureCollection', 'features': out_features}
    with open(out_path, 'w') as f:
        json.dump(fc, f, separators=(',', ':'))
    import os
    print(f'{out_path}: {len(out_features)} features, {os.path.getsize(out_path)} bytes')


if __name__ == '__main__':
    in_path, out_path, epsilon = sys.argv[1], sys.argv[2], float(sys.argv[3])
    simplify_file(in_path, out_path, epsilon)
