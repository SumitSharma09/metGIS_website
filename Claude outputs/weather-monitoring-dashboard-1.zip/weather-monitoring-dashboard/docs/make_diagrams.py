import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.font_manager import FontProperties

# ---- palette (matches the app's real brand blue, #165ca8) ----
ACCENT = "#165ca8"      # brand blue - the dashboard itself
ACTIVE = "#c9772e"      # warm amber - "this is what's actually feeding the screen today"
ACTIVE_FILL = "#fbeee0"
INACTIVE = "#8a93a3"    # muted grey - "built, but not connected yet"
INACTIVE_FILL = "#eef0f3"
REAL_FILL = "#e7f1fa"
TEXT = "#1e2530"
SUBTEXT = "#5b6472"
CARD_FILL = "#ffffff"
CARD_EDGE = "#d7dbe3"

plt.rcParams["font.family"] = "DejaVu Sans"


def box(ax, x, y, w, h, title, subtitle=None, edge=ACCENT, fill=CARD_FILL, lw=1.8,
        title_size=11.5, sub_size=8.8, dashed=False, title_color=TEXT, sub_color=SUBTEXT):
    style = "round,pad=0.02,rounding_size=0.10"
    ls = (0, (5, 3)) if dashed else "solid"
    patch = FancyBboxPatch((x, y), w, h, boxstyle=style, linewidth=lw,
                            edgecolor=edge, facecolor=fill, linestyle=ls, zorder=3)
    ax.add_patch(patch)
    if subtitle:
        ax.text(x + w / 2, y + h * 0.62, title, ha="center", va="center",
                 fontsize=title_size, color=title_color, fontweight="bold", zorder=4)
        ax.text(x + w / 2, y + h * 0.28, subtitle, ha="center", va="center",
                 fontsize=sub_size, color=sub_color, zorder=4, wrap=True)
    else:
        ax.text(x + w / 2, y + h / 2, title, ha="center", va="center",
                 fontsize=title_size, color=title_color, fontweight="bold", zorder=4)
    return (x, y, w, h)


def arrow(ax, p_from, p_to, color=ACCENT, dashed=False, lw=2.0, label=None, label_dy=0.14):
    ls = (0, (5, 3)) if dashed else "solid"
    fa = FancyArrowPatch(p_from, p_to, arrowstyle="-|>", mutation_scale=16,
                          linewidth=lw, color=color, linestyle=ls, zorder=2,
                          shrinkA=2, shrinkB=2)
    ax.add_patch(fa)
    if label:
        mx, my = (p_from[0] + p_to[0]) / 2, (p_from[1] + p_to[1]) / 2
        ax.text(mx, my + label_dy, label, ha="center", va="bottom",
                 fontsize=8.3, color=color, style="italic", zorder=5)


def new_fig(w, h):
    fig, ax = plt.subplots(figsize=(w, h), dpi=220)
    ax.set_xlim(0, w)
    ax.set_ylim(0, h)
    ax.axis("off")
    return fig, ax


# =====================================================================
# Diagram 1 : the big picture - how data reaches the dashboard today
# =====================================================================
W, H = 10.4, 6.3
fig, ax = new_fig(W, H)

# Source row
demo = box(ax, 0.5, 4.7, 4.1, 1.15,
           "Practice Data Generator",
           "Built into the app - invents realistic\nnumbers so every screen has data",
           edge=ACTIVE, fill=ACTIVE_FILL)

real = box(ax, 5.8, 4.7, 4.1, 1.15,
           "Your Real Weather System",
           "Your organization's actual sensors /\ndatabase - not linked in yet",
           edge=INACTIVE, fill=INACTIVE_FILL, dashed=True, title_color=SUBTEXT)

# Dashboard hub
hub = box(ax, 3.15, 2.75, 4.1, 1.0, "WeatherOps Dashboard",
          edge=ACCENT, fill="#eaf2fb", title_size=13)

arrow(ax, (demo[0] + demo[2] * 0.5, demo[1]), (hub[0] + hub[2] * 0.35, hub[1] + hub[3]),
      color=ACTIVE, label="flowing now")
arrow(ax, (real[0] + real[2] * 0.5, real[1]), (hub[0] + hub[2] * 0.65, hub[1] + hub[3]),
      color=INACTIVE, dashed=True, label="not connected yet")

# Feature fan-out
features = [
    "Live Map", "Forecasts &\nHourly Timeline", "Site Reports",
    "Daily Bulletins\n& PDF Downloads", "Alerts &\nHazard Warnings",
]
n = len(features)
fw, gap = 1.78, 0.14
total_w = n * fw + (n - 1) * gap
start_x = (W - total_w) / 2
fy = 0.65
for i, label in enumerate(features):
    fx = start_x + i * (fw + gap)
    fb = box(ax, fx, fy, fw, 1.15, label, edge=CARD_EDGE, fill=CARD_FILL,
              title_size=9.4, lw=1.4)
    arrow(ax, (hub[0] + hub[2] * (i + 0.5) / n, hub[1]), (fx + fw / 2, fy + 1.15),
          color=ACCENT, lw=1.4)

ax.text(W / 2, 6.05, "How data reaches your dashboard today", ha="center",
         fontsize=15, fontweight="bold", color=TEXT)

fig.tight_layout(pad=0.4)
fig.savefig("assets/diagram_overview.png", bbox_inches="tight")
plt.close(fig)

# =====================================================================
# Diagram 2 : the cyclone exception
# =====================================================================
W2, H2 = 10.4, 3.5
fig, ax = new_fig(W2, H2)

cyc = box(ax, 3.6, 1.75, 3.2, 1.05, "Cyclone Tracker",
          "One fixed, made-up storm -\nthe same for every user, always",
          edge="#b23a2e", fill="#fbe9e6")

hz = box(ax, 0.5, 0.35, 3.0, 0.95, "Hazards Page", edge=CARD_EDGE, fill=CARD_FILL, title_size=10)
rp = box(ax, 6.9, 0.35, 3.0, 0.95, "Bulletins & Reports", edge=CARD_EDGE, fill=CARD_FILL, title_size=10)

arrow(ax, (cyc[0] + cyc[2] * 0.25, cyc[1]), (hz[0] + hz[2] * 0.7, hz[1] + hz[3]),
      color="#b23a2e", dashed=True, label="not linked to\nany data source")
arrow(ax, (cyc[0] + cyc[2] * 0.75, cyc[1]), (rp[0] + rp[2] * 0.3, rp[1] + rp[3]),
      color="#b23a2e", dashed=True)

ax.text(W2 / 2, 3.25, "The one exception: cyclone tracking", ha="center",
         fontsize=15, fontweight="bold", color=TEXT)

fig.tight_layout(pad=0.4)
fig.savefig("assets/diagram_cyclone.png", bbox_inches="tight")
plt.close(fig)

print("done")
