from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle,
    HRFlowable, PageBreak, KeepTogether
)
from reportlab.pdfgen import canvas as pdfcanvas

ACCENT = colors.HexColor("#165ca8")
ACTIVE = colors.HexColor("#c9772e")
INACTIVE = colors.HexColor("#5b6472")
TEXT = colors.HexColor("#1e2530")
SUBTEXT = colors.HexColor("#454e5c")
LIGHT_BG = colors.HexColor("#f4f6f9")
ACTIVE_BG = colors.HexColor("#fbeee0")
INACTIVE_BG = colors.HexColor("#eef0f3")
FLAG_BG = colors.HexColor("#fbe9e6")
RULE = colors.HexColor("#d7dbe3")

PAGE_W, PAGE_H = letter

styles = getSampleStyleSheet()

title_style = ParagraphStyle("TitleBig", parent=styles["Title"], fontName="Helvetica-Bold",
                              fontSize=26, textColor=TEXT, leading=30, spaceAfter=6)
eyebrow_style = ParagraphStyle("Eyebrow", parent=styles["Normal"], fontName="Helvetica-Bold",
                                fontSize=10.5, textColor=ACCENT, leading=13,
                                spaceAfter=10, tracking=1)
lede_style = ParagraphStyle("Lede", parent=styles["Normal"], fontName="Helvetica",
                             fontSize=12.5, textColor=SUBTEXT, leading=18, spaceAfter=14)
h2_style = ParagraphStyle("H2", parent=styles["Heading2"], fontName="Helvetica-Bold",
                           fontSize=15.5, textColor=TEXT, spaceBefore=18, spaceAfter=8)
body_style = ParagraphStyle("Body", parent=styles["Normal"], fontName="Helvetica",
                             fontSize=10.3, textColor=TEXT, leading=15, spaceAfter=8)
small_style = ParagraphStyle("Small", parent=styles["Normal"], fontName="Helvetica",
                              fontSize=8.8, textColor=SUBTEXT, leading=12.5)
cell_style = ParagraphStyle("Cell", parent=styles["Normal"], fontName="Helvetica",
                             fontSize=9, textColor=TEXT, leading=12.5)
cell_head = ParagraphStyle("CellHead", parent=styles["Normal"], fontName="Helvetica-Bold",
                            fontSize=9.3, textColor=colors.white, leading=12.5)
tag_active = ParagraphStyle("TagActive", parent=styles["Normal"], fontName="Helvetica-Bold",
                             fontSize=8.3, textColor=ACTIVE, leading=11)
tag_inactive = ParagraphStyle("TagInactive", parent=styles["Normal"], fontName="Helvetica-Bold",
                               fontSize=8.3, textColor=colors.HexColor("#b23a2e"), leading=11)
tag_real = ParagraphStyle("TagReal", parent=styles["Normal"], fontName="Helvetica-Bold",
                           fontSize=8.3, textColor=colors.HexColor("#2f7d4f"), leading=11)
callout_head = ParagraphStyle("CalloutHead", parent=styles["Normal"], fontName="Helvetica-Bold",
                               fontSize=10.5, textColor=TEXT, leading=13, spaceAfter=3)
callout_body = ParagraphStyle("CalloutBody", parent=styles["Normal"], fontName="Helvetica",
                               fontSize=9.4, textColor=SUBTEXT, leading=13)


def rule(color=RULE, thickness=0.8, space_before=4, space_after=10):
    return [Spacer(1, space_before), HRFlowable(width="100%", thickness=thickness, color=color),
            Spacer(1, space_after)]


def domain_row(name, hooks, mock, real, flagged=False):
    return [
        Paragraph(f"<b>{name}</b>", cell_style),
        Paragraph(mock, cell_style),
        Paragraph(real, cell_style),
    ]


def header_footer(canvas: pdfcanvas.Canvas, doc):
    canvas.saveState()
    # header rule + brand strip
    canvas.setFillColor(ACCENT)
    canvas.rect(0, PAGE_H - 0.14 * inch, PAGE_W, 0.14 * inch, stroke=0, fill=1)
    canvas.setFont("Helvetica-Bold", 8)
    canvas.setFillColor(SUBTEXT)
    canvas.drawString(0.75 * inch, PAGE_H - 0.34 * inch, "BKC WEATHERSYS")
    canvas.setFont("Helvetica", 8)
    canvas.drawRightString(PAGE_W - 0.75 * inch, PAGE_H - 0.34 * inch, "WeatherOps Dashboard - Data Guide")
    # footer
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(SUBTEXT)
    canvas.drawString(0.75 * inch, 0.55 * inch, "Confidential - for internal operational use only")
    canvas.drawRightString(PAGE_W - 0.75 * inch, 0.55 * inch, f"Page {doc.page}")
    canvas.restoreState()


def build():
    doc = SimpleDocTemplate(
        "WeatherOps_Data_Guide.pdf",
        pagesize=letter,
        topMargin=0.85 * inch, bottomMargin=0.85 * inch,
        leftMargin=0.75 * inch, rightMargin=0.75 * inch,
        title="WeatherOps Dashboard - Data Guide",
        author="BKC WeatherSys",
    )

    story = []

    # ---------- Title block ----------
    story.append(Paragraph("BKC WEATHERSYS &nbsp;&middot;&nbsp; DATA GUIDE", eyebrow_style))
    story.append(Paragraph("Where Your Dashboard's Data Comes From", title_style))
    story.append(Paragraph(
        "A plain-language walkthrough of the WeatherOps dashboard: which screens are live today, "
        "where their numbers actually come from, and what would need to change to switch over to "
        "your organization's real weather system.",
        lede_style))
    story += rule()

    # ---------- The one-line answer ----------
    story.append(Paragraph("The short version", h2_style))
    story.append(Paragraph(
        "Every screen on the dashboard works and looks complete today, but the weather numbers behind "
        "almost all of them are <b>practice data</b> &mdash; realistic numbers invented by the app itself, "
        "not readings from a real sensor or a real database. The only genuinely real things in the app "
        "right now are the <b>list of tower sites/circles</b> and the <b>login system</b>. Everything else "
        "is a stand-in, built so the dashboard could be designed and tested before it's wired up to your "
        "actual weather system.",
        body_style))

    # ---------- Diagram 1 ----------
    story.append(Spacer(1, 6))
    story.append(Image("assets/diagram_overview.png", width=6.85 * inch,
                        height=6.85 * inch * (789 / 2307) if False else None))
    story[-1].drawWidth = 6.85 * inch
    story[-1].drawHeight = 6.85 * inch * (789.0 / 2307.0)
    story.append(Paragraph(
        "The dashboard has one central data hub. Today, only the amber path (the built-in practice "
        "data generator) is actually turned on; the grey dashed path (your real weather system) is "
        "ready to be connected but nothing is plugged into it yet.",
        small_style))

    story.append(PageBreak())

    # ---------- Domain-by-domain table ----------
    story.append(Paragraph("Screen by screen: what's behind each one", h2_style))
    story.append(Paragraph(
        "This table lists every major area of the dashboard, what it shows you, and exactly where "
        "that information comes from right now versus where it would come from once connected to a "
        "real system.",
        body_style))

    header = [Paragraph("Dashboard area", cell_head), Paragraph("Where the data comes from today", cell_head),
              Paragraph("Where it would come from, once connected", cell_head)]

    rows_data = [
        ("Live Map &amp; current conditions",
         "Invented on the spot by the app's practice data generator",
         "Your live sensor/API feed, refreshed continuously"),
        ("Forecasts (7-day &amp; hourly slider)",
         "Same practice generator, projected forward in time",
         "Your forecasting system or meteorological data provider"),
        ("Historical weather &amp; comparisons",
         "Practice generator, built to look like a believable history",
         "Your archived/historical weather records"),
        ("Alerts &amp; hazard warnings",
         "Calculated from the practice weather numbers above",
         "Calculated the same way, but from your real weather feed"),
        ("Daily bulletins &amp; PDF reports",
         "Assembled from whichever practice numbers each report covers",
         "Same reports, built from real figures once connected"),
        ("Cyclone tracker",
         "One fixed, hand-set demo storm - see note below",
         "Would need a dedicated cyclone data feed to be built - none exists today, mock or real"),
        ("Tower sites &amp; circle names",
         "<b>Real.</b> The actual list of your sites, states and circles",
         "No change needed - already real"),
        ("User login",
         "<b>Real &amp; working</b>, using a temporary practice database",
         "Same login system, pointed at your permanent database"),
    ]

    table_rows = [header]
    for name, today, future in rows_data:
        table_rows.append([Paragraph(name, cell_style), Paragraph(today, cell_style), Paragraph(future, cell_style)])

    col_widths = [1.55 * inch, 2.55 * inch, 2.55 * inch]
    tbl = Table(table_rows, colWidths=col_widths, repeatRows=1)
    style_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), ACCENT),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 7),
        ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LINEBELOW", (0, 0), (-1, 0), 0.8, ACCENT),
        ("GRID", (0, 1), (-1, -1), 0.5, RULE),
    ]
    for i in range(1, len(table_rows)):
        if i % 2 == 0:
            style_cmds.append(("BACKGROUND", (0, i), (-1, i), LIGHT_BG))
        if "Cyclone" in rows_data[i - 1][0]:
            style_cmds.append(("BACKGROUND", (0, i), (-1, i), FLAG_BG))
    tbl.setStyle(TableStyle(style_cmds))
    story.append(Spacer(1, 6))
    story.append(tbl)

    story.append(PageBreak())

    # ---------- Cyclone callout section ----------
    story.append(Paragraph("A closer look: the cyclone tracker", h2_style))
    story.append(Paragraph(
        "The cyclone tracker works differently from everything else in the app, and it's worth calling "
        "out on its own. It is not connected to the practice data generator, and it is not connected to "
        "anything else either. It shows one single storm track that was manually set once, and every "
        "user of the dashboard sees that exact same storm, all the time - it never updates and does not "
        "represent a real, current cyclone.",
        body_style))
    story.append(Spacer(1, 4))
    story.append(Image("assets/diagram_cyclone.png", width=6.85 * inch,
                        height=6.85 * inch * (1218.0 / 2000.0)))
    story.append(Paragraph(
        "If real cyclone tracking is needed, it would have to be built from scratch as a new connection - "
        "unlike the rest of the app, there isn't even a practice-data version of it feeding a real "
        "structure that a live feed could later slot into.",
        small_style))

    story.append(Spacer(1, 10))

    # ---------- What it would take ----------
    story.append(Paragraph("What it would take to switch to real data", h2_style))
    story.append(Paragraph(
        "Turning on the grey \"real weather system\" path in the diagram above is mainly a matter of "
        "information, not a rebuild - the dashboard was designed to accept a real data source in place "
        "of the practice generator, feature by feature. To move forward, we'd need from your team:",
        body_style))

    items = [
        ("The web address (URL) of your weather system",
         "So the dashboard knows where to ask for data."),
        ("A sample of what your system sends back",
         "So the dashboard's screens can be matched up to your system's real fields and units."),
        ("How to sign in to it",
         "The dashboard already expects a standard secure login step (a token from a login page) - "
         "we'd confirm your system works the same way."),
    ]
    tbl2_rows = []
    for i, (head, sub) in enumerate(items, start=1):
        tbl2_rows.append([
            Paragraph(f"<b>{i}</b>", ParagraphStyle("num", parent=cell_style, fontSize=13, textColor=ACCENT,
                                                      alignment=TA_CENTER)),
            Paragraph(f"<b>{head}</b><br/><font color='#454e5c' size=8.6>{sub}</font>", cell_style),
        ])
    tbl2 = Table(tbl2_rows, colWidths=[0.4 * inch, 6.25 * inch])
    tbl2.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LINEBELOW", (0, 0), (-1, -2), 0.5, RULE),
    ]))
    story.append(Spacer(1, 4))
    story.append(tbl2)

    story.append(Spacer(1, 12))
    story.append(Paragraph(
        "Once that information is available, each screen can be switched over one at a time - the "
        "dashboard doesn't need to go all-or-nothing, and everything keeps working on practice data in "
        "the meantime for anything not yet connected.",
        body_style))

    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)


if __name__ == "__main__":
    build()
