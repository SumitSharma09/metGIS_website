"""
Minimal, dependency-free ESRI Shapefile (.shp + .dbf) -> GeoJSON converter.

Written by hand because this sandbox's pip mirror doesn't carry pyshp/
fiona/gdal (confirmed - `pip install pyshp` 404s here), the same situation
that led to a hand-written Douglas-Peucker simplifier in an earlier session
for this same project. Handles Polygon (type 5) shapes only, which is all
these two files (India-States.shp / India-Districts-2011Census.shp) use.

Both files are already plain WGS84 lon/lat degrees (confirmed via their
.prj sidecars - `GEOGCS["GCS_WGS_1984", ...]`), so no reprojection is
needed - coordinates are used as-is.

Ring classification (outer boundary vs. hole) is done via the shoelace-
formula sign, then grouped into MultiPolygons by walking the shapefile's
parts in order and starting a new polygon at every "outer" ring - the de
facto convention these files (and the vast majority of real-world
shapefiles) follow, even though the format itself doesn't strictly
guarantee part ordering.
"""
import struct
import json
import sys


def read_shp(path):
    with open(path, 'rb') as f:
        data = f.read()

    # Main file header is 100 bytes; shape type is at offset 32 (should be 5 = Polygon).
    shape_type = struct.unpack('<i', data[32:36])[0]
    if shape_type != 5:
        raise ValueError(f'Unsupported shape type {shape_type} in {path} (expected 5=Polygon)')

    records = []
    pos = 100
    n = len(data)
    while pos < n:
        rec_number, content_len_words = struct.unpack('>ii', data[pos:pos + 8])
        pos += 8
        content_start = pos
        rtype = struct.unpack('<i', data[pos:pos + 4])[0]
        if rtype == 0:
            # Null shape
            records.append([])
            pos = content_start + content_len_words * 2
            continue
        # Polygon record layout: shapeType(4) box(32) numParts(4) numPoints(4)
        # parts[numParts](4 each) points[numPoints](16 each: x,y doubles)
        num_parts, num_points = struct.unpack('<ii', data[pos + 36:pos + 44])
        parts_start = pos + 44
        parts = list(struct.unpack(f'<{num_parts}i', data[parts_start:parts_start + 4 * num_parts]))
        points_start = parts_start + 4 * num_parts
        coords = struct.unpack(f'<{num_points * 2}d', data[points_start:points_start + 16 * num_points])
        points = [(coords[2 * i], coords[2 * i + 1]) for i in range(num_points)]

        rings = []
        for i, start_idx in enumerate(parts):
            end_idx = parts[i + 1] if i + 1 < len(parts) else num_points
            rings.append(points[start_idx:end_idx])
        records.append(rings)

        pos = content_start + content_len_words * 2

    return records


def read_dbf(path):
    with open(path, 'rb') as f:
        data = f.read()

    num_records = struct.unpack('<I', data[4:8])[0]
    header_len = struct.unpack('<H', data[8:10])[0]
    record_len = struct.unpack('<H', data[10:12])[0]

    fields = []
    pos = 32
    while data[pos] != 0x0D:
        name = data[pos:pos + 11].split(b'\x00')[0].decode('ascii', errors='replace')
        ftype = chr(data[pos + 11])
        flen = data[pos + 16]
        fields.append((name, ftype, flen))
        pos += 32

    records = []
    rec_start = header_len
    for i in range(num_records):
        offset = rec_start + i * record_len
        raw = data[offset:offset + record_len]
        deleted = raw[0:1] == b'*'
        row = {}
        col = 1
        for name, ftype, flen in fields:
            raw_val = raw[col:col + flen]
            col += flen
            val = raw_val.decode('ascii', errors='replace').strip()
            if ftype == 'N':
                try:
                    row[name] = int(val) if val and '.' not in val else (float(val) if val else None)
                except ValueError:
                    row[name] = val
            else:
                row[name] = val
        records.append((row, deleted))

    return records


def shoelace_signed_area(ring):
    area = 0.0
    n = len(ring)
    for i in range(n):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % n]
        area += (x1 * y2 - x2 * y1)
    return area / 2.0


def rings_to_multipolygon(rings):
    """Groups a shapefile record's flat ring list into GeoJSON MultiPolygon
    coordinates, classifying each ring as an outer boundary (starts a new
    polygon) or a hole (attaches to the most recent outer ring) by the sign
    of its shoelace area. The first ring seen establishes which sign means
    "outer" for this record (handles either overall winding convention)."""
    if not rings:
        return []
    signs = [shoelace_signed_area(r) >= 0 for r in rings]
    outer_sign = signs[0]

    polygons = []
    current = None
    for ring, is_outer_sign in zip(rings, signs):
        closed = ring if ring[0] == ring[-1] else ring + [ring[0]]
        if is_outer_sign == outer_sign or current is None:
            current = [closed]
            polygons.append(current)
        else:
            current.append(closed)
    return polygons


def convert(shp_path, dbf_path, out_path, prop_map, filter_fn=None):
    shapes = read_shp(shp_path)
    attrs = read_dbf(dbf_path)
    assert len(shapes) == len(attrs), f'{len(shapes)} shapes vs {len(attrs)} dbf records'

    features = []
    for rings, (row, deleted) in zip(shapes, attrs):
        if deleted or not rings:
            continue
        props = {out_key: row.get(src_key) for out_key, src_key in prop_map.items()}
        if filter_fn and not filter_fn(props):
            continue
        multipoly = rings_to_multipolygon(rings)
        if not multipoly:
            continue
        features.append({
            'type': 'Feature',
            'properties': props,
            'geometry': {'type': 'MultiPolygon', 'coordinates': multipoly},
        })

    fc = {'type': 'FeatureCollection', 'features': features}
    with open(out_path, 'w') as f:
        json.dump(fc, f, separators=(',', ':'))
    print(f'{out_path}: {len(features)} features, {len(json.dumps(fc))} bytes (uncompressed)')


if __name__ == '__main__':
    # Quick inspection mode: python3 shp_to_geojson.py inspect <dbf>
    if len(sys.argv) > 1 and sys.argv[1] == 'inspect':
        recs = read_dbf(sys.argv[2])
        for row, deleted in recs[:10]:
            print(row, 'DELETED' if deleted else '')
        print(f'... {len(recs)} total records. Fields: {list(recs[0][0].keys()) if recs else []}')
