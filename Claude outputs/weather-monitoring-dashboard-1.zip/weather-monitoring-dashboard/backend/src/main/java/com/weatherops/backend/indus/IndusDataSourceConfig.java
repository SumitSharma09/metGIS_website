package com.weatherops.backend.indus;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * Second, entirely separate datasource/persistence-unit for the user's own
 * MySQL database holding {@code INDUS_Stations}/{@code INDUS_WeatherData}
 * (real station + hourly-forecast data, see {@link IndusStation} and
 * {@link IndusWeatherData}) - independent of the app's own primary datasource
 * (H2 by default, holding users/alerts/reports/sites/etc., unaffected by any
 * of this - see {@code com.weatherops.backend.config.PrimaryDataSourceConfig}
 * and {@code BackendApplication}'s {@code @EntityScan}/{@code @EnableJpaRepositories}
 * restrictions, which keep the primary persistence unit scoped to
 * {@code domain}/{@code repository} and never let it pick up the two
 * entities below).
 * <p>
 * This whole class only activates when {@code app.indus.enabled=true}
 * (see application.yml) - with it left at the default {@code false}, no
 * MySQL connection is attempted at all and the app boots exactly as before,
 * with zero risk to the existing H2-backed functionality.
 * <p>
 * Two deliberate safety choices, since this database is the user's own
 * pre-existing production data, not something this app owns or should ever
 * migrate/alter:
 * <ul>
 *   <li>{@code hibernate.hbm2ddl.auto=none} - Hibernate never creates,
 *   validates, or alters {@code INDUS_Stations}/{@code INDUS_WeatherData}.
 *   This app only ever issues {@code SELECT}s against them.</li>
 *   <li>{@code PhysicalNamingStrategyStandardImpl} - uses the exact
 *   {@code @Table}/{@code @Column} names given in {@link IndusStation}/
 *   {@link IndusWeatherData} verbatim. Spring Boot's default naming strategy
 *   rewrites identifiers to snake_case, which would mangle mixed-case names
 *   like {@code INDUS_Stations}/{@code RegionType} instead of matching the
 *   real table.</li>
 * </ul>
 */
@Configuration
@ConditionalOnProperty(prefix = "app.indus", name = "enabled", havingValue = "true")
@EnableJpaRepositories(
        basePackages = "com.weatherops.backend.indus",
        entityManagerFactoryRef = "indusEntityManagerFactory",
        transactionManagerRef = "indusTransactionManager")
public class IndusDataSourceConfig {

    @Bean
    @ConfigurationProperties("app.indus.datasource")
    public DataSource indusDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean indusEntityManagerFactory(
            EntityManagerFactoryBuilder builder, DataSource indusDataSource) {
        Map<String, Object> properties = new HashMap<>();
        properties.put("hibernate.hbm2ddl.auto", "none");
        properties.put(
                "hibernate.physical_naming_strategy",
                "org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl");
        return builder
                .dataSource(indusDataSource)
                .packages(IndusStation.class, IndusWeatherData.class)
                .persistenceUnit("indus")
                .properties(properties)
                .build();
    }

    @Bean
    public PlatformTransactionManager indusTransactionManager(
            LocalContainerEntityManagerFactoryBean indusEntityManagerFactory) {
        return new JpaTransactionManager(indusEntityManagerFactory.getObject());
    }
}
