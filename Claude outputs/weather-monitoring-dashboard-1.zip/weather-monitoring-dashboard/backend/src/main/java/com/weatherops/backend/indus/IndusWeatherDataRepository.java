package com.weatherops.backend.indus;

import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/** Read-only repository over the user's existing {@code INDUS_WeatherData} table - see {@link IndusWeatherData}. */
public interface IndusWeatherDataRepository extends JpaRepository<IndusWeatherData, Long> {

    /** Nearest row at-or-before a given instant - used for "current" observations. */
    Optional<IndusWeatherData> findTopByStationIdAndForecastTimeLessThanEqualOrderByForecastTimeDesc(
            Long stationId, LocalDateTime at);

    /** Fallback for a station whose earliest stored row is still in the future
     *  relative to the requested instant (e.g. "now" requested before the
     *  first forecast row has been ingested for a brand-new station). */
    Optional<IndusWeatherData> findTopByStationIdOrderByForecastTimeAsc(Long stationId);

    List<IndusWeatherData> findByStationIdAndForecastTimeBetweenOrderByForecastTimeAsc(
            Long stationId, LocalDateTime from, LocalDateTime to);

    List<IndusWeatherData> findByStationIdOrderByForecastTimeAsc(Long stationId);
}
