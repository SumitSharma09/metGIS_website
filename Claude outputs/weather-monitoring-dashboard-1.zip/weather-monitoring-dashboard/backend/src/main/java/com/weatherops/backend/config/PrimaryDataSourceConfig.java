package com.weatherops.backend.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;

/**
 * Explicitly (re-)declares the app's own primary datasource (H2 by default;
 * see application.yml's {@code spring.datasource.*} block, still the only
 * thing to edit to swap it for MySQL/Postgres) and marks it {@code @Primary}.
 * <p>
 * Functionally this is exactly what Spring Boot's own auto-configuration
 * would already have built - the same bean name ("dataSource"), the same
 * {@code spring.datasource.*} properties. The only reason it's spelled out
 * here is {@code @Primary}: once the optional Indus MySQL datasource
 * (see {@code com.weatherops.backend.indus.IndusDataSourceConfig}) is turned
 * on via {@code app.indus.enabled=true}, there are two {@link DataSource}
 * beans in the context, and anything that autowires a plain
 * {@code DataSource} with no qualifier (the H2 console, actuator health
 * indicators, etc.) needs an unambiguous default to resolve to - this one.
 * With Indus mode left off (the default), this bean is the only
 * {@link DataSource} in the app either way, so {@code @Primary} is a no-op.
 */
@Configuration
public class PrimaryDataSourceConfig {

    @Bean
    @Primary
    @ConfigurationProperties("spring.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }
}
