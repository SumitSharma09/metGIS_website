package com.weatherops.backend.indus;

import com.weatherops.backend.domain.Site;
import com.weatherops.backend.dto.weather.CurrentObservationDto;
import com.weatherops.backend.dto.weather.ForecastDayDto;
import com.weatherops.backend.dto.weather.HistoricalPointDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Real weather data path (hourly forecast rows from the user's own
 * {@code INDUS_WeatherData} table, via {@link IndusWeatherDataRepository})
 * - the drop-in replacement for {@link com.weatherops.backend.weather.WeatherGenerator}'s
 * synthetic data, activated only when {@code app.indus.enabled=true} (see
 * {@link IndusDataSourceConfig}). {@link com.weatherops.backend.service.WeatherService}
 * branches to this instead of the generator once enabled.
 */
@Service
@ConditionalOnProperty(prefix = "app.indus", name = "enabled", havingValue = "true")
public class IndusWeatherService {

    private final IndusWeatherDataRepository weatherDataRepository;
    private final IndusWeatherMapper mapper;
    private final ZoneId sourceZone;

    public IndusWeatherService(
            IndusWeatherDataRepository weatherDataRepository,
            IndusWeatherMapper mapper,
            @Value("${app.indus.source-timezone:UTC}") String sourceTimezone) {
        this.weatherDataRepository = weatherDataRepository;
        this.mapper = mapper;
        this.sourceZone = ZoneId.of(sourceTimezone);
    }

    public CurrentObservationDto currentAt(Site site, Instant at) {
        long stationId = Long.parseLong(site.getId());
        LocalDateTime atLocal = LocalDateTime.ofInstant(at, sourceZone);

        IndusWeatherData row = weatherDataRepository
                .findTopByStationIdAndForecastTimeLessThanEqualOrderByForecastTimeDesc(stationId, atLocal)
                .or(() -> weatherDataRepository.findTopByStationIdOrderByForecastTimeAsc(stationId))
                .orElse(null);

        if (row == null) {
            return emptyCurrentObservation(site.getId(), at);
        }

        double rainfallToday = sumPrecipitationForDay(stationId, atLocal.toLocalDate(), atLocal);
        return mapper.toCurrentObservation(site.getId(), at, row, site.getElevationMeters(), rainfallToday);
    }

    public List<HistoricalPointDto> historical(Site site, Instant from, Instant to, String interval) {
        long stationId = Long.parseLong(site.getId());
        LocalDateTime fromLocal = LocalDateTime.ofInstant(from, sourceZone);
        LocalDateTime toLocal = LocalDateTime.ofInstant(to, sourceZone);

        List<IndusWeatherData> rows = weatherDataRepository
                .findByStationIdAndForecastTimeBetweenOrderByForecastTimeAsc(stationId, fromLocal, toLocal);

        if (!"daily".equalsIgnoreCase(interval)) {
            return rows.stream().map(r -> mapper.toHistoricalPoint(r, sourceZone)).toList();
        }

        // Daily interval: bucket the hourly rows by calendar date and average/
        // sum them into one HistoricalPointDto per day (matches the shape the
        // synthetic generator already produces for interval=daily).
        Map<LocalDate, List<IndusWeatherData>> byDate = new TreeMap<>();
        for (IndusWeatherData row : rows) {
            byDate.computeIfAbsent(row.getForecastTime().toLocalDate(), d -> new ArrayList<>()).add(row);
        }
        List<HistoricalPointDto> daily = new ArrayList<>();
        for (Map.Entry<LocalDate, List<IndusWeatherData>> entry : byDate.entrySet()) {
            daily.add(averageDay(entry.getKey(), entry.getValue()));
        }
        return daily;
    }

    public List<ForecastDayDto> forecast(Site site, int days) {
        long stationId = Long.parseLong(site.getId());
        LocalDate today = LocalDate.now(sourceZone);

        List<IndusWeatherData> rows = weatherDataRepository.findByStationIdOrderByForecastTimeAsc(stationId);
        Map<LocalDate, List<IndusWeatherData>> byDate = new TreeMap<>();
        for (IndusWeatherData row : rows) {
            LocalDate date = row.getForecastTime().toLocalDate();
            if (!date.isBefore(today) && date.isBefore(today.plusDays(days))) {
                byDate.computeIfAbsent(date, d -> new ArrayList<>()).add(row);
            }
        }

        List<ForecastDayDto> result = new ArrayList<>();
        for (int i = 0; i < days; i++) {
            LocalDate date = today.plusDays(i);
            List<IndusWeatherData> dayRows = byDate.get(date);
            if (dayRows == null || dayRows.isEmpty()) {
                // No ingested rows for this date yet - skip it rather than
                // fabricate a day with no underlying data. The caller may get
                // fewer than `days` entries back; that's expected once the
                // ingestion pipeline hasn't reached that far ahead yet.
                continue;
            }
            ForecastDayDto dto = mapper.toForecastDay(date, dayRows);
            if (dto != null) result.add(dto);
        }
        return result;
    }

    private double sumPrecipitationForDay(long stationId, LocalDate date, LocalDateTime upTo) {
        LocalDateTime dayStart = date.atStartOfDay();
        List<IndusWeatherData> todaysRows = weatherDataRepository
                .findByStationIdAndForecastTimeBetweenOrderByForecastTimeAsc(stationId, dayStart, upTo);
        double total = 0;
        for (IndusWeatherData row : todaysRows) {
            total += row.getPrecipitation() == null ? 0 : row.getPrecipitation();
        }
        return Math.round(total * 10.0) / 10.0;
    }

    private HistoricalPointDto averageDay(LocalDate date, List<IndusWeatherData> dayRows) {
        double tempSum = 0;
        double windSum = 0;
        double rainfallSum = 0;
        double snowfallSum = 0;
        int lightningSum = 0;
        int humiditySum = 0;
        int n = dayRows.size();
        for (IndusWeatherData row : dayRows) {
            HistoricalPointDto point = mapper.toHistoricalPoint(row, sourceZone);
            tempSum += point.temperature;
            windSum += point.windSpeed;
            rainfallSum += point.rainfall;
            snowfallSum += point.snowfallCm == null ? 0 : point.snowfallCm;
            lightningSum += point.lightningStrikes;
            humiditySum += point.humidity;
        }
        HistoricalPointDto daily = new HistoricalPointDto();
        daily.timestamp = date.atStartOfDay(sourceZone).toInstant();
        daily.temperature = Math.round((tempSum / n) * 10.0) / 10.0;
        daily.humidity = Math.round((float) humiditySum / n);
        daily.rainfall = Math.round(rainfallSum * 10.0) / 10.0;
        daily.windSpeed = Math.round((windSum / n) * 10.0) / 10.0;
        daily.pressure = 1013;
        daily.lightningStrikes = lightningSum;
        daily.snowfallCm = Math.round(snowfallSum * 10.0) / 10.0;
        return daily;
    }

    private CurrentObservationDto emptyCurrentObservation(String siteId, Instant at) {
        // No row at all for this station yet (brand-new station the
        // ingestion pipeline hasn't produced a forecast for). Returning
        // zeroed-out data keeps the Live Map from erroring on this site
        // rather than showing genuinely-collected zeros as if they were real.
        CurrentObservationDto dto = new CurrentObservationDto();
        dto.siteId = siteId;
        dto.timestamp = at;
        dto.condition = "clear";
        dto.humidity = 0;
        dto.pressure = 1013;
        return dto;
    }
}
