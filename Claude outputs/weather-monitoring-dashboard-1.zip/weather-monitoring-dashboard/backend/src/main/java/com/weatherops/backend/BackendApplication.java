package com.weatherops.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * {@code @EntityScan}/{@code @EnableJpaRepositories} are pinned explicitly to
 * this app's own {@code domain}/{@code repository} packages (H2 by default -
 * users/alerts/reports/sites/etc.) rather than left to Spring Boot's default
 * whole-package auto-detection, so that the separate {@code indus} package
 * (see {@code com.weatherops.backend.indus.IndusDataSourceConfig}) - the
 * user's own pre-existing MySQL tables, {@code INDUS_Stations}/
 * {@code INDUS_WeatherData} - is never picked up by *this*, the app's own
 * primary persistence unit. Those two entities belong only to the separate
 * "indus" persistence unit, which points at a different (MySQL) datasource
 * and is configured with {@code hibernate.hbm2ddl.auto=none} specifically so
 * this app never creates, alters, or touches the user's real tables.
 * <p>
 * This restriction is unconditional (not gated on {@code app.indus.enabled}):
 * once any explicit {@code @EnableJpaRepositories} exists anywhere in the
 * app (the conditional one in {@code IndusDataSourceConfig}, only present
 * when Indus mode is on), Spring Boot's own automatic repository scanning
 * backs off application-wide - so this app's original repositories need
 * their own explicit declaration here regardless of whether Indus mode is
 * currently enabled, or they'd silently stop being created the moment
 * Indus mode is turned on.
 */
@EntityScan(basePackages = "com.weatherops.backend.domain")
@EnableJpaRepositories(basePackages = "com.weatherops.backend.repository")
@SpringBootApplication
public class BackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(BackendApplication.class, args);
    }
}
