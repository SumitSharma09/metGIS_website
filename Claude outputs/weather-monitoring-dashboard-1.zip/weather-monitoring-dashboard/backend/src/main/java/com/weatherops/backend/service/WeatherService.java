package com.weatherops.backend.service;

import com.weatherops.backend.domain.Site;
import com.weatherops.backend.dto.weather.CurrentObservationDto;
import com.weatherops.backend.dto.weather.ForecastDayDto;
import com.weatherops.backend.dto.weather.HistoricalPointDto;
import com.weatherops.backend.indus.IndusWeatherService;
import com.weatherops.backend.weather.WeatherGenerator;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class WeatherService {

    private final SiteService siteService;
    private final WeatherGenerator generator;
    private final ObjectProvider<IndusWeatherService> indusWeatherService;
    private final boolean indusEnabled;

    public WeatherService(
            SiteService siteService,
            WeatherGenerator generator,
            ObjectProvider<IndusWeatherService> indusWeatherService,
            @Value("${app.indus.enabled:false}") boolean indusEnabled) {
        this.siteService = siteService;
        this.generator = generator;
        this.indusWeatherService = indusWeatherService;
        this.indusEnabled = indusEnabled;
    }

    public List<CurrentObservationDto> currentFor(List<String> siteIds, Instant at) {
        Instant timestamp = at != null ? at : Instant.now();
        // RBAC: whether the caller asked for "all sites" or named specific
        // IDs, a non-admin only ever gets observations for sites in scope -
        // listAllInScope() applies that regardless of which data source
        // (demo or Indus) is active.
        List<Site> sites = siteService.listAllInScope(siteIds);
        if (indusEnabled) {
            IndusWeatherService indus = indusWeatherService.getIfAvailable();
            if (indus != null) {
                return sites.stream().map(s -> indus.currentAt(s, timestamp)).toList();
            }
        }
        return sites.stream().map(s -> generator.currentAt(s, timestamp)).toList();
    }

    public CurrentObservationDto currentForSite(String siteId) {
        Site site = siteService.findOrThrow(siteId);
        if (indusEnabled) {
            IndusWeatherService indus = indusWeatherService.getIfAvailable();
            if (indus != null) return indus.currentAt(site, Instant.now());
        }
        return generator.currentAt(site, Instant.now());
    }

    public List<HistoricalPointDto> historical(String siteId, Instant from, Instant to, String interval) {
        Site site = siteService.findOrThrow(siteId);
        if (indusEnabled) {
            IndusWeatherService indus = indusWeatherService.getIfAvailable();
            if (indus != null) return indus.historical(site, from, to, interval);
        }
        return generator.historical(site, from, to, interval);
    }

    public List<ForecastDayDto> forecast(String siteId, Integer days) {
        Site site = siteService.findOrThrow(siteId);
        int resolvedDays = days == null ? 7 : days;
        if (indusEnabled) {
            IndusWeatherService indus = indusWeatherService.getIfAvailable();
            if (indus != null) return indus.forecast(site, resolvedDays);
        }
        return generator.forecast(site, resolvedDays);
    }
}
