package com.weatherops.backend.indus;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * Read-only mapping onto the user's own, pre-existing {@code INDUS_WeatherData}
 * MySQL table (real hourly forecast rows per station, as shown to Claude
 * directly from a `mysql>` session):
 *
 * <pre>
 * id | station_id | district_name | circle | area | zone | region_type | latitude | longitude
 * | forecast_time | temperature_2m | snowfall | visibility | wind_speed_10m
 * | wind_direction_10m | precipitation | precipitation_probability | wind_gusts_10m | created_at
 * </pre>
 *
 * Column names (temperature_2m, wind_speed_10m, wind_gusts_10m, ...) match
 * Open-Meteo's naming convention, so this assumes Open-Meteo's default units:
 * temperature in °C, wind speed/gusts in km/h, precipitation/snowfall in
 * mm/cm, visibility in meters, precipitation_probability in %. If the user's
 * ingestion pipeline uses different units, adjust {@link IndusWeatherMapper}
 * accordingly - the raw values are passed straight through untouched here.
 *
 * {@code station_id} is a foreign key to {@code INDUS_Stations.ID} (the
 * numeric auto-increment primary key), NOT {@code INDUS_SITE_ID} - confirmed
 * from the sample rows (station_id 1/2/3 lining up with INDUS_Stations.ID,
 * not with a real-looking site code). {@link IndusSiteMapper} sets the
 * app-facing {@code Site.id} to this same numeric id (as a string) so a
 * weather lookup for a given site is a direct, cheap join back to this
 * column - {@code Site.code} carries the human-readable INDUS_SITE_ID
 * instead.
 *
 * {@code forecast_time}/{@code created_at} are assumed to already be stored
 * in UTC, matching the rest of this backend's {@code Instant}/
 * {@code ZoneOffset.UTC} conventions - see {@code app.indus.source-timezone}
 * in application.yml if the ingestion pipeline actually writes local
 * (IST) timestamps instead; that property lets {@link IndusWeatherService}
 * convert without any code change.
 *
 * See {@link IndusStation} for why this belongs to the separate "indus"
 * persistence unit and is never written to.
 */
@Entity
@Table(name = "INDUS_WeatherData")
public class IndusWeatherData {

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "station_id")
    private Long stationId;

    @Column(name = "district_name")
    private String districtName;

    @Column(name = "circle")
    private String circle;

    @Column(name = "area")
    private String area;

    @Column(name = "zone")
    private String zone;

    @Column(name = "region_type")
    private String regionType;

    @Column(name = "latitude")
    private double latitude;

    @Column(name = "longitude")
    private double longitude;

    @Column(name = "forecast_time")
    private LocalDateTime forecastTime;

    @Column(name = "temperature_2m")
    private Double temperature2m;

    @Column(name = "snowfall")
    private Double snowfall;

    @Column(name = "visibility")
    private Double visibility;

    @Column(name = "wind_speed_10m")
    private Double windSpeed10m;

    @Column(name = "wind_direction_10m")
    private Double windDirection10m;

    @Column(name = "precipitation")
    private Double precipitation;

    @Column(name = "precipitation_probability")
    private Double precipitationProbability;

    @Column(name = "wind_gusts_10m")
    private Double windGusts10m;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public Long getId() {
        return id;
    }

    public Long getStationId() {
        return stationId;
    }

    public String getDistrictName() {
        return districtName;
    }

    public String getCircle() {
        return circle;
    }

    public String getArea() {
        return area;
    }

    public String getZone() {
        return zone;
    }

    public String getRegionType() {
        return regionType;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public LocalDateTime getForecastTime() {
        return forecastTime;
    }

    public Double getTemperature2m() {
        return temperature2m;
    }

    public Double getSnowfall() {
        return snowfall;
    }

    public Double getVisibility() {
        return visibility;
    }

    public Double getWindSpeed10m() {
        return windSpeed10m;
    }

    public Double getWindDirection10m() {
        return windDirection10m;
    }

    public Double getPrecipitation() {
        return precipitation;
    }

    public Double getPrecipitationProbability() {
        return precipitationProbability;
    }

    public Double getWindGusts10m() {
        return windGusts10m;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
