package com.weatherops.backend.indus;

import org.springframework.data.jpa.repository.JpaRepository;

/** Read-only repository over the user's existing {@code INDUS_Stations} table - see {@link IndusStation}. */
public interface IndusStationRepository extends JpaRepository<IndusStation, Long> {
}
