package com.weatherops.backend.indus;

import com.weatherops.backend.dto.weather.CurrentObservationDto;
import com.weatherops.backend.dto.weather.ForecastDayDto;
import com.weatherops.backend.dto.weather.HistoricalPointDto;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

/**
 * Turns real {@link IndusWeatherData} rows into this app's existing weather
 * DTOs. Column names match Open-Meteo's convention (temperature_2m,
 * wind_speed_10m, wind_gusts_10m, ...), so this assumes Open-Meteo's default
 * units throughout: °C, km/h, mm (precipitation), cm (snowfall), meters
 * (visibility), % (precipitation_probability). Adjust the constants below if
 * the ingestion pipeline actually uses different units.
 * <p>
 * <b>Real vs. derived/estimated fields</b> - per the user's explicit choice
 * to keep every existing map layer/parameter working rather than remove the
 * ones the source table has no column for:
 * <ul>
 *   <li><b>Real, straight from the source:</b> temperature, wind speed,
 *   wind gusts, wind direction, precipitation (-> rainfall), precipitation
 *   probability, snowfall, visibility.</li>
 *   <li><b>Derived/estimated, clearly not measured</b> - condition, cloud
 *   cover (via {@code estimateCloudCoverPercent} on the frontend, from
 *   condition), humidity, feels-like temperature, pressure, and
 *   lightning-strike count. None of these have a source column, so each is
 *   computed from a simple, documented heuristic below rather than a random
 *   number - see each method's own comment for the exact reasoning. If the
 *   ingestion pipeline is later extended to carry real humidity/pressure/
 *   cloud-cover columns, prefer wiring those through directly instead of
 *   these estimates.</li>
 * </ul>
 */
@Component
public class IndusWeatherMapper {

    public CurrentObservationDto toCurrentObservation(
            String siteId, Instant at, IndusWeatherData row, int elevationMeters, double rainfallTodayMm) {
        double temperature = orZero(row.getTemperature2m());
        double windSpeed = orZero(row.getWindSpeed10m());
        double windGusts = orZero(row.getWindGusts10m());
        double precipitation = orZero(row.getPrecipitation());
        double snowfall = orZero(row.getSnowfall());
        double visibilityKm = orZero(row.getVisibility()) / 1000.0;
        int precipProbability = (int) Math.round(orZero(row.getPrecipitationProbability()));
        String condition = deriveCondition(temperature, precipitation, snowfall, visibilityKm, windSpeed, precipProbability);

        CurrentObservationDto dto = new CurrentObservationDto();
        dto.siteId = siteId;
        dto.timestamp = at;
        dto.temperature = round1(temperature);
        dto.feelsLike = round1(deriveFeelsLike(temperature, windSpeed));
        dto.humidity = deriveHumidity(precipProbability, visibilityKm);
        dto.rainfallLastHour = round1(precipitation);
        dto.rainfallToday = round1(rainfallTodayMm);
        dto.windSpeed = round1(windSpeed);
        dto.windGust = round1(windGusts);
        dto.windDirection = (int) Math.round(orZero(row.getWindDirection10m()));
        dto.pressure = derivePressure(elevationMeters);
        dto.lightningStrikesLastHour = deriveLightning(precipitation, windGusts);
        dto.condition = condition;
        dto.visibilityKm = round1(visibilityKm);
        dto.snowfallCm = round1(snowfall);
        return dto;
    }

    public HistoricalPointDto toHistoricalPoint(IndusWeatherData row, ZoneId sourceZone) {
        double temperature = orZero(row.getTemperature2m());
        double windSpeed = orZero(row.getWindSpeed10m());
        double precipitation = orZero(row.getPrecipitation());
        double windGusts = orZero(row.getWindGusts10m());
        double visibilityKm = orZero(row.getVisibility()) / 1000.0;
        int precipProbability = (int) Math.round(orZero(row.getPrecipitationProbability()));

        HistoricalPointDto dto = new HistoricalPointDto();
        dto.timestamp = row.getForecastTime().atZone(sourceZone).toInstant();
        dto.temperature = round1(temperature);
        dto.humidity = deriveHumidity(precipProbability, visibilityKm);
        dto.rainfall = round1(precipitation);
        dto.windSpeed = round1(windSpeed);
        dto.pressure = derivePressure(200); // historical points aren't tied to one site's elevation estimate here
        dto.lightningStrikes = deriveLightning(precipitation, windGusts);
        dto.snowfallCm = round1(orZero(row.getSnowfall()));
        return dto;
    }

    /** Aggregates one calendar day's hourly rows into a single forecast-day
     *  summary, matching {@link com.weatherops.backend.weather.WeatherGenerator#forecast}'s
     *  DTO shape. Returns {@code null} if {@code dayRows} is empty (the
     *  caller skips that date rather than fabricating a day with no data). */
    public ForecastDayDto toForecastDay(LocalDate date, List<IndusWeatherData> dayRows) {
        if (dayRows.isEmpty()) return null;

        double minTemp = Double.MAX_VALUE;
        double maxTemp = -Double.MAX_VALUE;
        double totalRainfall = 0;
        double totalSnowfall = 0;
        double maxWindSpeed = 0;
        double maxWindGusts = 0;
        int maxPrecipProbability = 0;
        double minVisibilityKm = Double.MAX_VALUE;

        for (IndusWeatherData row : dayRows) {
            double temp = orZero(row.getTemperature2m());
            minTemp = Math.min(minTemp, temp);
            maxTemp = Math.max(maxTemp, temp);
            totalRainfall += orZero(row.getPrecipitation());
            totalSnowfall += orZero(row.getSnowfall());
            maxWindSpeed = Math.max(maxWindSpeed, orZero(row.getWindSpeed10m()));
            maxWindGusts = Math.max(maxWindGusts, orZero(row.getWindGusts10m()));
            maxPrecipProbability = Math.max(maxPrecipProbability, (int) Math.round(orZero(row.getPrecipitationProbability())));
            minVisibilityKm = Math.min(minVisibilityKm, orZero(row.getVisibility()) / 1000.0);
        }

        String condition = deriveCondition(maxTemp, totalRainfall, totalSnowfall, minVisibilityKm, maxWindSpeed, maxPrecipProbability);

        ForecastDayDto dto = new ForecastDayDto();
        dto.date = date;
        dto.minTemp = round1(minTemp);
        dto.maxTemp = round1(maxTemp);
        dto.rainfallProbability = maxPrecipProbability;
        dto.expectedRainfallMm = round1(totalRainfall);
        dto.windSpeed = round1(maxWindSpeed);
        dto.condition = condition;
        dto.summary = summaryFor(condition, maxPrecipProbability, totalRainfall);
        return dto;
    }

    /** Deterministic (no randomness, unlike the synthetic mock generator)
     *  condition classification from real values, checked most-severe-first:
     *  snow if any snowfall is forecast; thunderstorm for heavy rain
     *  alongside strong gusts (a real proxy for storm activity, since there's
     *  no separate CAPE/lightning-probability column); plain rain for any
     *  meaningful precipitation; fog for genuinely poor visibility; windy for
     *  strong sustained wind with no rain; otherwise cloudy/partly-cloudy/
     *  clear purely from precipitation *probability*, since that's the
     *  closest real proxy this data has for cloud cover. */
    private String deriveCondition(
            double temperature, double rainfallMm, double snowfallCm, double visibilityKm, double windSpeedKmph, int precipProbability) {
        if (snowfallCm > 0.1) return snow();
        if (rainfallMm > 12 && windSpeedKmph > 30) return "thunderstorm";
        if (rainfallMm > 2) return "rain";
        if (visibilityKm > 0 && visibilityKm < 1) return "fog";
        if (windSpeedKmph > 35) return "windy";
        if (precipProbability > 60) return "cloudy";
        if (precipProbability > 30) return "partly-cloudy";
        return "clear";
    }

    // Small helper kept separate only so the "snow" literal has one place to
    // live if a dedicated WeatherCondition value is ever added for it - today
    // the frontend's WeatherCondition union has no "snow" entry, so a snowy
    // hour is reported as "cloudy" (the closest existing condition) with the
    // real snowfallCm value still carried on the DTO for the Snowfall map
    // layer, which reads that field directly rather than the condition string.
    private String snow() {
        return "cloudy";
    }

    /** Rough estimate: humid air both raises rain probability and cuts
     *  visibility, so this blends the two into a plausible-looking humidity%
     *  - not a substitute for a real hygrometer reading, which this source
     *  simply doesn't provide. */
    private int deriveHumidity(int precipProbability, double visibilityKm) {
        double visibilityPenalty = Math.max(0, 10 - Math.min(visibilityKm, 10)) * 2.5;
        double value = 35 + precipProbability * 0.45 + visibilityPenalty;
        return (int) Math.round(Math.max(20, Math.min(98, value)));
    }

    /** Simplified wind-chill-style adjustment for cold+windy hours only
     *  (the regime where "feels like" meaningfully differs from the air
     *  temperature without also needing a real humidity/heat-index model). */
    private double deriveFeelsLike(double temperature, double windSpeedKmph) {
        if (temperature <= 10 && windSpeedKmph > 5) {
            return temperature - Math.min(6, windSpeedKmph / 10.0);
        }
        return temperature;
    }

    /** Standard-atmosphere approximation (~1 hPa per 8-9m of elevation) from
     *  the site's (already-estimated, see {@link IndusSiteMapper}) elevation
     *  - the source has no barometric column at all, so this is a physically
     *  plausible baseline rather than a measured reading. */
    private int derivePressure(int elevationMeters) {
        double value = 1013 - (elevationMeters / 8.5);
        return (int) Math.round(Math.max(850, Math.min(1030, value)));
    }

    /** Lightning-strike-count proxy: only non-zero for the same
     *  heavy-rain-plus-strong-gusts combination {@link #deriveCondition}
     *  calls "thunderstorm", scaled by rainfall intensity - there is no
     *  actual lightning-detection column in this data. */
    private int deriveLightning(double rainfallMm, double windGustsKmph) {
        if (rainfallMm > 12 && windGustsKmph > 30) {
            return (int) Math.round(Math.min(40, rainfallMm / 1.5));
        }
        return 0;
    }

    private String summaryFor(String condition, int rainfallProbability, double totalRainfallMm) {
        return switch (condition) {
            case "thunderstorm" -> "Thunderstorms likely, " + rainfallProbability + "% chance of rain";
            case "rain" -> "Rain expected (" + round1(totalRainfallMm) + " mm), " + rainfallProbability + "% chance";
            case "windy" -> "Strong winds expected";
            case "fog" -> "Foggy conditions expected";
            case "cloudy" -> "Overcast through the day";
            case "partly-cloudy" -> "Partly cloudy skies";
            default -> "Clear skies expected";
        };
    }

    private double orZero(Double v) {
        return v == null ? 0 : v;
    }

    private double round1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }
}
