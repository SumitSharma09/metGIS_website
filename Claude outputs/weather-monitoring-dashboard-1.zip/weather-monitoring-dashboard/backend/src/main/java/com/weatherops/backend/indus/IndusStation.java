package com.weatherops.backend.indus;

import jakarta.persistence.*;

/**
 * Read-only mapping onto the user's own, pre-existing {@code INDUS_Stations}
 * MySQL table (real tower/site master data - station id, telecom circle,
 * district, area, zone, real-world lat/long, and a Hilly/Plains region type),
 * as shown to Claude directly from a `mysql>` session:
 *
 * <pre>
 * +----+---------------+---------------+---------------+------+--------+-------------------+--------------------+------------+
 * | ID | CIRCLE        | INDUS_SITE_ID | DISTRICT_NAME | AREA | ZONE   | PRIORITY_LATITUDE | PRIORITY_LONGITUDE | RegionType |
 * +----+---------------+---------------+---------------+------+--------+-------------------+--------------------+------------+
 * |  1 | Jammu Kashmir | IN-2019381    | Doda          | DODA | BATOTE |         33.161000 |          75.715000 | Hilly      |
 * </pre>
 *
 * This entity belongs to the separate "indus" persistence unit
 * (see {@link IndusDataSourceConfig}), which is configured with
 * {@code hibernate.hbm2ddl.auto=none} and the identity physical-naming
 * strategy specifically so Hibernate never attempts to create, alter, or
 * rename anything in this table - it is treated purely as an external,
 * read-only data source, exactly like calling a third-party weather API.
 * Nothing in this app ever writes to {@code INDUS_Stations} or
 * {@code INDUS_WeatherData}.
 */
@Entity
@Table(name = "INDUS_Stations")
public class IndusStation {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "CIRCLE")
    private String circle;

    @Column(name = "INDUS_SITE_ID")
    private String indusSiteId;

    @Column(name = "DISTRICT_NAME")
    private String districtName;

    @Column(name = "AREA")
    private String area;

    @Column(name = "ZONE")
    private String zone;

    @Column(name = "PRIORITY_LATITUDE")
    private double priorityLatitude;

    @Column(name = "PRIORITY_LONGITUDE")
    private double priorityLongitude;

    @Column(name = "RegionType")
    private String regionType;

    public Long getId() {
        return id;
    }

    public String getCircle() {
        return circle;
    }

    public String getIndusSiteId() {
        return indusSiteId;
    }

    public String getDistrictName() {
        return districtName;
    }

    public String getArea() {
        return area;
    }

    public String getZone() {
        return zone;
    }

    public double getPriorityLatitude() {
        return priorityLatitude;
    }

    public double getPriorityLongitude() {
        return priorityLongitude;
    }

    public String getRegionType() {
        return regionType;
    }
}
