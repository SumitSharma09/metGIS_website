package com.weatherops.backend.indus;

import com.weatherops.backend.domain.Site;
import com.weatherops.backend.domain.SiteStatus;
import com.weatherops.backend.domain.TowerType;
import org.springframework.stereotype.Component;

import java.util.Locale;

/**
 * Maps a real {@link IndusStation} row onto this app's own {@link Site}
 * domain shape, so the rest of the app (RBAC's {@link com.weatherops.backend.security.AccessScope},
 * {@link com.weatherops.backend.dto.site.SiteDto#from}, the Live Map, ...)
 * can treat a real station exactly like the demo data's {@code Site} entity
 * without any of that code needing to know the difference. The returned
 * {@link Site} is transient (never passed to {@code siteRepository.save()})
 * - it exists only in memory for the duration of one request.
 * <p>
 * Field mapping, and what's a real value vs. a documented estimate:
 * <ul>
 *   <li>{@code id} = the numeric {@code INDUS_Stations.ID} as a string -
 *   deliberately NOT {@code INDUS_SITE_ID}, because
 *   {@code INDUS_WeatherData.station_id} is a foreign key to this numeric
 *   id (confirmed from the sample rows), so keeping {@code Site.id} equal to
 *   it makes {@link IndusWeatherService}'s weather lookup a direct,
 *   cheap join with no separate id-translation table needed.</li>
 *   <li>{@code code} = {@code INDUS_SITE_ID} (e.g. "IN-2019381") - the real,
 *   human-facing site code.</li>
 *   <li>{@code state} = resolved from {@code district_name} (+ circle as a
 *   disambiguator) via {@link DistrictStateResolver} - real, but derived,
 *   since the source table has no state column of its own.</li>
 *   <li>{@code circle}/{@code district} = the real {@code CIRCLE}/
 *   {@code DISTRICT_NAME} columns, unchanged.</li>
 *   <li>{@code name} = title-cased {@code AREA} (the source's most specific
 *   per-station locality field in the sample data) - if the real, full
 *   dataset turns out to use {@code AREA} more like a broad zone than a
 *   per-tower name, prefer {@code ZONE} instead once you can see more rows;
 *   this is a best-effort guess from a 1-2 row sample, not a documented
 *   contract from the source system.</li>
 *   <li>{@code tehsil} - NOT mapped here: the backend's own {@link Site}
 *   entity and {@link com.weatherops.backend.dto.site.SiteDto} have no
 *   {@code tehsil} field at all (a pre-existing gap - only the frontend
 *   mock data layer's {@code Site} type carries one today). Out of scope
 *   for this change; add a {@code tehsil} column to both if/when the real
 *   backend needs to serve it.</li>
 *   <li>{@code elevationMeters} - NOT in the source data at all. Estimated
 *   coarsely from {@code RegionType} ("Hilly" -> 2200m, everything else
 *   -> 200m) purely so the existing elevation-gated snowfall/avalanche risk
 *   logic (see {@code src/utils/severity.ts}) has a non-zero elevation to
 *   work with for real hill stations - this is a category-level guess, not
 *   a measured elevation, and is documented as such wherever it's used.</li>
 *   <li>{@code towerType}/{@code status} - NOT in the source data either;
 *   defaulted to {@code MONOPOLE}/{@code ACTIVE} for every station (an
 *   arbitrary but harmless placeholder - nothing in this app currently
 *   branches Live Map behavior on tower type, and every real station is
 *   presumably active or it wouldn't be forecasting weather for it).</li>
 *   <li>{@code address}/{@code installedOn}/{@code contactPerson}/
 *   {@code contactPhone} - left null; genuinely not available from this
 *   source, and only used by the (real-backend-only, not Live-Map-facing)
 *   Sites list/detail pages' contact-info display.</li>
 * </ul>
 */
@Component
public class IndusSiteMapper {

    private final DistrictStateResolver districtStateResolver;

    public IndusSiteMapper(DistrictStateResolver districtStateResolver) {
        this.districtStateResolver = districtStateResolver;
    }

    public Site toSite(IndusStation station) {
        Site site = new Site();
        site.setId(String.valueOf(station.getId()));
        site.setCode(station.getIndusSiteId());
        site.setName(titleCase(nonBlank(station.getArea(), station.getDistrictName())));
        site.setCircle(nonBlank(station.getCircle(), "Unknown"));
        site.setState(districtStateResolver.resolve(station.getDistrictName(), station.getCircle()));
        site.setDistrict(nonBlank(station.getDistrictName(), "Unknown"));
        site.setLatitude(station.getPriorityLatitude());
        site.setLongitude(station.getPriorityLongitude());
        site.setElevationMeters(estimateElevationMeters(station.getRegionType()));
        site.setTowerType(TowerType.MONOPOLE);
        site.setStatus(SiteStatus.ACTIVE);
        return site;
    }

    private int estimateElevationMeters(String regionType) {
        if (regionType != null && regionType.trim().equalsIgnoreCase("hilly")) {
            return 2200;
        }
        return 200;
    }

    private String titleCase(String s) {
        if (s == null || s.isBlank()) return s;
        String[] words = s.trim().toLowerCase(Locale.ROOT).split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    private String nonBlank(String value, String fallback) {
        return (value == null || value.isBlank()) ? fallback : value;
    }
}

