package com.weatherops.backend.service;

import com.weatherops.backend.common.ApiException;
import com.weatherops.backend.common.PageResponse;
import com.weatherops.backend.domain.Site;
import com.weatherops.backend.dto.site.SiteDto;
import com.weatherops.backend.indus.IndusSiteMapper;
import com.weatherops.backend.indus.IndusStationRepository;
import com.weatherops.backend.repository.SiteRepository;
import com.weatherops.backend.security.AccessScope;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

@Service
public class SiteService {

    private final SiteRepository siteRepository;
    private final ObjectProvider<IndusStationRepository> indusStationRepository;
    private final IndusSiteMapper indusSiteMapper;
    private final boolean indusEnabled;

    public SiteService(
            SiteRepository siteRepository,
            ObjectProvider<IndusStationRepository> indusStationRepository,
            IndusSiteMapper indusSiteMapper,
            @Value("${app.indus.enabled:false}") boolean indusEnabled) {
        this.siteRepository = siteRepository;
        this.indusStationRepository = indusStationRepository;
        this.indusSiteMapper = indusSiteMapper;
        this.indusEnabled = indusEnabled;
    }

    /**
     * Every site-sourcing method below goes through this one method rather
     * than {@code siteRepository.findAll()} directly, so the single
     * {@code app.indus.enabled} flag (see application.yml) is the only
     * thing that decides whether the whole app (Live Map included) sees the
     * ~20 demo sites or every real station from the user's own MySQL
     * {@code INDUS_Stations} table (via {@link IndusSiteMapper}) - see
     * {@code com.weatherops.backend.indus.IndusDataSourceConfig} for why
     * this is completely inert (no MySQL connection attempted at all) when
     * the flag is left at its default {@code false}.
     * <p>
     * Loads every station into memory on each call, same as the existing
     * "small dataset" comment below already accepted for the ~20 demo
     * sites - fine for the low hundreds/thousands of real stations this is
     * designed for, but a large-scale deployment should push filtering down
     * into a native/JPQL query instead of this in-memory stream once the
     * station count grows large enough for that to matter.
     */
    private List<Site> loadAllSites() {
        if (indusEnabled) {
            IndusStationRepository repo = indusStationRepository.getIfAvailable();
            if (repo == null) return List.of();
            return repo.findAll().stream().map(indusSiteMapper::toSite).toList();
        }
        return siteRepository.findAll();
    }

    /** Same sites {@link #loadAllSites()} would return, already RBAC-scoped
     *  to the caller and (when {@code siteIds} is non-empty) filtered down to
     *  just those ids - used by {@link WeatherService#currentFor} so a
     *  weather lookup can never see a site outside the caller's scope,
     *  whichever data source (demo or Indus) is active. */
    public List<Site> listAllInScope(List<String> siteIds) {
        List<Site> scoped = AccessScope.restrictToScope(loadAllSites());
        if (siteIds == null || siteIds.isEmpty()) return scoped;
        return scoped.stream().filter(s -> siteIds.contains(s.getId())).toList();
    }

    public PageResponse<SiteDto> listSites(String search, String circle, String state, String district,
                                            String status, Integer page, Integer pageSize,
                                            String sortBy, String sortDir) {
        List<Site> all = loadAllSites();

        List<Site> filtered = all.stream()
                .filter(s -> circle == null || circle.isBlank() || s.getCircle().equalsIgnoreCase(circle))
                .filter(s -> state == null || state.isBlank() || s.getState().equalsIgnoreCase(state))
                .filter(s -> district == null || district.isBlank() || s.getDistrict().equalsIgnoreCase(district))
                .filter(s -> status == null || status.isBlank() || s.getStatus().toJson().equalsIgnoreCase(status))
                .filter(s -> matchesSearch(s, search))
                .sorted(comparatorFor(sortBy, sortDir))
                .toList();
        // RBAC: a non-admin only ever sees sites in their assigned states,
        // regardless of what the caller asked for (an out-of-scope `state`
        // filter just yields an empty page, not an error).
        filtered = AccessScope.restrictToScope(filtered);

        int p = page == null || page < 1 ? 1 : page;
        int size = pageSize == null || pageSize < 1 ? 10 : pageSize;
        int from = Math.min((p - 1) * size, filtered.size());
        int to = Math.min(from + size, filtered.size());

        List<SiteDto> pageItems = filtered.subList(from, to).stream().map(SiteDto::from).toList();
        return new PageResponse<>(pageItems, filtered.size(), p, size);
    }

    public SiteDto getSite(String id) {
        return SiteDto.from(findOrThrow(id));
    }

    public Site findOrThrow(String id) {
        Site site;
        if (indusEnabled) {
            site = loadAllSites().stream().filter(s -> s.getId().equals(id)).findFirst()
                    .orElseThrow(() -> ApiException.notFound("Site not found"));
        } else {
            site = siteRepository.findById(id).orElseThrow(() -> ApiException.notFound("Site not found"));
        }
        if (!AccessScope.canAccessState(site.getState())) {
            // Deliberately the same "not found" a real lookup miss would
            // give - a 403 with a state name in the body would tell a
            // non-admin exactly which real site IDs exist outside their
            // scope, which is its own small information leak.
            throw ApiException.notFound("Site not found");
        }
        return site;
    }

    public List<String> listCircles() {
        if (indusEnabled) {
            List<Site> scoped = AccessScope.isPanIndia() ? loadAllSites() : AccessScope.restrictToScope(loadAllSites());
            return scoped.stream().map(Site::getCircle).distinct().sorted().toList();
        }
        if (AccessScope.isPanIndia()) return siteRepository.findDistinctCircles();
        return AccessScope.restrictToScope(siteRepository.findAll()).stream()
                .map(Site::getCircle).distinct().sorted().toList();
    }

    public List<String> listStates() {
        if (indusEnabled) {
            List<Site> scoped = AccessScope.isPanIndia() ? loadAllSites() : AccessScope.restrictToScope(loadAllSites());
            return scoped.stream().map(Site::getState).distinct().sorted().toList();
        }
        List<String> all = siteRepository.findDistinctStates();
        if (AccessScope.isPanIndia()) return all;
        return all.stream().filter(AccessScope::canAccessState).toList();
    }

    public List<String> listDistricts(String state) {
        if (state != null && !state.isBlank() && !AccessScope.canAccessState(state)) {
            return List.of();
        }
        if (indusEnabled) {
            List<Site> scoped = AccessScope.isPanIndia() ? loadAllSites() : AccessScope.restrictToScope(loadAllSites());
            return scoped.stream()
                    .filter(s -> state == null || state.isBlank() || s.getState().equalsIgnoreCase(state))
                    .map(Site::getDistrict).distinct().sorted().toList();
        }
        if (state != null && !state.isBlank()) {
            return siteRepository.findDistinctDistricts(state);
        }
        // No state filter: restrict the nationwide district list down to
        // districts that actually belong to an in-scope state.
        if (AccessScope.isPanIndia()) return siteRepository.findDistinctDistricts(null);
        return AccessScope.restrictToScope(siteRepository.findAll()).stream()
                .map(Site::getDistrict).distinct().sorted().toList();
    }

    private boolean matchesSearch(Site s, String search) {
        if (search == null || search.isBlank()) return true;
        String q = search.toLowerCase();
        return s.getName().toLowerCase().contains(q)
                || s.getCode().toLowerCase().contains(q)
                || s.getCircle().toLowerCase().contains(q)
                || s.getState().toLowerCase().contains(q)
                || s.getDistrict().toLowerCase().contains(q);
    }

    private Comparator<Site> comparatorFor(String sortBy, String sortDir) {
        Function<Site, String> key = switch (sortBy == null ? "" : sortBy) {
            case "code" -> Site::getCode;
            case "circle" -> Site::getCircle;
            case "state" -> Site::getState;
            case "district" -> Site::getDistrict;
            default -> Site::getName;
        };
        Comparator<Site> comparator = Comparator.comparing(key, String.CASE_INSENSITIVE_ORDER);
        return "desc".equalsIgnoreCase(sortDir) ? comparator.reversed() : comparator;
    }
}
