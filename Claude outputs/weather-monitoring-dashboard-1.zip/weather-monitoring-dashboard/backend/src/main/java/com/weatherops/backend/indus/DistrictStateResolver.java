package com.weatherops.backend.indus;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Resolves an Indian state/UT name from an {@code INDUS_Stations} row's
 * {@code district_name} (+ {@code circle} as a disambiguator), so the Live
 * Map's state-scoped features (the state dropdown, the per-state district
 * choropleth, RBAC's {@code assignedStates}) work correctly for real
 * stations - none of that is usable if {@code Site.state} is wrong or blank.
 * <p>
 * The primary lookup table ({@code indus/district-state-map.json}, bundled
 * as a resource) is generated once from this project's own already-verified
 * government-sourced district boundary files
 * ({@code public/data/districts/*.json}, {@code st_nm}/{@code district}
 * properties - see {@code docs/generate_boundaries.py}) via a small one-off
 * script, not hand-typed - see {@code backend/README.md} for how to
 * regenerate it if the frontend's boundary data ever changes. 631 distinct
 * district names map to exactly one state each; 10 district names
 * ("Aurangabad", "Bijapur", "Bilaspur", "East", "Hamirpur", "North",
 * "Pratapgarh", "Raigarh", "South", "West") are real district names that
 * exist in more than one state, so those are disambiguated with
 * {@code circle} first, below.
 * <p>
 * A district name that matches neither the direct lookup nor a known
 * ambiguous case falls back to a single-state telecom circle
 * (e.g. "Gujarat" circle unambiguously means Gujarat state) - most circles
 * map 1:1 to a state, but circles like "North East" (six states) or
 * "Madhya Pradesh" (also covers Chhattisgarh) don't, and in that case this
 * returns {@code null} and logs a warning rather than guessing: the caller
 * (see {@link IndusSiteMapper}) then uses the literal string
 * {@code "Unknown"} so the station still appears on the map (right lat/long)
 * but is flagged for the state name to be corrected/added to the alias table
 * once the real district spelling is known.
 */
@Component
public class DistrictStateResolver {

    private static final Logger log = LoggerFactory.getLogger(DistrictStateResolver.class);

    /** {district name (lowercase, trimmed) -> state name}, ~631 entries. */
    private final Map<String, String> districtToState;

    /** Extra spellings/aliases seen in real-world data that don't exactly
     *  match this app's own district boundary files - same idea as the
     *  frontend's DISTRICT_ALIASES in districtGeo.ts, kept as a separate,
     *  small, easy-to-extend list rather than folded into the generated
     *  district-state-map.json. Add an entry here if a real station's
     *  district_name logs an "unresolved district" warning below. */
    private static final Map<String, String> DISTRICT_ALIASES = Map.ofEntries(
            Map.entry("bangalore", "bengaluru urban"),
            Map.entry("bangalore urban", "bengaluru urban"),
            Map.entry("mysore", "mysuru"),
            Map.entry("mumbai", "mumbai suburban"),
            Map.entry("mumbai city", "mumbai suburban"),
            Map.entry("bombay", "mumbai suburban"),
            Map.entry("gurgaon", "gurugram"),
            Map.entry("madras", "chennai"),
            Map.entry("purbi singhbhum", "east singhbhum"),
            Map.entry("ahmadabad", "ahmedabad"),
            Map.entry("hardwar", "haridwar"),
            Map.entry("haora", "howrah"));

    /** district (lowercase) -> {circle text fragment (lowercase) -> state}. Checked before the plain lookup. */
    private static final Map<String, Map<String, String>> AMBIGUOUS_DISTRICTS = Map.ofEntries(
            Map.entry("aurangabad", Map.of("bihar", "Bihar", "maharashtra", "Maharashtra")),
            Map.entry("bijapur", Map.of("karnataka", "Karnataka", "madhya", "Chhattisgarh", "chhattisgarh", "Chhattisgarh")),
            Map.entry("bilaspur", Map.of("himachal", "Himachal Pradesh", "madhya", "Chhattisgarh", "chhattisgarh", "Chhattisgarh")),
            Map.entry("hamirpur", Map.of("himachal", "Himachal Pradesh", "up", "Uttar Pradesh", "uttar pradesh", "Uttar Pradesh")),
            Map.entry("pratapgarh", Map.of("rajasthan", "Rajasthan", "up", "Uttar Pradesh", "uttar pradesh", "Uttar Pradesh")),
            Map.entry("raigarh", Map.of("maharashtra", "Maharashtra", "madhya", "Chhattisgarh", "chhattisgarh", "Chhattisgarh")),
            Map.entry("east", Map.of("delhi", "Delhi", "north east", "Sikkim", "sikkim", "Sikkim")),
            Map.entry("north", Map.of("delhi", "Delhi", "north east", "Sikkim", "sikkim", "Sikkim")),
            Map.entry("south", Map.of("delhi", "Delhi", "north east", "Sikkim", "sikkim", "Sikkim")),
            Map.entry("west", Map.of("delhi", "Delhi", "north east", "Sikkim", "sikkim", "Sikkim")));

    /** Telecom circle (normalized) -> state, for circles that map to exactly
     *  one state/UT and so can safely resolve a district this app's boundary
     *  data doesn't otherwise recognize. Circles spanning multiple states
     *  ("north east", "jammu" (also covers Ladakh UT), "madhya pradesh"
     *  (also covers Chhattisgarh), "up east"/"up west" (also covers
     *  Uttarakhand for a handful of border districts), "bihar" (also covers
     *  Jharkhand)) are deliberately left out - a district-name match should
     *  settle those, not a guess from the circle alone. */
    private static final Map<String, String> SINGLE_STATE_CIRCLES = Map.ofEntries(
            Map.entry("andhra pradesh", "Andhra Pradesh"),
            Map.entry("assam", "Assam"),
            Map.entry("chennai", "Tamil Nadu"),
            Map.entry("delhi", "Delhi"),
            Map.entry("gujarat", "Gujarat"),
            Map.entry("haryana", "Haryana"),
            Map.entry("karnataka", "Karnataka"),
            Map.entry("kerala", "Kerala"),
            Map.entry("kolkata", "West Bengal"),
            Map.entry("mumbai", "Maharashtra"),
            Map.entry("orissa", "Odisha"),
            Map.entry("odisha", "Odisha"),
            Map.entry("punjab", "Punjab"),
            Map.entry("rajasthan", "Rajasthan"),
            Map.entry("tamil nadu", "Tamil Nadu"),
            Map.entry("west bengal", "West Bengal"));

    private final Set<String> warnedDistricts = ConcurrentHashMap.newKeySet();

    public DistrictStateResolver(ObjectMapper objectMapper) {
        this.districtToState = loadMap(objectMapper);
    }

    @SuppressWarnings("unchecked")
    private Map<String, String> loadMap(ObjectMapper objectMapper) {
        try (InputStream in = new ClassPathResource("indus/district-state-map.json").getInputStream()) {
            return objectMapper.readValue(in, Map.class);
        } catch (IOException e) {
            log.error("Could not load indus/district-state-map.json - every Indus station will resolve to state=Unknown", e);
            return Map.of();
        }
    }

    /** Resolves a station's Indian state/UT from its district name (with the
     *  circle as a disambiguator for the handful of district names that
     *  exist in more than one state) - returns "Unknown" (never null) with a
     *  one-time warning log if nothing matches. */
    public String resolve(String districtName, String circle) {
        if (districtName == null || districtName.isBlank()) {
            return "Unknown";
        }
        String districtKey = normalize(districtName);
        String circleKey = circle == null ? "" : normalize(circle);

        Map<String, String> ambiguous = AMBIGUOUS_DISTRICTS.get(districtKey);
        if (ambiguous != null) {
            for (Map.Entry<String, String> candidate : ambiguous.entrySet()) {
                if (circleKey.contains(candidate.getKey())) {
                    return candidate.getValue();
                }
            }
            // Circle didn't match any known variant for this ambiguous name -
            // fall through to the plain lookup / circle fallback below rather
            // than guessing between the ambiguous candidates.
        }

        String resolvedKey = DISTRICT_ALIASES.getOrDefault(districtKey, districtKey);
        String state = districtToState.get(resolvedKey);
        if (state != null) {
            return state;
        }

        String fromCircle = SINGLE_STATE_CIRCLES.get(circleKey);
        if (fromCircle != null) {
            return fromCircle;
        }

        if (warnedDistricts.add(districtKey)) {
            log.warn(
                    "Indus station district \"{}\" (circle \"{}\") did not match this app's district->state "
                            + "lookup or a single-state circle - resolving to state=\"Unknown\" for now. Add an "
                            + "entry to DISTRICT_ALIASES (spelling mismatch) or AMBIGUOUS_DISTRICTS (a real "
                            + "multi-state district name) in DistrictStateResolver if this is a real district.",
                    districtName, circle);
        }
        return "Unknown";
    }

    private static String normalize(String s) {
        return s.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }
}
