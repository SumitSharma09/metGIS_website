package com.weatherops.backend.dto.weather;

import java.time.Instant;

public class CurrentObservationDto {
    public String siteId;
    public Instant timestamp;
    public double temperature;
    public double feelsLike;
    public int humidity;
    public double rainfallLastHour;
    public double rainfallToday;
    public double windSpeed;
    public double windGust;
    public int windDirection;
    public int pressure;
    public int lightningStrikesLastHour;
    public String condition; // WeatherCondition union
    public double visibilityKm;
    /** Real snowfall (cm) when sourced from Indus data (see
     *  com.weatherops.backend.indus.IndusWeatherMapper); left null for the
     *  synthetic mock generator, which doesn't model snow - the frontend's
     *  snowfall/avalanche risk logic falls back to its elevation-based proxy
     *  whenever this is null. */
    public Double snowfallCm;
}
