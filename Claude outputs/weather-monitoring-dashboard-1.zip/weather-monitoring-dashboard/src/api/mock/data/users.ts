import dayjs from 'dayjs';
import type { UserProfile } from '@/features/users/types';
import type { RegisterPayload } from '@/features/auth/types';

export const demoUsers: (UserProfile & { password: string })[] = [
  {
    id: 'user-1',
    username: 'admin',
    password: 'admin123',
    fullName: 'Sumit Sharma',
    email: 'sumit.javadeveloper09@gmail.com',
    phone: '+91 98200 12345',
    role: 'admin',
    designation: 'Network Operations Manager',
    lastLoginAt: dayjs().subtract(2, 'hour').toISOString(),
    assignedStates: [], // Pan-India
    // Pan-India admin has no single "home" circle to receive tower alerts
    // for, so no location/notificationPreferences here - see UserLocation's
    // doc comment in features/users/types.ts.
  },
  {
    id: 'user-2',
    username: 'operator',
    password: 'operator123',
    fullName: 'Priya Nair',
    email: 'priya.nair@example.com',
    phone: '+91 98450 67890',
    role: 'operator',
    designation: 'Field Operations Executive',
    lastLoginAt: dayjs().subtract(1, 'day').toISOString(),
    // Mirrors the Spring Boot DataSeeder's seeded operator scope.
    assignedStates: ['Delhi', 'Haryana'],
    // Illustrative registration data, so the Hazards page's "Registered
    // Recipients" preview has at least one match out of the box.
    location: { state: 'Delhi', district: 'New Delhi', circle: 'Delhi NCR' },
    notificationPreferences: { whatsapp: true, sms: true, email: true, whatsappNumber: '+91 98450 67890' },
  },
  {
    id: 'user-3',
    username: 'viewer',
    password: 'viewer123',
    fullName: 'Arjun Mehta',
    email: 'arjun.mehta@example.com',
    phone: '+91 98110 45678',
    role: 'viewer',
    designation: 'Regional Analyst',
    lastLoginAt: dayjs().subtract(5, 'day').toISOString(),
    // Mirrors the Spring Boot DataSeeder's seeded viewer scope.
    assignedStates: ['Karnataka'],
    location: { state: 'Karnataka', district: 'Bengaluru Urban', circle: 'Bangalore' },
    notificationPreferences: { whatsapp: false, sms: true, email: true },
  },
];

export const findUserByCredentials = (username: string, password: string) =>
  demoUsers.find((u) => u.username === username && u.password === password);

export const findUserById = (id: string) => demoUsers.find((u) => u.id === id);

export const findUserByUsername = (username: string) => demoUsers.find((u) => u.username === username);

/**
 * Mock-only "create account" - pushes a new self-service user into the
 * in-memory demoUsers array (there's no real persistence layer here, so
 * this resets on page reload, same as every other mock mutation in this
 * app). New accounts register as 'viewer', scoped to their own
 * registration state, matching the RBAC convention the seeded operator/
 * viewer accounts already follow.
 */
export function registerMockUser(payload: RegisterPayload): UserProfile & { password: string } {
  const user: UserProfile & { password: string } = {
    id: `user-${demoUsers.length + 1}-${Date.now()}`,
    username: payload.username,
    password: payload.password,
    fullName: payload.fullName,
    email: payload.email,
    phone: payload.phone,
    role: 'viewer',
    designation: payload.designation || 'Registered User',
    lastLoginAt: dayjs().toISOString(),
    assignedStates: [payload.location.state],
    location: payload.location,
    notificationPreferences: payload.notificationPreferences,
  };
  demoUsers.push(user);
  return user;
}
