import { useMemo } from 'react';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Alert from '@mui/material/Alert';
import { useListSitesQuery } from '@/features/sites/sitesApi';
import { useGetCurrentObservationsQuery } from '@/features/weather/weatherApi';
import { useListUsersQuery } from '@/features/users/usersApi';
import type { CurrentObservation } from '@/features/weather/types';
import { PageHeader } from '@/components/common/PageHeader';
import { LoadingState } from '@/components/common/LoadingState';
import { ErrorState } from '@/components/common/ErrorState';
import { useSevenDayObservations } from '@/pages/reports/useSevenDayObservations';
import { CycloneMap } from './components/CycloneMap';
import { FloodMap } from './components/FloodMap';
import { RiskIntensityDashboard } from './components/RiskIntensityDashboard';
import { CurrentDayAdvisory } from './components/CurrentDayAdvisory';
import { WeeklyAdvisories } from './components/WeeklyAdvisories';
import {
  getActiveCyclone,
  buildWeatherParameterRiskRows,
  buildHazardRiskRows,
  buildWeeklyAdvisories,
  buildCurrentDayAdvisories,
} from './hazardData';

export default function HazardsPage() {
  const { data: sitesPage, isLoading: sitesLoading, isError, refetch } = useListSitesQuery({ pageSize: 500 });
  const sites = useMemo(() => sitesPage?.items ?? [], [sitesPage]);
  const siteIds = useMemo(() => sites.map((s) => s.id), [sites]);

  const { data: observationsList, isLoading: obsLoading } = useGetCurrentObservationsQuery(siteIds, {
    skip: siteIds.length === 0,
  });
  const obsBySiteId = useMemo(() => {
    const map: Record<string, CurrentObservation> = {};
    (observationsList ?? []).forEach((obs) => {
      map[obs.siteId] = obs;
    });
    return map;
  }, [observationsList]);

  const { days, isLoading: forecastLoading } = useSevenDayObservations(siteIds);
  // Every registered user, matched to a Current Day Advisory row by circle
  // to preview who'd be notified and on which channel - see
  // notificationRecipients.ts's doc comment (mock preview only, no real
  // WhatsApp/SMS/email gateway behind it).
  const { data: registeredUsers = [] } = useListUsersQuery();

  const cyclone = useMemo(() => getActiveCyclone(), []);
  const parameterRows = useMemo(() => buildWeatherParameterRiskRows(sites, obsBySiteId), [sites, obsBySiteId]);
  const hazardRows = useMemo(() => buildHazardRiskRows(sites, obsBySiteId, cyclone), [sites, obsBySiteId, cyclone]);
  const weeklyRows = useMemo(() => buildWeeklyAdvisories(sites, days), [sites, days]);
  const currentDayRows = useMemo(() => buildCurrentDayAdvisories(weeklyRows), [weeklyRows]);

  const loading = sitesLoading || obsLoading;

  return (
    <Stack spacing={2}>
      <PageHeader
        title="Hazards & Advisories"
        description="Special cyclone bulletin, today's district risk intensity across every hazard, and the weekly monsoon-preparation advisory"
      />

      {isError ? (
        <ErrorState onRetry={refetch} />
      ) : loading ? (
        <LoadingState label="Loading hazard data..." />
      ) : (
        <>
          <Alert severity="info" variant="outlined">
            Lightning, Snowfall, Flood, Fog, and Avalanche now live as parameter toggles on the Live Map itself,
            alongside Temperature, Rainfall, Cloud, and Visibility - pick any of them there to see the same
            per-district and per-tower risk coloring. Cyclone stays here since it's a storm track, not a
            per-district reading.
          </Alert>

          <div>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
              Active Cyclone
            </Typography>
            <CycloneMap cyclone={cyclone} />
          </div>

          <div>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
              Flood Map
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
              District-wise flood risk, derived from current rainfall (no separate hydrological model behind this
              yet - see hazardData.ts's getFloodRisk)
            </Typography>
            <FloodMap sites={sites} observations={obsBySiteId} />
          </div>

          <div>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
              Today&apos;s Risk Intensity of Districts
            </Typography>
            <RiskIntensityDashboard parameterRows={parameterRows} hazardRows={hazardRows} />
          </div>

          <div>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
              Current Day Advisory
            </Typography>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
              Today's line out of the Daily Weather Alerts Report - the same per-circle outlook the weekly bulletin
              below tracks across the week, just for today. Recipients previews who'd be notified via WhatsApp/SMS/
              Email, based on the location and channels registered users chose at sign-up.
            </Typography>
            {forecastLoading ? (
              <LoadingState label="Loading today's outlook..." />
            ) : (
              <CurrentDayAdvisory rows={currentDayRows} users={registeredUsers} />
            )}
          </div>

          <div>
            <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>
              Weekly Advisories (Monsoon Preparation)
            </Typography>
            {forecastLoading ? (
              <LoadingState label="Loading 7-day outlook..." />
            ) : (
              <WeeklyAdvisories rows={weeklyRows} />
            )}
          </div>
        </>
      )}
    </Stack>
  );
}
