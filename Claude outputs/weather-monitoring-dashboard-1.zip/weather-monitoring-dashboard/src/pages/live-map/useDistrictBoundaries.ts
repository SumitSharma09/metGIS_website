import { useEffect, useMemo, useRef, useState } from 'react';
import { fetchStateDistricts, fetchIndiaStates, extractStateName, type DistrictFeature } from './districtGeo';
import { normalizeName } from '@/utils/districtRisk';
import { useScopedStates } from '@/features/users/useScopedStates';

interface StateBoundaryStatus {
  features: DistrictFeature[];
  loading: boolean;
  error: boolean;
}

const EMPTY_STATUS: StateBoundaryStatus = { features: [], loading: false, error: false };

/**
 * Loads district-boundary polygons for a set of states, one small
 * per-state file each (cached in `districtGeo.ts` for the tab's lifetime),
 * fetched in parallel. Used two ways by the Live Map:
 *  - no state picked yet -> pass every state that has a monitored site, so
 *    the whole country shows colored districts on first load (matching the
 *    reference product's default view);
 *  - a state picked -> pass just that one state, for the zoomed-in view.
 *
 * Implemented as one hook tracking a dynamic list (rather than one
 * `useDistrictBoundaries(stateName)` call per state) so the number of
 * states being watched can change from render to render without breaking
 * the rules of hooks.
 */
export function useDistrictBoundariesForStates(stateNames: string[]) {
  const [statusByState, setStatusByState] = useState<Record<string, StateBoundaryStatus>>({});
  const requested = useRef<Set<string>>(new Set());
  const key = [...stateNames].sort().join('|');

  useEffect(() => {
    stateNames.forEach((name) => {
      if (requested.current.has(name)) return;
      requested.current.add(name);
      setStatusByState((prev) => ({ ...prev, [name]: { features: [], loading: true, error: false } }));
      fetchStateDistricts(name)
        .then((collection) => {
          setStatusByState((prev) => ({ ...prev, [name]: { features: collection.features, loading: false, error: false } }));
        })
        .catch(() => {
          requested.current.delete(name); // allow a retry if this state is requested again later
          setStatusByState((prev) => ({ ...prev, [name]: { features: [], loading: false, error: true } }));
        });
    });
    // `key` (the sorted, joined state list) is the real dependency - it only
    // changes when the actual set of requested states changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  return {
    get: (stateName: string): StateBoundaryStatus => statusByState[stateName] ?? EMPTY_STATUS,
  };
}

interface IndiaStatesStatus {
  features: DistrictFeature[];
  loading: boolean;
  error: boolean;
}

/**
 * Loads the all-India state-boundary FeatureCollection once (memoized in
 * `districtGeo.ts` for the tab's lifetime) - the Live Map's default view,
 * shown before any state is picked. Kept separate from
 * `useDistrictBoundariesForStates` above because it fetches one fixed
 * asset rather than a dynamic, per-state list.
 */
export function useIndiaStates(): IndiaStatesStatus {
  const [status, setStatus] = useState<IndiaStatesStatus>({ features: [], loading: true, error: false });
  const requested = useRef(false);

  useEffect(() => {
    if (requested.current) return;
    requested.current = true;
    fetchIndiaStates()
      .then((collection) => setStatus({ features: collection.features, loading: false, error: false }))
      .catch(() => {
        requested.current = false; // allow a retry on next mount
        setStatus({ features: [], loading: false, error: true });
      });
  }, []);

  return status;
}

interface VisibleStates {
  /** RBAC-filtered state features, straight from `india-states.json` - a
   *  Pan-India user gets every one of the (currently 37) government-
   *  recognized states/UTs in that file, Ladakh included; a scoped
   *  operator/viewer gets only their own `assignedStates`, whether or not
   *  those states happen to have a monitored site yet. */
  features: DistrictFeature[];
  /** The same set, as sorted state-name strings - what every state
   *  dropdown/search box and "iterate every visible state" default view in
   *  this app should be built from. */
  names: string[];
  loading: boolean;
  error: boolean;
}

/**
 * The single, shared source of "every state/UT this signed-in user is
 * allowed to see" - combines the real government boundary list
 * (`useIndiaStates()`) with RBAC (`useScopedStates()`).
 *
 * Originally written inline in `LiveMapPage.tsx` to fix its State dropdown
 * (which used to be built from `useListStatesQuery()`, the site-derived
 * list - narrower than the real government state/UT list, since a state/UT
 * with no monitored demo site, like Jammu and Kashmir, Ladakh, or Arunachal
 * Pradesh, would never appear even though the app has real boundary data
 * for it). Pulled out into this shared hook so `FloodMap.tsx`,
 * `RegionRiskMap.tsx`, and the Reports page's state filter
 * (`TowerRiskReportsTab.tsx`) can all fix the exact same class of bug the
 * same way, instead of three more copies of `useListStatesQuery()` that
 * would each need re-fixing separately later.
 *
 * Note this only ever widens which *states* are considered - it doesn't
 * change what happens once a state with zero monitored sites is actually
 * selected (site lists/markers correctly stay empty there; only the
 * boundary polygons and dropdown options were ever the site-derived,
 * too-narrow list).
 */
export function useVisibleStates(): VisibleStates {
  const indiaStates = useIndiaStates();
  const { isPanIndia, assignedStates } = useScopedStates();

  const features = useMemo(() => {
    if (indiaStates.features.length === 0) return [];
    if (isPanIndia) return indiaStates.features;
    const allowed = new Set(assignedStates.map(normalizeName));
    return indiaStates.features.filter((f) => {
      const name = extractStateName(f);
      return name ? allowed.has(normalizeName(name)) : false;
    });
  }, [indiaStates.features, isPanIndia, assignedStates]);

  const names = useMemo(
    () =>
      features
        .map((f) => extractStateName(f))
        .filter((name): name is string => !!name)
        .sort(),
    [features]
  );

  return { features, names, loading: indiaStates.loading, error: indiaStates.error };
}
