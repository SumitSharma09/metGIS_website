import type { CurrentObservation } from '@/features/weather/types';
import type { Site } from '@/features/sites/types';
import {
  getParameterRisk,
  getCloudRisk,
  estimateCloudCoverPercent,
  getVisibilityRisk,
  getSnowfallRisk,
  getAvalancheRisk,
  type RiskLevel,
} from '@/utils/severity';

export type MapLayer = 'temperature' | 'rainfall' | 'wind' | 'cloud' | 'visibility' | 'fog' | 'lightning' | 'snowfall' | 'avalanche';

export const MAP_LAYERS: { value: MapLayer; label: string }[] = [
  { value: 'temperature', label: 'Temperature' },
  { value: 'rainfall', label: 'Rainfall' },
  { value: 'cloud', label: 'Cloud' },
  { value: 'visibility', label: 'Visibility' },
  { value: 'fog', label: 'Fog' },
  { value: 'wind', label: 'Wind' },
  { value: 'lightning', label: 'Lightning' },
  { value: 'snowfall', label: 'Snowfall' },
  { value: 'avalanche', label: 'Avalanche' },
];

/**
 * Each map layer gets its own color family (rather than every layer sharing
 * one red/orange/yellow/green ramp) so a glance at the map or its legend
 * tells you *which parameter* you're looking at, not just how severe it is.
 * Severity still increases from `none` -> `warning` within each family.
 * Temperature keeps the classic IMD-style warning colors (the reference
 * this was modeled on); every other layer gets a distinct hue.
 */
export const LAYER_COLORS: Record<MapLayer, Record<RiskLevel, string>> = {
  temperature: { none: '#16a34a', watch: '#eab308', alert: '#f97316', warning: '#dc2626' },
  rainfall: { none: '#7dd3fc', watch: '#38bdf8', alert: '#2563eb', warning: '#1e3a8a' },
  wind: { none: '#5eead4', watch: '#2dd4bf', alert: '#0d9488', warning: '#134e4a' },
  cloud: { none: '#94a3b8', watch: '#64748b', alert: '#475569', warning: '#1e293b' },
  visibility: { none: '#c4b5fd', watch: '#a78bfa', alert: '#7c3aed', warning: '#4c1d95' },
  fog: { none: '#d6d3d1', watch: '#a8a29e', alert: '#78716c', warning: '#44403c' },
  lightning: { none: '#fef08a', watch: '#fde047', alert: '#eab308', warning: '#92400e' },
  snowfall: { none: '#e0f2fe', watch: '#bae6fd', alert: '#7dd3fc', warning: '#075985' },
  avalanche: { none: '#f5d0fe', watch: '#e879f9', alert: '#c026d3', warning: '#701a75' },
};

export interface LayerLegendBand {
  level: RiskLevel;
  /** Human-readable range in the layer's own unit, for the map legend -
   *  keep these in sync with the actual thresholds in severity.ts (BANDS,
   *  getCloudRisk, getVisibilityRisk) and layerRisk() below. Layers with no
   *  entry here (snowfall/avalanche - multi-factor, not a single reading
   *  vs. a threshold) fall back to a plain qualitative legend. */
  rangeLabel: string;
}

export const LAYER_LEGEND: Partial<Record<MapLayer, LayerLegendBand[]>> = {
  temperature: [
    { level: 'warning', rangeLabel: '≥ 45°C' },
    { level: 'alert', rangeLabel: '40 – 44.9°C' },
    { level: 'watch', rangeLabel: '35 – 39.9°C' },
    { level: 'none', rangeLabel: '< 35°C' },
  ],
  rainfall: [
    { level: 'warning', rangeLabel: '≥ 40 mm/hr' },
    { level: 'alert', rangeLabel: '20 – 39 mm/hr' },
    { level: 'watch', rangeLabel: '10 – 19 mm/hr' },
    { level: 'none', rangeLabel: '< 10 mm/hr' },
  ],
  wind: [
    { level: 'warning', rangeLabel: '≥ 60 km/h' },
    { level: 'alert', rangeLabel: '40 – 59 km/h' },
    { level: 'watch', rangeLabel: '30 – 39 km/h' },
    { level: 'none', rangeLabel: '< 30 km/h' },
  ],
  cloud: [
    { level: 'warning', rangeLabel: '≥ 90% cover' },
    { level: 'alert', rangeLabel: '70 – 89% cover' },
    { level: 'watch', rangeLabel: '40 – 69% cover' },
    { level: 'none', rangeLabel: '< 40% cover' },
  ],
  visibility: [
    { level: 'warning', rangeLabel: '< 1 km' },
    { level: 'alert', rangeLabel: '1 – 1.9 km' },
    { level: 'watch', rangeLabel: '2 – 3.9 km' },
    { level: 'none', rangeLabel: '≥ 4 km' },
  ],
  fog: [
    { level: 'warning', rangeLabel: '< 1 km' },
    { level: 'alert', rangeLabel: '1 – 1.9 km' },
    { level: 'watch', rangeLabel: '2 – 3.9 km' },
    { level: 'none', rangeLabel: '≥ 4 km' },
  ],
  lightning: [
    { level: 'warning', rangeLabel: '≥ 20 /hr' },
    { level: 'alert', rangeLabel: '10 – 19 /hr' },
    { level: 'watch', rangeLabel: '1 – 9 /hr' },
    { level: 'none', rangeLabel: '0 /hr' },
  ],
};

/** A single continuous vertical gradient spanning a layer's whole color
 *  family, most severe ("warning") at the top down to least ("none") at
 *  the bottom - matches `RISK_LEVELS`' own top-to-bottom order, and the
 *  same visual language `WIND_GRADIENT_CSS` (windField.ts) already uses
 *  for the wind-flow legend, so every legend swatch in the app reads the
 *  same way regardless of which parameter it's for. */
export function layerGradientCss(colors: Record<RiskLevel, string>): string {
  return `linear-gradient(to top, ${colors.none} 0%, ${colors.watch} 40%, ${colors.alert} 70%, ${colors.warning} 100%)`;
}

/** Reading + unit shown on a marker/popup for the currently active layer.
 *  `site` is only needed for the elevation-dependent hazards (snowfall/
 *  avalanche) - every other layer ignores it. */
export function layerReading(
  layer: MapLayer,
  obs: CurrentObservation,
  site?: Pick<Site, 'elevationMeters'>
): { value: number; unit: string; label: string } {
  switch (layer) {
    case 'temperature':
      return { value: obs.temperature, unit: '°C', label: 'Temperature' };
    case 'rainfall':
      return { value: obs.rainfallLastHour, unit: 'mm/hr', label: 'Rainfall (last hr)' };
    case 'wind':
      return { value: obs.windSpeed, unit: 'km/h', label: 'Wind speed' };
    case 'cloud':
      // Matches the value getCloudRisk() actually colors by (see layerRisk
      // below) - showing humidity here instead would silently disagree
      // with the marker/legend color for the same reading.
      return { value: estimateCloudCoverPercent(obs.condition), unit: '%', label: 'Cloud cover (est.)' };
    case 'visibility':
      return { value: obs.visibilityKm, unit: 'km', label: 'Visibility' };
    case 'fog':
      return { value: obs.visibilityKm, unit: 'km', label: 'Visibility (fog)' };
    case 'lightning':
      return { value: obs.lightningStrikesLastHour, unit: '/hr', label: 'Lightning strikes' };
    case 'snowfall':
      return obs.snowfallCm !== undefined
        ? { value: obs.snowfallCm, unit: 'cm', label: 'Snowfall' }
        : { value: site?.elevationMeters ?? 0, unit: 'm elev.', label: 'Snowfall risk (by elevation)' };
    case 'avalanche':
      return { value: site?.elevationMeters ?? 0, unit: 'm elev.', label: 'Avalanche risk (by elevation)' };
    default:
      return { value: 0, unit: '', label: '' };
  }
}

/** Risk classification for a site under the currently active layer -
 *  this drives marker color and the legend, using the same thresholds
 *  shared with the Alerts feed and Tower Risk Reports. */
export function layerRisk(layer: MapLayer, obs: CurrentObservation, site?: Pick<Site, 'elevationMeters'>): RiskLevel {
  switch (layer) {
    case 'temperature':
      return getParameterRisk('temperature', obs.temperature);
    case 'rainfall':
      return getParameterRisk('rainfall', obs.rainfallLastHour);
    case 'wind':
      return getParameterRisk('windSpeed', obs.windSpeed);
    case 'cloud':
      return getCloudRisk(obs.condition);
    case 'visibility':
      return getVisibilityRisk(obs.visibilityKm);
    case 'fog':
      return obs.condition === 'fog' ? getVisibilityRisk(obs.visibilityKm) : 'none';
    case 'lightning':
      return getParameterRisk('lightning', obs.lightningStrikesLastHour);
    case 'snowfall':
      return site ? getSnowfallRisk(site.elevationMeters, obs.temperature, obs.snowfallCm) : 'none';
    case 'avalanche':
      return site ? getAvalancheRisk(site.elevationMeters, obs.temperature, obs.windSpeed, obs.snowfallCm) : 'none';
    default:
      return 'none';
  }
}
