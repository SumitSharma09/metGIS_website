import { useMemo } from 'react';
import L from 'leaflet';
import { GeoJSON, useMap } from 'react-leaflet';
import type { Layer, LeafletMouseEvent, PathOptions, StyleFunction } from 'leaflet';
import { extractStateName, type DistrictFeature, type DistrictFeatureCollection } from '../districtGeo';

interface StateOutlinesLayerProps {
  /** Real Survey-of-India state polygons (see districtGeo.ts's header),
   *  already narrowed by the caller to whichever states the signed-in user
   *  is scoped to see. */
  features: DistrictFeature[];
  onSelectState: (stateName: string) => void;
}

const STATE_STROKE = '#0b3d91';
const STATE_FILL = 'rgba(11, 61, 145, 0.08)';
const STATE_FILL_HOVER = 'rgba(11, 61, 145, 0.22)';

const BASE_STYLE: PathOptions = {
  color: STATE_STROKE,
  weight: 1.5,
  opacity: 0.9,
  fillColor: STATE_FILL,
  fillOpacity: 1,
};

const HOVER_STYLE: PathOptions = {
  ...BASE_STYLE,
  weight: 2.25,
  fillColor: STATE_FILL_HOVER,
};

/**
 * The Live Map's default view: plain Indian state boundaries only, with no
 * district-level detail and no risk coloring - per the compliance
 * requirement that the map not show a Pan-India district choropleth by
 * default (see districtGeo.ts's header for why the previous boundary
 * source was replaced). A light, uniform fill keeps every state clickable
 * (an outline with no fill has no interactive area in its interior)
 * without implying any risk/data meaning the way DistrictLayer's fill does.
 *
 * Picking a state - by clicking it here, or via MapControls' State
 * dropdown - hands off to DistrictLayer for that one state's actual
 * district-level detail and choropleth.
 */
export function StateOutlinesLayer({ features, onSelectState }: StateOutlinesLayerProps) {
  const map = useMap();

  const collection: DistrictFeatureCollection = useMemo(
    () => ({ type: 'FeatureCollection', features }),
    [features]
  );

  const style: StyleFunction<Record<string, unknown>> = () => BASE_STYLE;

  const onEachFeature = (feature: DistrictFeature, layer: Layer) => {
    const name = extractStateName(feature);
    if (!name) return;
    layer.bindTooltip(name, { sticky: true, direction: 'top' });
    layer.on('click', (e: LeafletMouseEvent) => {
      L.DomEvent.stopPropagation(e);
      onSelectState(name);
      const bounds = (layer as L.Polygon).getBounds();
      if (bounds.isValid()) map.flyToBounds(bounds, { padding: [40, 40], duration: 0.6, maxZoom: 8 });
    });
    layer.on('mouseover', () => (layer as L.Path).setStyle(HOVER_STYLE));
    layer.on('mouseout', () => (layer as L.Path).setStyle(BASE_STYLE));
  };

  return (
    <GeoJSON
      key={`india-states-${features.length}`}
      data={collection}
      style={style}
      onEachFeature={onEachFeature}
    />
  );
}
