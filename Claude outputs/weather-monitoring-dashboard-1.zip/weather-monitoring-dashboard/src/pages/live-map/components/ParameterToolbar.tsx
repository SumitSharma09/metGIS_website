import Paper from '@mui/material/Paper';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import Divider from '@mui/material/Divider';
import Typography from '@mui/material/Typography';
import ThermostatRoundedIcon from '@mui/icons-material/ThermostatRounded';
import WaterDropRoundedIcon from '@mui/icons-material/WaterDropRounded';
import WbCloudyRoundedIcon from '@mui/icons-material/WbCloudyRounded';
import VisibilityRoundedIcon from '@mui/icons-material/VisibilityRounded';
import CloudRoundedIcon from '@mui/icons-material/CloudRounded';
import AirRoundedIcon from '@mui/icons-material/AirRounded';
import BoltRoundedIcon from '@mui/icons-material/BoltRounded';
import AcUnitRoundedIcon from '@mui/icons-material/AcUnitRounded';
import TerrainRoundedIcon from '@mui/icons-material/TerrainRounded';
import type { MapLayer } from '../mapLayers';

const LAYER_ICON: Record<MapLayer, JSX.Element> = {
  temperature: <ThermostatRoundedIcon fontSize="small" />,
  rainfall: <WaterDropRoundedIcon fontSize="small" />,
  cloud: <WbCloudyRoundedIcon fontSize="small" />,
  visibility: <VisibilityRoundedIcon fontSize="small" />,
  fog: <CloudRoundedIcon fontSize="small" />,
  wind: <AirRoundedIcon fontSize="small" />,
  lightning: <BoltRoundedIcon fontSize="small" />,
  snowfall: <AcUnitRoundedIcon fontSize="small" />,
  avalanche: <TerrainRoundedIcon fontSize="small" />,
};

const LAYER_SHORT_LABEL: Record<MapLayer, string> = {
  temperature: 'Temp',
  rainfall: 'Rainfall',
  cloud: 'Cloud',
  visibility: 'Visibility',
  fog: 'Fog',
  wind: 'Wind',
  lightning: 'Lightning',
  snowfall: 'Snowfall',
  avalanche: 'Avalanche',
};

// Every weather parameter AND every hazard the app tracks lives in this one
// toolbar - Lightning/Snowfall/Avalanche used to only be reachable from a
// separate Hazards page (each with its own small map); folding them in here
// means there's exactly one live map, with every parameter just a click
// away, matching how the reference product presents a single toggle row
// rather than a second page. Flood isn't listed separately since flood risk
// *is* rainfall risk (see hazardData.ts's getFloodRisk) - Rainfall already
// covers it. Cyclone isn't a per-district parameter (it's a storm track),
// so it stays on its own page rather than becoming a 10th button here.
const PARAMETER_ORDER: MapLayer[] = [
  'temperature',
  'rainfall',
  'cloud',
  'visibility',
  'fog',
  'lightning',
  'snowfall',
  'avalanche',
];

interface ParameterToolbarProps {
  layer: MapLayer;
  onChangeLayer: (layer: MapLayer) => void;
  showWind: boolean;
  onToggleWind: (show: boolean) => void;
}

const BUTTON_SX = {
  flexDirection: 'column' as const,
  gap: 0.25,
  px: 1.25,
  py: 0.75,
  minWidth: 64,
  lineHeight: 1,
  textTransform: 'none' as const,
};

export function ParameterToolbar({ layer, onChangeLayer, showWind, onToggleWind }: ParameterToolbarProps) {
  return (
    <Paper
      elevation={4}
      sx={{
        position: 'absolute',
        top: 12,
        left: 12,
        zIndex: 1000,
        p: 0.75,
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 0.75,
        maxWidth: 'calc(100% - 24px)',
        overflowX: 'auto',
        backgroundColor: 'background.paper',
        opacity: 0.97,
      }}
    >
      <ToggleButtonGroup
        size="small"
        exclusive
        value={layer}
        onChange={(_e, value: MapLayer | null) => value && onChangeLayer(value)}
      >
        {PARAMETER_ORDER.map((value) => (
          <ToggleButton key={value} value={value} sx={BUTTON_SX}>
            {LAYER_ICON[value]}
            <Typography variant="caption" sx={{ fontSize: '0.65rem', lineHeight: 1 }}>
              {LAYER_SHORT_LABEL[value]}
            </Typography>
          </ToggleButton>
        ))}
      </ToggleButtonGroup>

      <Divider orientation="vertical" flexItem sx={{ mx: 0.25 }} />

      <ToggleButton
        value="wind"
        size="small"
        selected={showWind}
        onChange={() => onToggleWind(!showWind)}
        sx={BUTTON_SX}
      >
        {LAYER_ICON.wind}
        <Typography variant="caption" sx={{ fontSize: '0.65rem', lineHeight: 1 }}>
          Wind
        </Typography>
      </ToggleButton>
    </Paper>
  );
}
