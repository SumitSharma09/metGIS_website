import { useMemo } from 'react';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Chip from '@mui/material/Chip';
import LockRoundedIcon from '@mui/icons-material/LockRounded';
import { useListDistrictsQuery, useListTehsilsQuery } from '@/features/sites/sitesApi';
import { useScopedStates } from '@/features/users/useScopedStates';

interface MapControlsProps {
  state: string | null;
  onChangeState: (state: string | null) => void;
  district: string | null;
  onChangeDistrict: (district: string | null) => void;
  tehsil: string | null;
  onChangeTehsil: (tehsil: string | null) => void;
  /** Every Indian state/UT the signed-in user is allowed to pick, from the
   *  real Survey-of-India boundary dataset (LiveMapPage's
   *  `visibleStateFeatures`) - not just states that happen to already have
   *  a monitored site, which is what this dropdown used to be limited to. */
  stateOptions: string[];
  /** Real district names for the currently picked state, from the same
   *  boundary dataset - merged below with the monitored-site-derived list
   *  so a state with no towers yet still has its actual districts
   *  searchable, matching what's already clickable on the map itself. */
  districtOptions?: string[];
}

/**
 * Region drill-down (state -> district -> tehsil), each level locked until
 * the one above it is picked - matching the reference product's cascading
 * dropdowns rather than letting district/tehsil be searched nationwide
 * before a state is chosen. Parameter selection, basemap, and the wind
 * toggle used to live in this same panel, but now live in the top-left
 * `ParameterToolbar` and top-right `MapViewControls` instead - matching the
 * reference product's icon-button toolbars - so this panel is just the
 * region picker now.
 */
export function MapControls({
  state,
  onChangeState,
  district,
  onChangeDistrict,
  tehsil,
  onChangeTehsil,
  stateOptions,
  districtOptions,
}: MapControlsProps) {
  const { data: siteDistricts = [] } = useListDistrictsQuery(state ?? undefined, { skip: !state });
  const districts = useMemo(
    () => Array.from(new Set([...siteDistricts, ...(districtOptions ?? [])])).sort(),
    [siteDistricts, districtOptions]
  );
  const { data: tehsils = [] } = useListTehsilsQuery(
    state && district ? { state, district } : undefined,
    { skip: !state || !district }
  );
  const { isPanIndia, assignedStates } = useScopedStates();

  return (
    <Paper
      elevation={4}
      sx={{
        position: 'absolute',
        top: 68,
        left: 12,
        zIndex: 900,
        p: 1.5,
        width: 240,
        backgroundColor: 'background.paper',
        opacity: 0.97,
      }}
    >
      <Typography variant="caption" fontWeight={700} color="text.secondary">
        REGION
      </Typography>
      <Stack spacing={1.5} sx={{ mt: 1 }}>
        <Autocomplete
          size="small"
          options={stateOptions}
          value={state}
          onChange={(_e, value) => {
            onChangeState(value);
            onChangeDistrict(null);
            onChangeTehsil(null);
          }}
          renderInput={(params) => <TextField {...params} label="State" />}
        />
        <Autocomplete
          size="small"
          options={districts}
          value={district}
          disabled={!state}
          onChange={(_e, value) => {
            onChangeDistrict(value);
            onChangeTehsil(null);
          }}
          renderInput={(params) => <TextField {...params} label={state ? 'District' : 'Select state first'} />}
        />
        <Autocomplete
          size="small"
          options={tehsils}
          value={tehsil}
          disabled={!district}
          onChange={(_e, value) => onChangeTehsil(value)}
          renderInput={(params) => (
            <TextField {...params} label={district ? 'Tehsil' : 'Select district first'} />
          )}
        />
        <Typography variant="caption" color="text.secondary">
          Tip: click a district on the map to select it too.
        </Typography>
        {!isPanIndia && (
          <Chip
            size="small"
            variant="outlined"
            color="primary"
            icon={<LockRoundedIcon fontSize="small" />}
            label={`Scoped to: ${assignedStates.join(', ') || 'none assigned'}`}
            sx={{ alignSelf: 'flex-start' }}
          />
        )}
      </Stack>
    </Paper>
  );
}
