import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import VisibilityRoundedIcon from '@mui/icons-material/VisibilityRounded';
import CloudRoundedIcon from '@mui/icons-material/CloudRounded';
import ThermostatRoundedIcon from '@mui/icons-material/ThermostatRounded';
import WaterDropRoundedIcon from '@mui/icons-material/WaterDropRounded';
import AirRoundedIcon from '@mui/icons-material/AirRounded';
import CellTowerRoundedIcon from '@mui/icons-material/CellTowerRounded';
import NotificationsActiveRoundedIcon from '@mui/icons-material/NotificationsActiveRounded';
import DescriptionRoundedIcon from '@mui/icons-material/DescriptionRounded';
import OpenInNewRoundedIcon from '@mui/icons-material/OpenInNewRounded';
import type { Site } from '@/features/sites/types';
import {
  useGetCurrentObservationBySiteQuery,
  useGetHistoricalDataQuery,
  useGetForecastQuery,
} from '@/features/weather/weatherApi';
import { formatWithUnit } from '@/utils/formatters';
import { ROUTES } from '@/routes/routePaths';
import { averageOf, buildOutlookNarrative, peakRainChance } from '../weatherNarrative';
import { StatBox } from './StatBox';

interface WeatherDetailsPanelProps {
  site: Site;
  onClose: () => void;
}

export const WEATHER_DETAILS_PANEL_WIDTH = 340;

/**
 * The right-side detail panel opened by clicking a tower marker, matching
 * the reference product's "Weather details" drawer. Fields backed by real
 * data use it directly (current reading, 24h hourly average, 7-day
 * forecast); the "Forecast Outlook" paragraph is genuinely derived from
 * that same 7-day forecast (see weatherNarrative.ts) rather than a
 * fabricated 15-day write-up, since a true multi-week forecast isn't part
 * of this app's data model yet.
 */
export function WeatherDetailsPanel({ site, onClose }: WeatherDetailsPanelProps) {
  const navigate = useNavigate();
  const { data: obs } = useGetCurrentObservationBySiteQuery(site.id, { pollingInterval: 60000 });
  const { data: history = [] } = useGetHistoricalDataQuery({
    siteId: site.id,
    from: dayjs().subtract(24, 'hour').toISOString(),
    to: dayjs().toISOString(),
    interval: 'hourly',
  });
  const { data: forecast = [] } = useGetForecastQuery({ siteId: site.id, days: 7 });

  const avgTemp = averageOf(history, (p) => p.temperature);
  const avgHumidity = averageOf(history, (p) => p.humidity);
  const avgWind = averageOf(history, (p) => p.windSpeed);
  const rainChance = peakRainChance(forecast);
  const outlook = buildOutlookNarrative(forecast);
  const readingCountLabel = `${history.length} reading${history.length === 1 ? '' : 's'}`;

  return (
    <Paper
      elevation={6}
      sx={{
        position: 'absolute',
        top: 0,
        right: 0,
        height: '100%',
        width: WEATHER_DETAILS_PANEL_WIDTH,
        maxWidth: '92%',
        zIndex: 1200,
        p: 2.5,
        overflowY: 'auto',
        borderRadius: 0,
      }}
    >
      <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
        <Typography variant="subtitle1" fontWeight={700}>
          Weather details
        </Typography>
        <IconButton size="small" onClick={onClose}>
          <CloseRoundedIcon fontSize="small" />
        </IconButton>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
        {site.name}, {site.district}, {site.state}
      </Typography>
      <Stack direction="row" spacing={0.75} alignItems="center" sx={{ mt: 1 }}>
        <CellTowerRoundedIcon fontSize="small" color="action" />
        <Typography variant="caption" color="text.secondary">
          {site.code} &middot; {site.towerType} tower
        </Typography>
      </Stack>

      <Divider sx={{ my: 2 }} />

      <Stack direction="row" spacing={1.5}>
        <StatBox
          icon={<VisibilityRoundedIcon fontSize="small" />}
          label="VISIBILITY"
          value={obs ? formatWithUnit(obs.visibilityKm, 'km') : '--'}
          subtitle="Current reading"
        />
        <StatBox
          icon={<CloudRoundedIcon fontSize="small" />}
          label="FOG"
          value={obs?.condition === 'fog' ? 'Present' : 'Clear'}
          subtitle="Regional fog outlook"
        />
      </Stack>

      {outlook && (
        <>
          <Typography
            variant="caption"
            fontWeight={700}
            color="text.secondary"
            sx={{ display: 'block', mt: 2.5, mb: 1, letterSpacing: 0.5 }}
          >
            FORECAST OUTLOOK
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {outlook}
          </Typography>
        </>
      )}

      <Typography
        variant="caption"
        fontWeight={700}
        color="text.secondary"
        sx={{ display: 'block', mt: 2.5, mb: 1, letterSpacing: 0.5 }}
      >
        HOURLY SUMMARY
      </Typography>
      <Stack spacing={1.5}>
        <Stack direction="row" spacing={1.5}>
          <StatBox
            icon={<ThermostatRoundedIcon fontSize="small" />}
            label="AVG TEMPERATURE"
            value={avgTemp != null ? formatWithUnit(avgTemp, '°C') : '--'}
            subtitle={readingCountLabel}
          />
          <StatBox
            icon={<WaterDropRoundedIcon fontSize="small" />}
            label="AVG HUMIDITY"
            value={avgHumidity != null ? `${Math.round(avgHumidity)}%` : '--'}
            subtitle="Relative humidity"
          />
        </Stack>
        <Stack direction="row" spacing={1.5}>
          <StatBox
            icon={<AirRoundedIcon fontSize="small" />}
            label="AVG WIND"
            value={avgWind != null ? formatWithUnit(avgWind, 'km/h') : '--'}
            subtitle={readingCountLabel}
          />
          <StatBox
            icon={<WaterDropRoundedIcon fontSize="small" />}
            label="PEAK RAIN CHANCE"
            value={rainChance != null ? `${Math.round(rainChance)}%` : '--'}
            subtitle={`Next ${forecast.length || 7} days`}
          />
        </Stack>
      </Stack>

      <Divider sx={{ my: 2 }} />

      <Stack spacing={1}>
        <Button fullWidth variant="outlined" startIcon={<NotificationsActiveRoundedIcon />} onClick={() => navigate(ROUTES.alerts)}>
          Weather alerts
        </Button>
        <Button fullWidth variant="outlined" startIcon={<DescriptionRoundedIcon />} onClick={() => navigate(ROUTES.reports)}>
          Reports &amp; exports
        </Button>
        <Button
          fullWidth
          size="small"
          endIcon={<OpenInNewRoundedIcon fontSize="small" />}
          onClick={() => navigate(ROUTES.siteDetail(site.id))}
        >
          View full site page
        </Button>
      </Stack>
    </Paper>
  );
}
