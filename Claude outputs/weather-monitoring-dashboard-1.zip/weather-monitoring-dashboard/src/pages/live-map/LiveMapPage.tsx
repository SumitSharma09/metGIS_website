import { useMemo, useRef, useState } from 'react';
import Box from '@mui/material/Box';
import Chip from '@mui/material/Chip';
import { MapContainer, TileLayer } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useListSitesQuery } from '@/features/sites/sitesApi';
import { useGetObservationsAtTimeQuery } from '@/features/weather/weatherApi';
import type { CurrentObservation } from '@/features/weather/types';
import type { Site } from '@/features/sites/types';
import { LoadingState } from '@/components/common/LoadingState';
import { ErrorState } from '@/components/common/ErrorState';
import { buildDistrictRiskIndex, normalizeName } from '@/utils/districtRisk';
import { useSevenDayObservations } from '@/pages/reports/useSevenDayObservations';
import { MapControls } from './components/MapControls';
import { ParameterToolbar } from './components/ParameterToolbar';
import { MapViewControls } from './components/MapViewControls';
import { RiskLegend } from './components/RiskLegend';
import { WeatherDetailsPanel, WEATHER_DETAILS_PANEL_WIDTH } from './components/WeatherDetailsPanel';
import { NetworkWeatherPanel } from './components/NetworkWeatherPanel';
import { TimelineScrubber } from './components/TimelineScrubber';
import { SiteMarkers } from './components/SiteMarkers';
import { WindFlowLayer } from './components/WindFlowLayer';
import { DistrictLayer } from './components/DistrictLayer';
import { StateBoundaryLayer } from './components/StateBoundaryLayer';
import { StateOutlinesLayer } from './components/StateOutlinesLayer';
import { IndiaBoundaryOutline } from './components/IndiaBoundaryOutline';
import { useMapTimeline } from './useMapTimeline';
import { useDistrictBoundariesForStates, useIndiaStates, useVisibleStates } from './useDistrictBoundaries';
import { extractStateName, extractNames, canonicalDistrictName } from './districtGeo';
import { layerRisk, LAYER_COLORS, type MapLayer } from './mapLayers';

export type Basemap = 'street' | 'satellite';

const INDIA_CENTER: [number, number] = [22.9734, 78.6569];

const TILE_LAYERS: Record<Basemap, { url: string; attribution: string }> = {
  street: {
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; OpenStreetMap contributors',
  },
  satellite: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, Maxar, Earthstar Geographics',
  },
};

export default function LiveMapPage() {
  const [state, setState] = useState<string | null>(null);
  const [district, setDistrict] = useState<string | null>(null);
  const [tehsil, setTehsil] = useState<string | null>(null);
  const [layer, setLayer] = useState<MapLayer>('temperature');
  const [basemap, setBasemap] = useState<Basemap>('street');
  const [showWind, setShowWind] = useState(false);
  const [showTowers, setShowTowers] = useState(true);
  const [selectedSite, setSelectedSite] = useState<Site | null>(null);
  const [showNetworkPanel, setShowNetworkPanel] = useState(false);

  const mapWrapperRef = useRef<HTMLDivElement>(null);

  const timeline = useMapTimeline();

  const { data: sitesPage, isLoading: sitesLoading, isError: sitesError, refetch } = useListSitesQuery({
    state: state ?? undefined,
    district: district ?? undefined,
    tehsil: tehsil ?? undefined,
    pageSize: 200,
  });
  const sites = useMemo(() => sitesPage?.items ?? [], [sitesPage]);
  const siteIds = useMemo(() => sites.map((s) => s.id), [sites]);

  const { data: observationsList } = useGetObservationsAtTimeQuery(
    { siteIds, at: timeline.at },
    { skip: siteIds.length === 0 }
  );

  const observations = useMemo(() => {
    const map: Record<string, CurrentObservation> = {};
    (observationsList ?? []).forEach((obs) => {
      map[obs.siteId] = obs;
    });
    return map;
  }, [observationsList]);

  // A second, state-scoped-but-not-district-filtered (or, with no state
  // picked yet, nationwide) view of the sites - this is what drives the
  // district choropleth, since every district needs to be colored by its
  // own worst risk, not just whichever single district the dropdown
  // currently has selected.
  const { data: riskScopeSitesPage } = useListSitesQuery({ state: state ?? undefined, pageSize: 500 });
  const riskScopeSites = useMemo(() => riskScopeSitesPage?.items ?? [], [riskScopeSitesPage]);
  const riskScopeSiteIds = useMemo(() => riskScopeSites.map((s) => s.id), [riskScopeSites]);

  const { data: riskScopeObservationsList } = useGetObservationsAtTimeQuery(
    { siteIds: riskScopeSiteIds, at: timeline.at },
    { skip: riskScopeSiteIds.length === 0 }
  );

  // Also feeds the wind-flow overlay below, so the animated field has
  // samples spread across the whole visible region (not just whichever
  // single district the dropdown currently narrows `sites`/`observations`
  // down to).
  const riskScopeObservations = useMemo(() => {
    const map: Record<string, CurrentObservation> = {};
    (riskScopeObservationsList ?? []).forEach((obs) => {
      map[obs.siteId] = obs;
    });
    return map;
  }, [riskScopeObservationsList]);

  // Only fetched while the network Weather details panel (opened via the
  // (i) button) is actually open - skip is baked into useSevenDayObservations
  // itself (siteIds.length === 0), so passing an empty array while the
  // panel is closed avoids firing seven extra queries for nothing.
  const { days: networkDays } = useSevenDayObservations(showNetworkPanel ? riskScopeSiteIds : []);

  // When a tehsil is picked, the selected district's own choropleth color
  // (and its tooltip's site count) should reflect just that tehsil - not
  // the whole district - otherwise picking a tehsil visibly changes nothing
  // on the map, which is confusing. Every *other* district still aggregates
  // across all of its sites as before; this only narrows the one district
  // the tehsil actually belongs to.
  const districtRiskScopeSites = useMemo(() => {
    if (!tehsil || !district) return riskScopeSites;
    return riskScopeSites.filter((s) => s.district !== district || s.tehsil === tehsil);
  }, [riskScopeSites, district, tehsil]);

  const districtRiskIndex = useMemo(() => {
    return buildDistrictRiskIndex(districtRiskScopeSites, riskScopeObservations, (site, obs) =>
      layerRisk(layer, obs, site)
    );
  }, [districtRiskScopeSites, riskScopeObservations, layer]);

  // District boundaries (the previously non-government-approved data
  // source has been replaced - see districtGeo.ts's header) are now only
  // ever loaded for the single state the user has drilled into, never
  // Pan-India: with no state picked, the map shows plain state outlines
  // instead (StateOutlinesLayer, fed by the india-states.json dataset
  // below), and picking a state hands off to the district-level choropleth
  // here.
  const indiaStates = useIndiaStates();
  const { get: getBoundary } = useDistrictBoundariesForStates(state ? [state] : []);

  // RBAC scoping (section 5 of the scope doc): a Pan-India admin sees every
  // one of India's 37 states/UTs; an operator/viewer only sees their own
  // `assignedStates`. This used to be narrowed through `useListStatesQuery()`
  // (the sites-derived list), which meant a state/UT with no monitored site
  // yet never showed up at all - not what "show me all states/UT" should
  // mean. `useVisibleStates()` (shared with FloodMap/RegionRiskMap/the
  // Reports state filter, so this fix applies everywhere at once - see its
  // own doc comment) filters the real india-states.json list directly
  // against RBAC instead, giving every government-recognized state/UT the
  // user is allowed to see, whether or not it has a tower in it yet.
  const { features: visibleStateFeatures, names: stateOptions } = useVisibleStates();

  const districtBoundary = state ? getBoundary(state) : null;

  // The District dropdown's options for the picked state: real district
  // names from the same boundary dataset, so a state with no monitored
  // sites yet still has its actual districts searchable in the dropdown -
  // matching what's already clickable on the map itself.
  const districtOptions = useMemo(() => {
    if (!state || !districtBoundary) return [];
    const names = new Set<string>();
    districtBoundary.features.forEach((f) => {
      const parsed = extractNames(f);
      if (parsed) names.add(canonicalDistrictName(parsed.district, parsed.state));
    });
    return Array.from(names).sort();
  }, [state, districtBoundary]);

  const selectedStateFeature = useMemo(() => {
    if (!state) return null;
    return (
      indiaStates.features.find((f) => normalizeName(extractStateName(f) ?? '') === normalizeName(state)) ?? null
    );
  }, [indiaStates.features, state]);

  const anyBoundaryLoading = state ? !!districtBoundary?.loading : indiaStates.loading;
  const allBoundariesFailed = state
    ? !districtBoundary?.loading && (districtBoundary?.features.length ?? 0) === 0
    : !indiaStates.loading && indiaStates.error;

  const handleSelectDistrict = (districtName: string, districtState: string) => {
    setState(districtState);
    setDistrict(districtName);
    setTehsil(null);
  };

  const handleSelectState = (stateName: string) => {
    setState(stateName);
    setDistrict(null);
    setTehsil(null);
  };

  // Either Weather details panel (per-tower or network-wide) occupies the
  // right edge of the map when open, so the top-right view controls and the
  // legend shift left by its width instead of being covered by it. The two
  // panels are mutually exclusive (see handleSelectSite/handleOpenInfo).
  const rightControlOffset = selectedSite || showNetworkPanel ? WEATHER_DETAILS_PANEL_WIDTH + 24 : 12;

  const handleSelectSite = (site: Site) => {
    setShowNetworkPanel(false);
    setSelectedSite(site);
  };

  const handleOpenInfo = () => {
    setSelectedSite(null);
    setShowNetworkPanel(true);
  };

  if (sitesLoading) return <LoadingState label="Loading tower network..." />;
  if (sitesError) return <ErrorState title="Failed to load sites" onRetry={refetch} />;

  return (
    <Box ref={mapWrapperRef} sx={{ position: 'relative', flex: 1, minHeight: 0 }}>
      <MapContainer
        center={INDIA_CENTER}
        zoom={5}
        minZoom={4}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          key={basemap}
          url={TILE_LAYERS[basemap].url}
          attribution={TILE_LAYERS[basemap].attribution}
        />
        <IndiaBoundaryOutline />
        {!state && visibleStateFeatures.length > 0 && (
          <StateOutlinesLayer features={visibleStateFeatures} onSelectState={handleSelectState} />
        )}
        {state && districtBoundary && districtBoundary.features.length > 0 && (
          <>
            <DistrictLayer
              stateName={state}
              features={districtBoundary.features}
              districtRisk={districtRiskIndex}
              colors={LAYER_COLORS[layer]}
              selectedDistrict={district}
              selectedTehsil={tehsil}
              onSelectDistrict={handleSelectDistrict}
              enableFitBounds
            />
            <StateBoundaryLayer stateName={state} feature={selectedStateFeature} />
          </>
        )}
        {showTowers && <SiteMarkers sites={sites} observations={observations} layer={layer} onSelectSite={handleSelectSite} />}
        <WindFlowLayer sites={riskScopeSites} observations={riskScopeObservations} enabled={showWind} />
      </MapContainer>

      {anyBoundaryLoading && (
        <Chip
          label={state ? 'Loading district boundaries...' : 'Loading state boundaries...'}
          size="small"
          sx={{ position: 'absolute', bottom: 84, left: '50%', transform: 'translateX(-50%)', zIndex: 1000 }}
        />
      )}
      {!anyBoundaryLoading && allBoundariesFailed && (
        <Chip
          label={
            state
              ? 'District boundaries unavailable - showing site markers only'
              : 'State boundaries unavailable - showing site markers only'
          }
          size="small"
          color="warning"
          sx={{ position: 'absolute', bottom: 84, left: '50%', transform: 'translateX(-50%)', zIndex: 1000 }}
        />
      )}

      <ParameterToolbar layer={layer} onChangeLayer={setLayer} showWind={showWind} onToggleWind={setShowWind} />
      <MapControls
        state={state}
        onChangeState={setState}
        district={district}
        onChangeDistrict={setDistrict}
        tehsil={tehsil}
        onChangeTehsil={setTehsil}
        stateOptions={stateOptions}
        districtOptions={districtOptions}
      />
      <MapViewControls
        basemap={basemap}
        onChangeBasemap={setBasemap}
        showTowers={showTowers}
        onToggleTowers={setShowTowers}
        onOpenInfo={handleOpenInfo}
        fullscreenTargetRef={mapWrapperRef}
        right={rightControlOffset}
      />
      <RiskLegend layer={layer} showWindGradient={showWind} right={rightControlOffset} />
      {selectedSite && <WeatherDetailsPanel site={selectedSite} onClose={() => setSelectedSite(null)} />}
      {showNetworkPanel && (
        <NetworkWeatherPanel
          sites={riskScopeSites}
          observations={riskScopeObservations}
          days={networkDays}
          onClose={() => setShowNetworkPanel(false)}
        />
      )}
      <TimelineScrubber
        mode={timeline.mode}
        onChangeMode={timeline.setMode}
        days={timeline.days}
        dayOffset={timeline.dayOffset}
        onChangeOffset={timeline.setDayOffset}
        hours={timeline.hours}
        hourOffset={timeline.hourOffset}
        onChangeHourOffset={timeline.setHourOffset}
        playing={timeline.playing}
        onTogglePlaying={timeline.togglePlaying}
        speed={timeline.speed}
        onChangeSpeed={timeline.setSpeed}
      />
    </Box>
  );
}
