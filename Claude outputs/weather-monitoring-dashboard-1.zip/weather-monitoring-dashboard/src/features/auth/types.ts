import type { UserProfile, UserLocation, NotificationPreferences } from '@/features/users/types';

export interface LoginPayload {
  username: string;
  password: string;
  rememberMe?: boolean;
}

export interface LoginResponse {
  token: string;
  user: UserProfile;
}

/** New self-service accounts register as 'viewer' (the least-privileged
 *  role) with `assignedStates` narrowed to their own registration state -
 *  an admin can broaden this later from user management. Location and
 *  notification preferences are what let the Hazards page's "Registered
 *  Recipients" preview match this user to tower alerts for their circle. */
export interface RegisterPayload {
  username: string;
  password: string;
  fullName: string;
  email: string;
  phone: string;
  designation?: string;
  location: UserLocation;
  notificationPreferences: NotificationPreferences;
}

export type RegisterResponse = LoginResponse;
