export type WeatherCondition =
  | 'clear'
  | 'partly-cloudy'
  | 'cloudy'
  | 'rain'
  | 'thunderstorm'
  | 'fog'
  | 'windy';

export interface CurrentObservation {
  siteId: string;
  timestamp: string; // ISO datetime
  temperature: number; // deg C
  feelsLike: number;
  humidity: number; // %
  rainfallLastHour: number; // mm
  rainfallToday: number; // mm
  windSpeed: number; // km/h
  windGust: number; // km/h
  windDirection: number; // degrees 0-359
  pressure: number; // hPa
  lightningStrikesLastHour: number;
  condition: WeatherCondition;
  visibilityKm: number;
  // Real snowfall (cm), present only when the backend is sourcing this
  // observation from real Indus station data (see the backend's
  // IndusWeatherMapper) - undefined for the mock/demo generator, which
  // doesn't model snow. severity.ts's snowfall/avalanche risk functions use
  // this directly when it's present, falling back to their old
  // elevation-based proxy when it's not.
  snowfallCm?: number;
}

export interface HistoricalPoint {
  timestamp: string;
  temperature: number;
  humidity: number;
  rainfall: number;
  windSpeed: number;
  pressure: number;
  lightningStrikes: number;
  snowfallCm?: number; // see CurrentObservation.snowfallCm
}

export interface HistoricalQuery {
  siteId: string;
  from: string; // ISO date
  to: string; // ISO date
  interval?: 'hourly' | 'daily';
}

export interface ForecastDay {
  date: string; // ISO date
  minTemp: number;
  maxTemp: number;
  rainfallProbability: number; // %
  expectedRainfallMm: number;
  windSpeed: number;
  condition: WeatherCondition;
  summary: string;
}

export interface ForecastQuery {
  siteId: string;
  days?: number;
}
